CREATE TABLE IF NOT EXISTS `afhwp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_commentmeta` VALUES ("1","1","_wp_trash_meta_status","post-trashed");
INSERT INTO `afhwp_commentmeta` VALUES ("2","1","_wp_trash_meta_time","1542964855");


CREATE TABLE IF NOT EXISTS `afhwp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_comments` VALUES ("1","1","A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2018-11-23 09:06:34","2018-11-23 09:06:34","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.","0","trash","","","0","0");


CREATE TABLE IF NOT EXISTS `afhwp_itsec_distributed_storage` (
  `storage_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `storage_group` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_key` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `storage_chunk` int(11) NOT NULL DEFAULT '0',
  `storage_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_updated` datetime NOT NULL,
  PRIMARY KEY (`storage_id`),
  UNIQUE KEY `storage_group__key__chunk` (`storage_group`,`storage_key`,`storage_chunk`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `afhwp_itsec_fingerprints` (
  `fingerprint_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fingerprint_user` bigint(20) unsigned NOT NULL,
  `fingerprint_hash` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fingerprint_created_at` datetime NOT NULL,
  `fingerprint_approved_at` datetime NOT NULL,
  `fingerprint_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fingerprint_snapshot` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fingerprint_last_seen` datetime NOT NULL,
  `fingerprint_uses` int(11) NOT NULL DEFAULT '0',
  `fingerprint_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fingerprint_uuid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`fingerprint_id`),
  UNIQUE KEY `fingerprint_user__hash` (`fingerprint_user`,`fingerprint_hash`),
  UNIQUE KEY `fingerprint_uuid` (`fingerprint_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `afhwp_itsec_geolocation_cache` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_host` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_lat` decimal(10,8) NOT NULL,
  `location_long` decimal(11,8) NOT NULL,
  `location_label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_credit` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_time` datetime NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_host` (`location_host`),
  KEY `location_time` (`location_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `afhwp_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `afhwp_itsec_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `code` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'notice',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `init_timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `memory_current` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memory_peak` bigint(20) unsigned NOT NULL DEFAULT '0',
  `url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `remote_ip` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `code` (`code`),
  KEY `type` (`type`),
  KEY `timestamp` (`timestamp`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `afhwp_itsec_logs` VALUES ("1","0","file_change","scan","a:2:{s:8:\"settings\";a:6:{s:9:\"file_list\";a:0:{}s:5:\"types\";a:40:{i:0;s:4:\".log\";i:1;s:3:\".mo\";i:2;s:3:\".po\";i:3;s:4:\".bmp\";i:4;s:4:\".gif\";i:5;s:4:\".ico\";i:6;s:4:\".jpe\";i:7;s:5:\".jpeg\";i:8;s:4:\".jpg\";i:9;s:4:\".png\";i:10;s:4:\".psd\";i:11;s:4:\".raw\";i:12;s:4:\".svg\";i:13;s:4:\".tif\";i:14;s:5:\".tiff\";i:15;s:4:\".aif\";i:16;s:5:\".flac\";i:17;s:4:\".m4a\";i:18;s:4:\".mp3\";i:19;s:4:\".oga\";i:20;s:4:\".ogg\";i:21;s:4:\".ogg\";i:22;s:3:\".ra\";i:23;s:4:\".wav\";i:24;s:4:\".wma\";i:25;s:4:\".asf\";i:26;s:4:\".avi\";i:27;s:4:\".mkv\";i:28;s:4:\".mov\";i:29;s:4:\".mp4\";i:30;s:4:\".mpe\";i:31;s:5:\".mpeg\";i:32;s:4:\".mpg\";i:33;s:4:\".ogv\";i:34;s:3:\".qt\";i:35;s:3:\".rm\";i:36;s:4:\".vob\";i:37;s:5:\".webm\";i:38;s:3:\".wm\";i:39;s:4:\".wmv\";}s:12:\"notify_admin\";b:1;s:12:\"show_warning\";b:0;s:15:\"expected_hashes\";a:0:{}s:9:\"last_scan\";i:0;}s:14:\"scheduled_call\";b:1;}","process-start","2018-11-24 10:00:01","2018-11-24 10:00:01","6340408","6352880","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("2","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:5:\"admin\";}","process-update","2018-11-24 10:00:01","2018-11-24 10:00:01","6350840","6390576","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("3","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:8:\"includes\";}","process-update","2018-11-24 10:02:00","2018-11-24 10:02:00","6328832","6375648","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("4","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:7:\"content\";}","process-update","2018-11-24 10:04:01","2018-11-24 10:04:01","6328824","6375632","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("5","0","notification_center","send::backup","a:2:{s:10:\"recipients\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:29:\"[hack.africa] Database Backup\";}","debug","2018-11-24 10:05:51","2018-11-24 10:05:50","6555856","9414464","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("6","0","notification_center","send_failed::backup","a:1:{s:5:\"error\";O:8:\"WP_Error\":2:{s:6:\"errors\";a:1:{s:14:\"wp_mail_failed\";a:1:{i:0;s:36:\"Could not instantiate mail function.\";}}s:10:\"error_data\";a:1:{s:14:\"wp_mail_failed\";a:6:{s:2:\"to\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:29:\"[hack.africa] Database Backup\";s:7:\"message\";s:50790:\"
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\">

<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
	<title>Database Backup</title>
	<meta name=\"viewport\" content=\"width=device-width\">

	<style type=\"text/css\">
		/* From: https://litmus.com/community/learning/13-foundations-email-coding-101 */

		/* GENERAL STYLE RESETS */
		body,#body-table,#body-cell{height:100%!important;width:100%!important;margin:0;padding:0;}
		img,aimg{border:0;outline:none;text-decoration:none;}
		.imageFix{display:block;}
		table,td{border-collapse:collapse;border-spacing:0;}

		/* CLIENT-SPECIFIC RESETS */
		.ReadMsgBody{width:100%;}
		.ExternalClass{width:100%;}
		.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:100%;}
		table,td{mso-table-lspace:0pt;mso-table-rspace:0pt;}
		img{-ms-interpolation-mode:bicubic;}
		body,table,td,p,a,li,blockquote{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;}


		h1,h2,h3,h4,h5,h6{color:#202020;font-family:Helvetica;font-size:20px;font-weight:bold;line-height:150%;margin:0;padding:0;text-align:center;}
		p{font-family:Helvetica;font-size:16px;line-height:150%;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;padding:0;text-align:center;}
		a{color:#0084CB;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;text-decoration:none;}
		img{height:auto;}

		body,#body-table{background-color:#FFFFFF;}
		#body-cell{padding-bottom:20px;}
		.section-padding{padding-top:20px;padding-right:20px;padding-left:20px;}
		.section-padding-bottom{padding-bottom:20px;}
		.container-cell{color:#808080;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;padding-bottom:20px;}
		#top-banner{background-color:#FFCE08;}
		#top-banner .container-cell{color:#413F39;font-size:13px;}
		#top-logo .container-cell{padding-top:20px;}
		#title-container h1{font-size:34px;}
		.info-box{padding-top:20px;padding-bottom:20px;}
		.info-box .container{border:1px solid #CDCECE;background-color:#F2F2F2;}
		.info-box .section-padding{padding-top:40px;padding-right:40px;padding-left:40px;}
		.info-box .container-cell{padding-bottom:40px;}
		.info-box .info-icon{width:33px;height:23px;vertical-align:middle;}
		.section-heading .container-cell{padding-bottom:0;}
		.section-heading h4{color:#0084CB;font-size:16px;}
		.section-heading h4 img{padding-top:2px;padding-right:5px;vertical-align:top;}
		.lockouts-summary .container.left-column{margin-right:60px;}
		.lockouts-summary h4{color:#ACAAAA;font-size:16px;font-weight:normal;}
		.lockouts-summary p{color:#505050;font-size:30px;font-weight:bold;}
		.table{border:1px solid #cdcece;color: #808080;font-family:Helvetica;font-size:14px;}
		.table th,.table td{border:1px solid #cdcece;padding:10px;}
		.table th{text-align:left;font-weight:bold;padding:5px 10px;}
		.table .row-label{font-style:italic;}
		.table a,.table b{font-size:14px;}
		.large-text h4{color:#505050;margin-bottom:10px;}
		.details-box-container{padding-top:20px;padding-bottom:20px;}
		.details-box{background-color:#E4EEF7;border:1px solid #CDCECE;}
		.details-box .container-cell{color:#6A6A6A;}
		.divider .divider-border{border-top-width:1px;border-top-style:solid;border-top-color:#E8E8E8;}
		.divider .container-cell{line-height:1px;padding-bottom:20px;width:450px;}
		.module-button .border-radius{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;}
		.module-button a{background-color:#FFCD08;border:1px solid #FFCD08;color:#2E280E;display:inline-block;font-size:18px;font-weight:bold;line-height:100%;padding-top:20px;padding-right:30px;padding-bottom:20px;padding-left:30px;}
		.pro-callout{padding-top:20px;}
		.pro-callout-background{background-color:#0B1A23;}
		.pro-callout .section-padding{padding-top:40px;}
		.pro-callout .two-factor{color:#FFFFFF;margin-top:20px;margin-bottom:20px;}
		.pro-callout .module-button a{font-size:30px;}
		.pro-callout .why-pro{color:#999999;font-style:italic;margin-top:20px;margin-bottom:20px;}
		.footer-heading h2{color:#002030;font-size:26px;}
		.pro-flag{background-color:#FFCC00;color:#000000;font-size:10px;display:inline-block;padding:3px;line-height:1;position:relative;bottom:10px;text-transform:uppercase;}
		#security-guide-container{border:1px solid #CDCECE;background-color:#D3E8E9;}
		#security-guide .container-cell{color:#6C6C6C;text-align:left;}
		#security-guide h4{color:#6C6C6C;font-size:18px;padding-bottom:10px;text-align:left;}
		#security-guide a{font-weight:bold;}
		#footer-source-details .container-cell{line-height:200%;padding-top:60px;padding-bottom:0;}
		#footer-source-details a{font-size:11px;font-weight:bold;line-height:200%;}
		.template-container {max-width: 600px !important;}

		@media only screen and (max-width:600px){
			body{width:100% !important;min-width:100% !important;}
			#body-cell{padding:10px !important;}
			#main-container, .container{width:100% !important;}
			.preserve-ratio{height:auto !important;width:100% !important;}
			.container-cell-bottom{padding-top:20px !important;}
			.lockouts-summary .container{width:auto !important;}
		}

		@media only screen and (max-width:450px){
			.divider .container-cell{width:auto !important;}
		}
	</style>
</head>

<body style=\"margin: 0;padding: 0;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
	<center>
		<table id=\"body-table\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
			<tr>
				<td id=\"body-cell\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;padding-bottom: 20px;height: 100%!important;width: 100%!important;\">
					<table id=\"main-container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td id=\"top-banner\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFCE08;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #413F39;font-family: Helvetica;font-size: 13px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	Site Database Backup for <b>November 24, 2018</b>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"top-logo\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;padding-top: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/logo.png\" style=\"max-width: 300px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" alt=\"\" align=\"center\">
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"title-container\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<h1 style=\"color: #202020;font-family: Helvetica;font-size: 34px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Database Backup</h1>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"info-box\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-bottom: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border: 1px solid #CDCECE;background-color: #F2F2F2;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 40px;padding-right: 40px;padding-left: 40px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 40px;\">
																	<img class=\"info-icon\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/attachment_icon.png\" alt=\"\" align=\"center\" width=\"33\" height=\"23\" style=\"border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: 23px;width: 33px;vertical-align: middle;\">
																	Attached is the database backup file for your site.
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"section-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 0;\">
																	<h4 style=\"color: #0084CB;font-family: Helvetica;font-size: 16px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
																		Website
																	</h4>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	hack.africa
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"section-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 0;\">
																	<h4 style=\"color: #0084CB;font-family: Helvetica;font-size: 16px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
																		Date
																	</h4>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	November 24, 2018
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"pro-callout\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;\">
								<table class=\"pro-callout-background\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #0B1A23;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" class=\"container\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td align=\"center\" valign=\"top\" width=\"600\" class=\"section-padding\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 40px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td valign=\"top\" class=\"container-cell\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/pro_logo_no_text.png\" style=\"max-width: 100px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"100\" alt=\"\" align=\"center\">
																	<p class=\"two-factor\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #FFFFFF;\">Want two-factor authentication, scheduled malware scanning, ticketed support and more?</p>
																	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																		<tr>
																			<td style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																				<table class=\"module-button\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																					<tr>
																						<td class=\"border-radius\" align=\"center\" bgcolor=\"#FFCD08\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">
																							<a href=\"https://ithemes.com/security/#plugin-pricing\" target=\"_blank\" class=\"border-radius\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #2E280E;font-family: Helvetica;font-size: 30px;line-height: 100%;text-align: center;text-decoration: none;background-color: #FFCD08;border: 1px solid #FFCD08;display: inline-block;font-weight: bold;padding-top: 20px;padding-right: 30px;padding-bottom: 20px;padding-left: 30px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">Get iThemes Security Pro</a>
																						</td>
																					</tr>
																				</table>
																			</td>
																		</tr>
																	</table>
																	<p class=\"why-pro\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #999999;font-style: italic;\">Why go Pro? <a href=\"https://ithemes.com/security/why-go-pro/\">Check out the Free/Pro comparison chart.</a></p>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Security Resources</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/article_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/category/wordpress-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Articles</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read the latest in WordPress Security news, tips, and updates on <a href=\"https://ithemes.com/category/wordpress-security/\">iThemes Blog</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/video_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/tutorial/category/ithemes-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Tutorials</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Make the most of iThemes Security features with our <a href=\"https://ithemes.com/tutorial/category/ithemes-security/\">free iThemes Security tutorials</a>.</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"divider\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"divider-border\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border-top-width: 1px;border-top-style: solid;border-top-color: #E8E8E8;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 1px;text-align: center;padding-bottom: 20px;width: 450px;\">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Help &amp; Support</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/documentation_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"http://ithemes.com/codex/page/IThemes_Security\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Documentation</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read iThemes Security documentation and Frequently Asked Questions on <a href=\"http://ithemes.com/codex/page/IThemes_Security\">the Codex</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/support_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://members.ithemes.com/panel/helpdesk.php\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Support</a>
												<span class=\"pro-flag\" style=\"background-color: #FFCC00;color: #000000;font-size: 10px;display: inline-block;padding: 3px;line-height: 1;position: relative;bottom: 10px;text-transform: uppercase;\">Pro</span>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Pro customers can contact <a href=\"https://members.ithemes.com/panel/helpdesk.php\">iThemes Helpdesk</a> for help. Our support team answers questions Monday – Friday, 8am – 5pm (CST).</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"security-guide\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table id=\"security-guide-container\" class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border: 1px solid #CDCECE;background-color: #D3E8E9;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"104\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"section-padding-bottom\" align=\"left\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/wp_security_book.png\" style=\"max-width: 84px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"84\" alt=\"\" align=\"center\">
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"454\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #6C6C6C;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: left;padding-bottom: 20px;\">
											<h4 style=\"color: #6C6C6C;font-family: Helvetica;font-size: 18px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: left;padding-bottom: 10px;\">Free WordPress Security Guide</h4>
											Learn simple WordPress security tips — including 3 kinds of security your site needs and 4 best security practices for keeping your WordPress site safe with our <a href=\"https://ithemes.com/publishing/wordpress-security/\">free guide</a>.
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"footer-source-details\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 200%;text-align: center;padding-bottom: 0;padding-top: 60px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/footer_logo.png\" style=\"max-width: 50px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"50\" alt=\"\" align=\"center\"><br>
											<br>
											<span style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #666f72;font-family: Helvetica;font-size: 11px;line-height: 200%;text-align: center;text-decoration: none;font-weight: bold;\">
												This email was generated by the iThemes Security plugin.<br>To unsubscribe from these updates, visit the <a href=\"http://hack.africa/wp-admin/admin.php?page=itsec\" style=\"color: #0084CB\">Settings page</a> in the iThemes Security plugin menu.
											</span>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>					</table>
				</td>
			</tr>
		</table>
	</center>
</body>

</html>
\";s:7:\"headers\";a:0:{}s:11:\"attachments\";a:1:{i:0;s:131:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups/backup-afrihack-20181124-100550-RDpgqWy3YloTU3RzjrSMI16Gjh1nL6.zip\";}s:24:\"phpmailer_exception_code\";i:2;}}}}","error","2018-11-24 10:05:51","2018-11-24 10:05:50","7090736","9414464","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("7","0","backup","email-failed-file-stored","a:3:{s:8:\"settings\";a:9:{s:9:\"all_sites\";b:1;s:6:\"method\";i:0;s:8:\"location\";s:64:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:2:{i:0;s:14:\"itsec_lockouts\";i:1;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:8:\"last_run\";i:0;}s:12:\"mail_success\";b:0;s:4:\"file\";s:131:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups/backup-afrihack-20181124-100550-RDpgqWy3YloTU3RzjrSMI16Gjh1nL6.sql\";}","warning","2018-11-24 10:05:51","2018-11-24 10:05:50","7010448","9414464","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("8","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:7:\"uploads\";}","process-update","2018-11-24 10:05:51","2018-11-24 10:05:50","7078312","9414464","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("9","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:6:\"themes\";}","process-update","2018-11-24 10:07:04","2018-11-24 10:07:04","6358560","6439576","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("10","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:7:\"plugins\";}","process-update","2018-11-24 10:08:28","2018-11-24 10:08:28","6354488","6402744","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("11","1","file_change","scan","a:2:{s:6:\"status\";s:23:\"get_chunk_files_plugins\";s:8:\"excludes\";a:0:{}}","process-update","2018-11-24 10:08:28","2018-11-24 10:08:28","6374976","6412192","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("12","1","file_change","scan","a:2:{s:6:\"status\";s:31:\"get_chunk_files_plugins_scanned\";s:7:\"scanned\";a:8:{s:68:\"/var/www/hack.africa/wp-content/plugins/social-media-buttons-toolbar\";i:1;s:67:\"/var/www/hack.africa/wp-content/plugins/modern-events-calendar-lite\";i:1;s:54:\"/var/www/hack.africa/wp-content/plugins/contact-form-7\";i:1;s:58:\"/var/www/hack.africa/wp-content/plugins/better-wp-security\";i:1;s:47:\"/var/www/hack.africa/wp-content/plugins/akismet\";i:1;s:64:\"/var/www/hack.africa/wp-content/plugins/velvet-blues-update-urls\";i:1;s:48:\"/var/www/hack.africa/wp-content/plugins/flamingo\";i:1;s:49:\"/var/www/hack.africa/wp-content/plugins/index.php\";i:1;}}","process-update","2018-11-24 10:08:29","2018-11-24 10:08:28","6981552","7028752","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("13","1","file_change","scan","a:2:{s:6:\"status\";s:15:\"get_chunk_files\";s:5:\"chunk\";s:6:\"others\";}","process-update","2018-11-24 10:09:31","2018-11-24 10:09:30","6358584","6402896","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("14","1","file_change","scan","a:1:{s:6:\"status\";s:18:\"file_scan_complete\";}","process-update","2018-11-24 10:09:31","2018-11-24 10:09:30","6833112","7670024","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("15","1","file_change","scan","a:3:{s:6:\"status\";s:22:\"file_comparisons_start\";s:8:\"excludes\";a:0:{}s:5:\"types\";a:39:{s:4:\".log\";i:0;s:3:\".mo\";i:1;s:3:\".po\";i:2;s:4:\".bmp\";i:3;s:4:\".gif\";i:4;s:4:\".ico\";i:5;s:4:\".jpe\";i:6;s:5:\".jpeg\";i:7;s:4:\".jpg\";i:8;s:4:\".png\";i:9;s:4:\".psd\";i:10;s:4:\".raw\";i:11;s:4:\".svg\";i:12;s:4:\".tif\";i:13;s:5:\".tiff\";i:14;s:4:\".aif\";i:15;s:5:\".flac\";i:16;s:4:\".m4a\";i:17;s:4:\".mp3\";i:18;s:4:\".oga\";i:19;s:4:\".ogg\";i:20;s:3:\".ra\";i:22;s:4:\".wav\";i:23;s:4:\".wma\";i:24;s:4:\".asf\";i:25;s:4:\".avi\";i:26;s:4:\".mkv\";i:27;s:4:\".mov\";i:28;s:4:\".mp4\";i:29;s:4:\".mpe\";i:30;s:5:\".mpeg\";i:31;s:4:\".mpg\";i:32;s:4:\".ogv\";i:33;s:3:\".qt\";i:34;s:3:\".rm\";i:35;s:4:\".vob\";i:36;s:5:\".webm\";i:37;s:3:\".wm\";i:38;s:4:\".wmv\";i:39;}}","process-update","2018-11-24 10:10:45","2018-11-24 10:10:45","6356192","6397856","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("16","1","file_change","scan","a:1:{s:6:\"status\";s:25:\"file_comparisons_complete\";}","process-update","2018-11-24 10:10:45","2018-11-24 10:10:45","8346616","8659344","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("17","1","file_change","scan","a:1:{s:6:\"status\";s:22:\"hash_comparisons_start\";}","process-update","2018-11-24 10:11:46","2018-11-24 10:11:45","6353200","6397856","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("18","1","file_change","scan","a:1:{s:6:\"status\";s:25:\"hash_comparisons_complete\";}","process-update","2018-11-24 10:11:46","2018-11-24 10:11:45","8132024","9221472","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("19","0","file_change","attempting-recovery","a:1:{s:7:\"storage\";a:7:{s:4:\"step\";s:12:\"check-hashes\";s:5:\"chunk\";s:6:\"others\";s:2:\"id\";s:11:\"file-change\";s:4:\"data\";a:4:{s:4:\"step\";s:9:\"get-files\";s:5:\"chunk\";s:5:\"admin\";s:10:\"loop_start\";i:1543053545;s:9:\"loop_item\";i:1;}s:6:\"memory\";i:9414464;s:11:\"memory_peak\";i:9414464;s:12:\"health_check\";i:1543054305;}}","debug","2018-11-24 10:24:52","2018-11-24 10:24:52","6317384","6349392","http://hack.africa/wp-admin/plugins.php?activate-multi=true&plugin_status=all&paged=1&s=","1","1","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("20","0","file_change","recovery-failed-first-loop","b:0;","debug","2018-11-24 10:24:52","2018-11-24 10:24:52","6324344","6365080","http://hack.africa/wp-admin/plugins.php?activate-multi=true&plugin_status=all&paged=1&s=","1","1","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("21","1","file_change","scan","a:1:{s:7:\"aborted\";b:1;}","process-stop","2018-11-24 10:24:52","2018-11-24 10:24:52","6349320","6404208","http://hack.africa/wp-admin/plugins.php?activate-multi=true&plugin_status=all&paged=1&s=","1","1","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("22","0","file_change","file-scan-aborted","a:3:{s:2:\"id\";s:11:\"file-change\";s:4:\"step\";s:12:\"check-hashes\";s:5:\"chunk\";s:6:\"others\";}","fatal","2018-11-24 10:24:52","2018-11-24 10:24:52","6332792","6404208","http://hack.africa/wp-admin/plugins.php?activate-multi=true&plugin_status=all&paged=1&s=","1","1","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("23","0","notification_center","send::hide-backend","a:2:{s:10:\"recipients\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:45:\"[hack.africa] WordPress Login Address Changed\";}","debug","2018-11-24 10:29:04","2018-11-24 10:29:04","7207128","7244432","http://hack.africa/wp-admin/admin-ajax.php","1","2","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("24","0","notification_center","send_failed::hide-backend","a:1:{s:5:\"error\";O:8:\"WP_Error\":2:{s:6:\"errors\";a:1:{s:14:\"wp_mail_failed\";a:1:{i:0;s:36:\"Could not instantiate mail function.\";}}s:10:\"error_data\";a:1:{s:14:\"wp_mail_failed\";a:6:{s:2:\"to\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:45:\"[hack.africa] WordPress Login Address Changed\";s:7:\"message\";s:44903:\"
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\">

<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
	<title>New Login URL</title>
	<meta name=\"viewport\" content=\"width=device-width\">

	<style type=\"text/css\">
		/* From: https://litmus.com/community/learning/13-foundations-email-coding-101 */

		/* GENERAL STYLE RESETS */
		body,#body-table,#body-cell{height:100%!important;width:100%!important;margin:0;padding:0;}
		img,aimg{border:0;outline:none;text-decoration:none;}
		.imageFix{display:block;}
		table,td{border-collapse:collapse;border-spacing:0;}

		/* CLIENT-SPECIFIC RESETS */
		.ReadMsgBody{width:100%;}
		.ExternalClass{width:100%;}
		.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:100%;}
		table,td{mso-table-lspace:0pt;mso-table-rspace:0pt;}
		img{-ms-interpolation-mode:bicubic;}
		body,table,td,p,a,li,blockquote{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;}


		h1,h2,h3,h4,h5,h6{color:#202020;font-family:Helvetica;font-size:20px;font-weight:bold;line-height:150%;margin:0;padding:0;text-align:center;}
		p{font-family:Helvetica;font-size:16px;line-height:150%;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;padding:0;text-align:center;}
		a{color:#0084CB;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;text-decoration:none;}
		img{height:auto;}

		body,#body-table{background-color:#FFFFFF;}
		#body-cell{padding-bottom:20px;}
		.section-padding{padding-top:20px;padding-right:20px;padding-left:20px;}
		.section-padding-bottom{padding-bottom:20px;}
		.container-cell{color:#808080;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;padding-bottom:20px;}
		#top-banner{background-color:#FFCE08;}
		#top-banner .container-cell{color:#413F39;font-size:13px;}
		#top-logo .container-cell{padding-top:20px;}
		#title-container h1{font-size:34px;}
		.info-box{padding-top:20px;padding-bottom:20px;}
		.info-box .container{border:1px solid #CDCECE;background-color:#F2F2F2;}
		.info-box .section-padding{padding-top:40px;padding-right:40px;padding-left:40px;}
		.info-box .container-cell{padding-bottom:40px;}
		.info-box .info-icon{width:33px;height:23px;vertical-align:middle;}
		.section-heading .container-cell{padding-bottom:0;}
		.section-heading h4{color:#0084CB;font-size:16px;}
		.section-heading h4 img{padding-top:2px;padding-right:5px;vertical-align:top;}
		.lockouts-summary .container.left-column{margin-right:60px;}
		.lockouts-summary h4{color:#ACAAAA;font-size:16px;font-weight:normal;}
		.lockouts-summary p{color:#505050;font-size:30px;font-weight:bold;}
		.table{border:1px solid #cdcece;color: #808080;font-family:Helvetica;font-size:14px;}
		.table th,.table td{border:1px solid #cdcece;padding:10px;}
		.table th{text-align:left;font-weight:bold;padding:5px 10px;}
		.table .row-label{font-style:italic;}
		.table a,.table b{font-size:14px;}
		.large-text h4{color:#505050;margin-bottom:10px;}
		.details-box-container{padding-top:20px;padding-bottom:20px;}
		.details-box{background-color:#E4EEF7;border:1px solid #CDCECE;}
		.details-box .container-cell{color:#6A6A6A;}
		.divider .divider-border{border-top-width:1px;border-top-style:solid;border-top-color:#E8E8E8;}
		.divider .container-cell{line-height:1px;padding-bottom:20px;width:450px;}
		.module-button .border-radius{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;}
		.module-button a{background-color:#FFCD08;border:1px solid #FFCD08;color:#2E280E;display:inline-block;font-size:18px;font-weight:bold;line-height:100%;padding-top:20px;padding-right:30px;padding-bottom:20px;padding-left:30px;}
		.pro-callout{padding-top:20px;}
		.pro-callout-background{background-color:#0B1A23;}
		.pro-callout .section-padding{padding-top:40px;}
		.pro-callout .two-factor{color:#FFFFFF;margin-top:20px;margin-bottom:20px;}
		.pro-callout .module-button a{font-size:30px;}
		.pro-callout .why-pro{color:#999999;font-style:italic;margin-top:20px;margin-bottom:20px;}
		.footer-heading h2{color:#002030;font-size:26px;}
		.pro-flag{background-color:#FFCC00;color:#000000;font-size:10px;display:inline-block;padding:3px;line-height:1;position:relative;bottom:10px;text-transform:uppercase;}
		#security-guide-container{border:1px solid #CDCECE;background-color:#D3E8E9;}
		#security-guide .container-cell{color:#6C6C6C;text-align:left;}
		#security-guide h4{color:#6C6C6C;font-size:18px;padding-bottom:10px;text-align:left;}
		#security-guide a{font-weight:bold;}
		#footer-source-details .container-cell{line-height:200%;padding-top:60px;padding-bottom:0;}
		#footer-source-details a{font-size:11px;font-weight:bold;line-height:200%;}
		.template-container {max-width: 600px !important;}

		@media only screen and (max-width:600px){
			body{width:100% !important;min-width:100% !important;}
			#body-cell{padding:10px !important;}
			#main-container, .container{width:100% !important;}
			.preserve-ratio{height:auto !important;width:100% !important;}
			.container-cell-bottom{padding-top:20px !important;}
			.lockouts-summary .container{width:auto !important;}
		}

		@media only screen and (max-width:450px){
			.divider .container-cell{width:auto !important;}
		}
	</style>
</head>

<body style=\"margin: 0;padding: 0;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
	<center>
		<table id=\"body-table\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
			<tr>
				<td id=\"body-cell\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;padding-bottom: 20px;height: 100%!important;width: 100%!important;\">
					<table id=\"main-container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td id=\"top-banner\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFCE08;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #413F39;font-family: Helvetica;font-size: 13px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	New Login URL
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"top-logo\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;padding-top: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/logo.png\" style=\"max-width: 300px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" alt=\"\" align=\"center\">
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"title-container\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<h1 style=\"color: #202020;font-family: Helvetica;font-size: 34px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">New Login URL</h1>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<p>The login address for Afrihack has changed. The new login address is <code>http://hack.africa/ha_login</code>. You will be unable to use the old login address.</p>

																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding section-padding-bottom\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;padding-bottom: 20px;\">
								<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"module-button\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"border-radius\" align=\"center\" bgcolor=\"#FFCD08\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">
														<a class=\"border-radius\" href=\"http://hack.africa/ha_login\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #2E280E;font-family: Helvetica;font-size: 18px;line-height: 100%;text-align: center;text-decoration: none;background-color: #FFCD08;border: 1px solid #FFCD08;display: inline-block;font-weight: bold;padding-top: 20px;padding-right: 30px;padding-bottom: 20px;padding-left: 30px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">Login Now</a>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
						<tr>
							<td class=\"pro-callout\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;\">
								<table class=\"pro-callout-background\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #0B1A23;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" class=\"container\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td align=\"center\" valign=\"top\" width=\"600\" class=\"section-padding\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 40px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td valign=\"top\" class=\"container-cell\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/pro_logo_no_text.png\" style=\"max-width: 100px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"100\" alt=\"\" align=\"center\">
																	<p class=\"two-factor\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #FFFFFF;\">Want two-factor authentication, scheduled malware scanning, ticketed support and more?</p>
																	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																		<tr>
																			<td style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																				<table class=\"module-button\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																					<tr>
																						<td class=\"border-radius\" align=\"center\" bgcolor=\"#FFCD08\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">
																							<a href=\"https://ithemes.com/security/#plugin-pricing\" target=\"_blank\" class=\"border-radius\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #2E280E;font-family: Helvetica;font-size: 30px;line-height: 100%;text-align: center;text-decoration: none;background-color: #FFCD08;border: 1px solid #FFCD08;display: inline-block;font-weight: bold;padding-top: 20px;padding-right: 30px;padding-bottom: 20px;padding-left: 30px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">Get iThemes Security Pro</a>
																						</td>
																					</tr>
																				</table>
																			</td>
																		</tr>
																	</table>
																	<p class=\"why-pro\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #999999;font-style: italic;\">Why go Pro? <a href=\"https://ithemes.com/security/why-go-pro/\">Check out the Free/Pro comparison chart.</a></p>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Security Resources</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/article_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/category/wordpress-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Articles</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read the latest in WordPress Security news, tips, and updates on <a href=\"https://ithemes.com/category/wordpress-security/\">iThemes Blog</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/video_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/tutorial/category/ithemes-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Tutorials</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Make the most of iThemes Security features with our <a href=\"https://ithemes.com/tutorial/category/ithemes-security/\">free iThemes Security tutorials</a>.</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"divider\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"divider-border\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border-top-width: 1px;border-top-style: solid;border-top-color: #E8E8E8;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 1px;text-align: center;padding-bottom: 20px;width: 450px;\">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Help &amp; Support</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/documentation_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"http://ithemes.com/codex/page/IThemes_Security\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Documentation</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read iThemes Security documentation and Frequently Asked Questions on <a href=\"http://ithemes.com/codex/page/IThemes_Security\">the Codex</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/support_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://members.ithemes.com/panel/helpdesk.php\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Support</a>
												<span class=\"pro-flag\" style=\"background-color: #FFCC00;color: #000000;font-size: 10px;display: inline-block;padding: 3px;line-height: 1;position: relative;bottom: 10px;text-transform: uppercase;\">Pro</span>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Pro customers can contact <a href=\"https://members.ithemes.com/panel/helpdesk.php\">iThemes Helpdesk</a> for help. Our support team answers questions Monday – Friday, 8am – 5pm (CST).</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"security-guide\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table id=\"security-guide-container\" class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border: 1px solid #CDCECE;background-color: #D3E8E9;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"104\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"section-padding-bottom\" align=\"left\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/wp_security_book.png\" style=\"max-width: 84px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"84\" alt=\"\" align=\"center\">
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"454\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #6C6C6C;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: left;padding-bottom: 20px;\">
											<h4 style=\"color: #6C6C6C;font-family: Helvetica;font-size: 18px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: left;padding-bottom: 10px;\">Free WordPress Security Guide</h4>
											Learn simple WordPress security tips — including 3 kinds of security your site needs and 4 best security practices for keeping your WordPress site safe with our <a href=\"https://ithemes.com/publishing/wordpress-security/\">free guide</a>.
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"footer-source-details\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 200%;text-align: center;padding-bottom: 0;padding-top: 60px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/footer_logo.png\" style=\"max-width: 50px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"50\" alt=\"\" align=\"center\"><br>
											<br>
											<span style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #666f72;font-family: Helvetica;font-size: 11px;line-height: 200%;text-align: center;text-decoration: none;font-weight: bold;\">
												This email was generated by the iThemes Security plugin.<br>To unsubscribe from these updates, visit the <a href=\"http://hack.africa/wp-admin/admin.php?page=itsec\" style=\"color: #0084CB\">Settings page</a> in the iThemes Security plugin menu.
											</span>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>					</table>
				</td>
			</tr>
		</table>
	</center>
</body>

</html>
\";s:7:\"headers\";a:0:{}s:11:\"attachments\";a:0:{}s:24:\"phpmailer_exception_code\";i:2;}}}}","error","2018-11-24 10:29:04","2018-11-24 10:29:04","7352688","7352944","http://hack.africa/wp-admin/admin-ajax.php","1","2","197.251.185.254");
INSERT INTO `afhwp_itsec_logs` VALUES ("25","0","notification_center","send::backup","a:2:{s:10:\"recipients\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:29:\"[hack.africa] Database Backup\";}","debug","2018-11-24 10:49:30","2018-11-24 10:49:30","6601872","9406232","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("26","0","notification_center","send_failed::backup","a:1:{s:5:\"error\";O:8:\"WP_Error\":2:{s:6:\"errors\";a:1:{s:14:\"wp_mail_failed\";a:1:{i:0;s:36:\"Could not instantiate mail function.\";}}s:10:\"error_data\";a:1:{s:14:\"wp_mail_failed\";a:6:{s:2:\"to\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";s:29:\"[hack.africa] Database Backup\";s:7:\"message\";s:50819:\"
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\">

<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
	<title>Database Backup</title>
	<meta name=\"viewport\" content=\"width=device-width\">

	<style type=\"text/css\">
		/* From: https://litmus.com/community/learning/13-foundations-email-coding-101 */

		/* GENERAL STYLE RESETS */
		body,#body-table,#body-cell{height:100%!important;width:100%!important;margin:0;padding:0;}
		img,aimg{border:0;outline:none;text-decoration:none;}
		.imageFix{display:block;}
		table,td{border-collapse:collapse;border-spacing:0;}

		/* CLIENT-SPECIFIC RESETS */
		.ReadMsgBody{width:100%;}
		.ExternalClass{width:100%;}
		.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:100%;}
		table,td{mso-table-lspace:0pt;mso-table-rspace:0pt;}
		img{-ms-interpolation-mode:bicubic;}
		body,table,td,p,a,li,blockquote{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;}


		h1,h2,h3,h4,h5,h6{color:#202020;font-family:Helvetica;font-size:20px;font-weight:bold;line-height:150%;margin:0;padding:0;text-align:center;}
		p{font-family:Helvetica;font-size:16px;line-height:150%;margin-top:10px;margin-right:0;margin-bottom:10px;margin-left:0;padding:0;text-align:center;}
		a{color:#0084CB;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;text-decoration:none;}
		img{height:auto;}

		body,#body-table{background-color:#FFFFFF;}
		#body-cell{padding-bottom:20px;}
		.section-padding{padding-top:20px;padding-right:20px;padding-left:20px;}
		.section-padding-bottom{padding-bottom:20px;}
		.container-cell{color:#808080;font-family:Helvetica;font-size:16px;line-height:150%;text-align:center;padding-bottom:20px;}
		#top-banner{background-color:#FFCE08;}
		#top-banner .container-cell{color:#413F39;font-size:13px;}
		#top-logo .container-cell{padding-top:20px;}
		#title-container h1{font-size:34px;}
		.info-box{padding-top:20px;padding-bottom:20px;}
		.info-box .container{border:1px solid #CDCECE;background-color:#F2F2F2;}
		.info-box .section-padding{padding-top:40px;padding-right:40px;padding-left:40px;}
		.info-box .container-cell{padding-bottom:40px;}
		.info-box .info-icon{width:33px;height:23px;vertical-align:middle;}
		.section-heading .container-cell{padding-bottom:0;}
		.section-heading h4{color:#0084CB;font-size:16px;}
		.section-heading h4 img{padding-top:2px;padding-right:5px;vertical-align:top;}
		.lockouts-summary .container.left-column{margin-right:60px;}
		.lockouts-summary h4{color:#ACAAAA;font-size:16px;font-weight:normal;}
		.lockouts-summary p{color:#505050;font-size:30px;font-weight:bold;}
		.table{border:1px solid #cdcece;color: #808080;font-family:Helvetica;font-size:14px;}
		.table th,.table td{border:1px solid #cdcece;padding:10px;}
		.table th{text-align:left;font-weight:bold;padding:5px 10px;}
		.table .row-label{font-style:italic;}
		.table a,.table b{font-size:14px;}
		.large-text h4{color:#505050;margin-bottom:10px;}
		.details-box-container{padding-top:20px;padding-bottom:20px;}
		.details-box{background-color:#E4EEF7;border:1px solid #CDCECE;}
		.details-box .container-cell{color:#6A6A6A;}
		.divider .divider-border{border-top-width:1px;border-top-style:solid;border-top-color:#E8E8E8;}
		.divider .container-cell{line-height:1px;padding-bottom:20px;width:450px;}
		.module-button .border-radius{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;}
		.module-button a{background-color:#FFCD08;border:1px solid #FFCD08;color:#2E280E;display:inline-block;font-size:18px;font-weight:bold;line-height:100%;padding-top:20px;padding-right:30px;padding-bottom:20px;padding-left:30px;}
		.pro-callout{padding-top:20px;}
		.pro-callout-background{background-color:#0B1A23;}
		.pro-callout .section-padding{padding-top:40px;}
		.pro-callout .two-factor{color:#FFFFFF;margin-top:20px;margin-bottom:20px;}
		.pro-callout .module-button a{font-size:30px;}
		.pro-callout .why-pro{color:#999999;font-style:italic;margin-top:20px;margin-bottom:20px;}
		.footer-heading h2{color:#002030;font-size:26px;}
		.pro-flag{background-color:#FFCC00;color:#000000;font-size:10px;display:inline-block;padding:3px;line-height:1;position:relative;bottom:10px;text-transform:uppercase;}
		#security-guide-container{border:1px solid #CDCECE;background-color:#D3E8E9;}
		#security-guide .container-cell{color:#6C6C6C;text-align:left;}
		#security-guide h4{color:#6C6C6C;font-size:18px;padding-bottom:10px;text-align:left;}
		#security-guide a{font-weight:bold;}
		#footer-source-details .container-cell{line-height:200%;padding-top:60px;padding-bottom:0;}
		#footer-source-details a{font-size:11px;font-weight:bold;line-height:200%;}
		.template-container {max-width: 600px !important;}

		@media only screen and (max-width:600px){
			body{width:100% !important;min-width:100% !important;}
			#body-cell{padding:10px !important;}
			#main-container, .container{width:100% !important;}
			.preserve-ratio{height:auto !important;width:100% !important;}
			.container-cell-bottom{padding-top:20px !important;}
			.lockouts-summary .container{width:auto !important;}
		}

		@media only screen and (max-width:450px){
			.divider .container-cell{width:auto !important;}
		}
	</style>
</head>

<body style=\"margin: 0;padding: 0;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
	<center>
		<table id=\"body-table\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;background-color: #FFFFFF;height: 100%!important;width: 100%!important;\">
			<tr>
				<td id=\"body-cell\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;margin: 0;padding: 0;padding-bottom: 20px;height: 100%!important;width: 100%!important;\">
					<table id=\"main-container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td id=\"top-banner\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #FFCE08;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #413F39;font-family: Helvetica;font-size: 13px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	Site Database Backup for <b>November 24, 2018</b>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"top-logo\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;padding-top: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/logo.png\" style=\"max-width: 300px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" alt=\"\" align=\"center\">
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td id=\"title-container\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<h1 style=\"color: #202020;font-family: Helvetica;font-size: 34px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Database Backup</h1>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"info-box\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-bottom: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border: 1px solid #CDCECE;background-color: #F2F2F2;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 40px;padding-right: 40px;padding-left: 40px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 40px;\">
																	<img class=\"info-icon\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/attachment_icon.png\" alt=\"\" align=\"center\" width=\"33\" height=\"23\" style=\"border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: 23px;width: 33px;vertical-align: middle;\">
																	Attached is the database backup file for your site.
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"section-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 0;\">
																	<h4 style=\"color: #0084CB;font-family: Helvetica;font-size: 16px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
																		Website
																	</h4>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	hack.africa
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"section-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 0;\">
																	<h4 style=\"color: #0084CB;font-family: Helvetica;font-size: 16px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
																		Date
																	</h4>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	November 24, 2018
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td class=\"pro-callout\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;\">
								<table class=\"pro-callout-background\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background-color: #0B1A23;\">
									<tr>
										<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
											<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" class=\"container\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
												<tr>
													<td align=\"center\" valign=\"top\" width=\"600\" class=\"section-padding\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 40px;padding-right: 20px;padding-left: 20px;\">
														<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
															<tr>
																<td valign=\"top\" class=\"container-cell\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
																	<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/pro_logo_no_text.png\" style=\"max-width: 100px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"100\" alt=\"\" align=\"center\">
																	<p class=\"two-factor\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #FFFFFF;\">Want two-factor authentication, scheduled malware scanning, ticketed support and more?</p>
																	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																		<tr>
																			<td style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																				<table class=\"module-button\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
																					<tr>
																						<td class=\"border-radius\" align=\"center\" bgcolor=\"#FFCD08\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">
																							<a href=\"https://ithemes.com/security/#plugin-pricing\" target=\"_blank\" class=\"border-radius\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #2E280E;font-family: Helvetica;font-size: 30px;line-height: 100%;text-align: center;text-decoration: none;background-color: #FFCD08;border: 1px solid #FFCD08;display: inline-block;font-weight: bold;padding-top: 20px;padding-right: 30px;padding-bottom: 20px;padding-left: 30px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;\">Get iThemes Security Pro</a>
																						</td>
																					</tr>
																				</table>
																			</td>
																		</tr>
																	</table>
																	<p class=\"why-pro\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 20px;margin-right: 0;margin-bottom: 20px;margin-left: 0;padding: 0;text-align: center;color: #999999;font-style: italic;\">Why go Pro? <a href=\"https://ithemes.com/security/why-go-pro/\">Check out the Free/Pro comparison chart.</a></p>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Security Resources</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/article_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/category/wordpress-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Articles</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read the latest in WordPress Security news, tips, and updates on <a href=\"https://ithemes.com/category/wordpress-security/\">iThemes Blog</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/video_icon.png\" style=\"max-width: 61px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"61\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://ithemes.com/tutorial/category/ithemes-security/\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Tutorials</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Make the most of iThemes Security features with our <a href=\"https://ithemes.com/tutorial/category/ithemes-security/\">free iThemes Security tutorials</a>.</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"divider\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"450\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"divider-border\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border-top-width: 1px;border-top-style: solid;border-top-color: #E8E8E8;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 1px;text-align: center;padding-bottom: 20px;width: 450px;\">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td class=\"footer-heading\" align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<h2 style=\"color: #002030;font-family: Helvetica;font-size: 26px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">Help &amp; Support</h2>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/documentation_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"http://ithemes.com/codex/page/IThemes_Security\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Documentation</a>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Read iThemes Security documentation and Frequently Asked Questions on <a href=\"http://ithemes.com/codex/page/IThemes_Security\">the Codex</a>.</p>
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"260\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell container-cell-bottom\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/support_icon.png\" style=\"max-width: 62px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"62\" alt=\"\" align=\"center\">
											<br>
											<h4 style=\"color: #202020;font-family: Helvetica;font-size: 20px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: center;\">
												<a href=\"https://members.ithemes.com/panel/helpdesk.php\" target=\"_blank\" style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #0084CB;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: center;text-decoration: none;\">Support</a>
												<span class=\"pro-flag\" style=\"background-color: #FFCC00;color: #000000;font-size: 10px;display: inline-block;padding: 3px;line-height: 1;position: relative;bottom: 10px;text-transform: uppercase;\">Pro</span>
											</h4>
											<br>
											<p style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-family: Helvetica;font-size: 16px;line-height: 150%;margin-top: 10px;margin-right: 0;margin-bottom: 10px;margin-left: 0;padding: 0;text-align: center;\">Pro customers can contact <a href=\"https://members.ithemes.com/panel/helpdesk.php\">iThemes Helpdesk</a> for help. Our support team answers questions Monday – Friday, 8am – 5pm (CST).</p>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"security-guide\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table id=\"security-guide-container\" class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;border: 1px solid #CDCECE;background-color: #D3E8E9;\">
						<tr>
							<td class=\"section-padding\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table class=\"container\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"104\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"section-padding-bottom\" align=\"left\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-bottom: 20px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/wp_security_book.png\" style=\"max-width: 84px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"84\" alt=\"\" align=\"center\">
										</td>
									</tr>
								</table>
								<table class=\"container\" align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"454\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #6C6C6C;font-family: Helvetica;font-size: 16px;line-height: 150%;text-align: left;padding-bottom: 20px;\">
											<h4 style=\"color: #6C6C6C;font-family: Helvetica;font-size: 18px;font-weight: bold;line-height: 150%;margin: 0;padding: 0;text-align: left;padding-bottom: 10px;\">Free WordPress Security Guide</h4>
											Learn simple WordPress security tips — including 3 kinds of security your site needs and 4 best security practices for keeping your WordPress site safe with our <a href=\"https://ithemes.com/publishing/wordpress-security/\">free guide</a>.
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td id=\"footer-source-details\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
			<tr>
				<td align=\"center\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
					<table class=\"container\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
						<tr>
							<td class=\"section-padding\" align=\"center\" valign=\"top\" width=\"600\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;padding-top: 20px;padding-right: 20px;padding-left: 20px;\">
								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;\">
									<tr>
										<td class=\"container-cell\" valign=\"top\" style=\"border-collapse: collapse;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #808080;font-family: Helvetica;font-size: 16px;line-height: 200%;text-align: center;padding-bottom: 0;padding-top: 60px;\">
											<img class=\"preserve-ratio\" src=\"http://hack.africa/wp-content/plugins/better-wp-security/core/img/mail/footer_logo.png\" style=\"max-width: 50px;border: 0;outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;height: auto;\" width=\"50\" alt=\"\" align=\"center\"><br>
											<br>
											<span style=\"-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #666f72;font-family: Helvetica;font-size: 11px;line-height: 200%;text-align: center;text-decoration: none;font-weight: bold;\">
												This email was generated by the iThemes Security plugin.<br>To unsubscribe from these updates, visit the <a href=\"http://hack.africa/wp-admin/admin.php?page=itsec&#038;itsec-hb-token=ha_login\" style=\"color: #0084CB\">Settings page</a> in the iThemes Security plugin menu.
											</span>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>					</table>
				</td>
			</tr>
		</table>
	</center>
</body>

</html>
\";s:7:\"headers\";a:0:{}s:11:\"attachments\";a:1:{i:0;s:131:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups/backup-afrihack-20181124-104930-S9AMdJUDNEDq0iOd72dwND8N4qq9X1.zip\";}s:24:\"phpmailer_exception_code\";i:2;}}}}","error","2018-11-24 10:49:30","2018-11-24 10:49:30","7103824","9406232","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("27","0","backup","email-failed-file-stored","a:3:{s:8:\"settings\";a:9:{s:9:\"all_sites\";b:1;s:6:\"method\";i:0;s:8:\"location\";s:64:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:2:{i:0;s:14:\"itsec_lockouts\";i:1;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:8:\"last_run\";i:1543053950;}s:12:\"mail_success\";b:0;s:4:\"file\";s:131:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups/backup-afrihack-20181124-104930-S9AMdJUDNEDq0iOd72dwND8N4qq9X1.sql\";}","warning","2018-11-24 10:49:30","2018-11-24 10:49:30","7028232","9406232","wp-cron","1","0","127.0.0.1");
INSERT INTO `afhwp_itsec_logs` VALUES ("28","0","four_oh_four","found_404","a:1:{s:6:\"SERVER\";a:37:{s:15:\"SERVER_SOFTWARE\";s:22:\"Apache/2.4.29 (Ubuntu)\";s:11:\"REQUEST_URI\";s:8:\"/ads.txt\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:9:\"HTTP_HOST\";s:11:\"hack.africa\";s:15:\"HTTP_CONNECTION\";s:10:\"Keep-Alive\";s:20:\"HTTP_ACCEPT_ENCODING\";s:4:\"gzip\";s:17:\"HTTP_CF_IPCOUNTRY\";s:2:\"FR\";s:20:\"HTTP_X_FORWARDED_FOR\";s:13:\"51.254.101.95\";s:11:\"HTTP_CF_RAY\";s:20:\"47ed01a1a3be69b2-CDG\";s:22:\"HTTP_X_FORWARDED_PROTO\";s:4:\"http\";s:15:\"HTTP_CF_VISITOR\";s:21:\"{\\\"scheme\\\":\\\"http\\\"}\";s:15:\"HTTP_USER_AGENT\";s:66:\"Mozilla/5.0 (Windows NT 10.0; rv:64.0) Gecko/20100101 Firefox/64.0\";s:11:\"HTTP_ACCEPT\";s:63:\"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\";s:20:\"HTTP_ACCEPT_LANGUAGE\";s:14:\"en-US,en;q=0.5\";s:21:\"HTTP_CF_CONNECTING_IP\";s:13:\"51.254.101.95\";s:4:\"PATH\";s:60:\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\";s:16:\"SERVER_SIGNATURE\";s:72:\"<address>Apache/2.4.29 (Ubuntu) Server at hack.africa Port 80</address>
\";s:11:\"SERVER_NAME\";s:11:\"hack.africa\";s:11:\"SERVER_ADDR\";s:14:\"46.101.210.206\";s:11:\"SERVER_PORT\";s:2:\"80\";s:11:\"REMOTE_ADDR\";s:13:\"141.101.69.14\";s:13:\"DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:14:\"REQUEST_SCHEME\";s:4:\"http\";s:14:\"CONTEXT_PREFIX\";s:0:\"\";s:21:\"CONTEXT_DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:12:\"SERVER_ADMIN\";s:24:\"ngunyimacharia@gmail.com\";s:15:\"SCRIPT_FILENAME\";s:30:\"/var/www/hack.africa/index.php\";s:11:\"REMOTE_PORT\";s:5:\"21788\";s:12:\"REDIRECT_URL\";s:8:\"/ads.txt\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.1\";s:14:\"REQUEST_METHOD\";s:3:\"GET\";s:12:\"QUERY_STRING\";s:0:\"\";s:11:\"SCRIPT_NAME\";s:10:\"/index.php\";s:8:\"PHP_SELF\";s:10:\"/index.php\";s:18:\"REQUEST_TIME_FLOAT\";s:14:\"1543074365.735\";s:12:\"REQUEST_TIME\";s:10:\"1543074365\";}}","notice","2018-11-24 15:46:05","2018-11-24 15:46:05","20736280","20736536","http://hack.africa/ads.txt","1","0","51.254.101.95");
INSERT INTO `afhwp_itsec_logs` VALUES ("29","0","four_oh_four","found_404","a:1:{s:6:\"SERVER\";a:35:{s:15:\"SERVER_SOFTWARE\";s:22:\"Apache/2.4.29 (Ubuntu)\";s:11:\"REQUEST_URI\";s:60:\"/.well-known/acme-challenge/PYH35ZQE8ZDKEU5CHYPC-GWE3H6Q0Q2D\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:9:\"HTTP_HOST\";s:11:\"hack.africa\";s:15:\"HTTP_CONNECTION\";s:10:\"Keep-Alive\";s:20:\"HTTP_ACCEPT_ENCODING\";s:4:\"gzip\";s:17:\"HTTP_CF_IPCOUNTRY\";s:2:\"US\";s:20:\"HTTP_X_FORWARDED_FOR\";s:15:\"192.185.129.194\";s:11:\"HTTP_CF_RAY\";s:20:\"47f029c685f25855-DFW\";s:22:\"HTTP_X_FORWARDED_PROTO\";s:4:\"http\";s:15:\"HTTP_CF_VISITOR\";s:21:\"{\\\"scheme\\\":\\\"http\\\"}\";s:15:\"HTTP_USER_AGENT\";s:22:\"Cpanel-HTTP-Client/1.0\";s:21:\"HTTP_CF_CONNECTING_IP\";s:15:\"192.185.129.194\";s:4:\"PATH\";s:60:\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\";s:16:\"SERVER_SIGNATURE\";s:72:\"<address>Apache/2.4.29 (Ubuntu) Server at hack.africa Port 80</address>
\";s:11:\"SERVER_NAME\";s:11:\"hack.africa\";s:11:\"SERVER_ADDR\";s:14:\"46.101.210.206\";s:11:\"SERVER_PORT\";s:2:\"80\";s:11:\"REMOTE_ADDR\";s:13:\"172.69.69.153\";s:13:\"DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:14:\"REQUEST_SCHEME\";s:4:\"http\";s:14:\"CONTEXT_PREFIX\";s:0:\"\";s:21:\"CONTEXT_DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:12:\"SERVER_ADMIN\";s:24:\"ngunyimacharia@gmail.com\";s:15:\"SCRIPT_FILENAME\";s:30:\"/var/www/hack.africa/index.php\";s:11:\"REMOTE_PORT\";s:5:\"60724\";s:12:\"REDIRECT_URL\";s:60:\"/.well-known/acme-challenge/PYH35ZQE8ZDKEU5CHYPC-GWE3H6Q0Q2D\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.1\";s:14:\"REQUEST_METHOD\";s:3:\"GET\";s:12:\"QUERY_STRING\";s:0:\"\";s:11:\"SCRIPT_NAME\";s:10:\"/index.php\";s:8:\"PHP_SELF\";s:10:\"/index.php\";s:18:\"REQUEST_TIME_FLOAT\";s:14:\"1543107467.514\";s:12:\"REQUEST_TIME\";s:10:\"1543107467\";}}","notice","2018-11-25 00:57:48","2018-11-25 00:57:47","20709832","20712936","http://hack.africa/.well-known/acme-challenge/PYH35ZQE8ZDKEU5CHYPC-GWE3H6Q0Q2D","1","0","192.185.129.194");
INSERT INTO `afhwp_itsec_logs` VALUES ("30","0","four_oh_four","found_404","a:1:{s:6:\"SERVER\";a:35:{s:15:\"SERVER_SOFTWARE\";s:22:\"Apache/2.4.29 (Ubuntu)\";s:11:\"REQUEST_URI\";s:60:\"/.well-known/acme-challenge/YAP8P-P10EITA5E99V0QL7MMSRLM_QMP\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:9:\"HTTP_HOST\";s:11:\"hack.africa\";s:15:\"HTTP_CONNECTION\";s:10:\"Keep-Alive\";s:20:\"HTTP_ACCEPT_ENCODING\";s:4:\"gzip\";s:17:\"HTTP_CF_IPCOUNTRY\";s:2:\"US\";s:20:\"HTTP_X_FORWARDED_FOR\";s:15:\"192.185.129.194\";s:11:\"HTTP_CF_RAY\";s:20:\"47f029d373c49af6-DFW\";s:22:\"HTTP_X_FORWARDED_PROTO\";s:4:\"http\";s:15:\"HTTP_CF_VISITOR\";s:21:\"{\\\"scheme\\\":\\\"http\\\"}\";s:15:\"HTTP_USER_AGENT\";s:22:\"Cpanel-HTTP-Client/1.0\";s:21:\"HTTP_CF_CONNECTING_IP\";s:15:\"192.185.129.194\";s:4:\"PATH\";s:60:\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\";s:16:\"SERVER_SIGNATURE\";s:72:\"<address>Apache/2.4.29 (Ubuntu) Server at hack.africa Port 80</address>
\";s:11:\"SERVER_NAME\";s:11:\"hack.africa\";s:11:\"SERVER_ADDR\";s:14:\"46.101.210.206\";s:11:\"SERVER_PORT\";s:2:\"80\";s:11:\"REMOTE_ADDR\";s:13:\"172.69.70.220\";s:13:\"DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:14:\"REQUEST_SCHEME\";s:4:\"http\";s:14:\"CONTEXT_PREFIX\";s:0:\"\";s:21:\"CONTEXT_DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:12:\"SERVER_ADMIN\";s:24:\"ngunyimacharia@gmail.com\";s:15:\"SCRIPT_FILENAME\";s:30:\"/var/www/hack.africa/index.php\";s:11:\"REMOTE_PORT\";s:5:\"31450\";s:12:\"REDIRECT_URL\";s:60:\"/.well-known/acme-challenge/YAP8P-P10EITA5E99V0QL7MMSRLM_QMP\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.1\";s:14:\"REQUEST_METHOD\";s:3:\"GET\";s:12:\"QUERY_STRING\";s:0:\"\";s:11:\"SCRIPT_NAME\";s:10:\"/index.php\";s:8:\"PHP_SELF\";s:10:\"/index.php\";s:18:\"REQUEST_TIME_FLOAT\";s:14:\"1543107469.577\";s:12:\"REQUEST_TIME\";s:10:\"1543107469\";}}","notice","2018-11-25 00:57:49","2018-11-25 00:57:49","20695408","20698512","http://hack.africa/.well-known/acme-challenge/YAP8P-P10EITA5E99V0QL7MMSRLM_QMP","1","0","192.185.129.194");
INSERT INTO `afhwp_itsec_logs` VALUES ("31","0","four_oh_four","found_404","a:1:{s:6:\"SERVER\";a:35:{s:15:\"SERVER_SOFTWARE\";s:22:\"Apache/2.4.29 (Ubuntu)\";s:11:\"REQUEST_URI\";s:60:\"/.well-known/acme-challenge/RXJ75QIMO6EKX0OLL0GD0ZS-PK9BA6TT\";s:15:\"REDIRECT_STATUS\";s:3:\"200\";s:9:\"HTTP_HOST\";s:11:\"hack.africa\";s:15:\"HTTP_CONNECTION\";s:10:\"Keep-Alive\";s:20:\"HTTP_ACCEPT_ENCODING\";s:4:\"gzip\";s:17:\"HTTP_CF_IPCOUNTRY\";s:2:\"US\";s:20:\"HTTP_X_FORWARDED_FOR\";s:15:\"192.185.129.194\";s:11:\"HTTP_CF_RAY\";s:20:\"47f029da13a358f7-DFW\";s:22:\"HTTP_X_FORWARDED_PROTO\";s:4:\"http\";s:15:\"HTTP_CF_VISITOR\";s:21:\"{\\\"scheme\\\":\\\"http\\\"}\";s:15:\"HTTP_USER_AGENT\";s:22:\"Cpanel-HTTP-Client/1.0\";s:21:\"HTTP_CF_CONNECTING_IP\";s:15:\"192.185.129.194\";s:4:\"PATH\";s:60:\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\";s:16:\"SERVER_SIGNATURE\";s:72:\"<address>Apache/2.4.29 (Ubuntu) Server at hack.africa Port 80</address>
\";s:11:\"SERVER_NAME\";s:11:\"hack.africa\";s:11:\"SERVER_ADDR\";s:14:\"46.101.210.206\";s:11:\"SERVER_PORT\";s:2:\"80\";s:11:\"REMOTE_ADDR\";s:11:\"172.69.71.5\";s:13:\"DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:14:\"REQUEST_SCHEME\";s:4:\"http\";s:14:\"CONTEXT_PREFIX\";s:0:\"\";s:21:\"CONTEXT_DOCUMENT_ROOT\";s:20:\"/var/www/hack.africa\";s:12:\"SERVER_ADMIN\";s:24:\"ngunyimacharia@gmail.com\";s:15:\"SCRIPT_FILENAME\";s:30:\"/var/www/hack.africa/index.php\";s:11:\"REMOTE_PORT\";s:5:\"13014\";s:12:\"REDIRECT_URL\";s:60:\"/.well-known/acme-challenge/RXJ75QIMO6EKX0OLL0GD0ZS-PK9BA6TT\";s:17:\"GATEWAY_INTERFACE\";s:7:\"CGI/1.1\";s:15:\"SERVER_PROTOCOL\";s:8:\"HTTP/1.1\";s:14:\"REQUEST_METHOD\";s:3:\"GET\";s:12:\"QUERY_STRING\";s:0:\"\";s:11:\"SCRIPT_NAME\";s:10:\"/index.php\";s:8:\"PHP_SELF\";s:10:\"/index.php\";s:18:\"REQUEST_TIME_FLOAT\";s:14:\"1543107470.624\";s:12:\"REQUEST_TIME\";s:10:\"1543107470\";}}","notice","2018-11-25 00:57:50","2018-11-25 00:57:50","20694544","20697648","http://hack.africa/.well-known/acme-challenge/RXJ75QIMO6EKX0OLL0GD0ZS-PK9BA6TT","1","0","192.185.129.194");
INSERT INTO `afhwp_itsec_logs` VALUES ("32","0","notification_center","send_scheduled","a:2:{s:13:\"notifications\";a:1:{i:0;s:6:\"digest\";}s:6:\"silent\";b:0;}","debug","2018-11-25 10:06:41","2018-11-25 10:06:41","6346176","6400512","wp-cron","1","0","127.0.0.1");


CREATE TABLE IF NOT EXISTS `afhwp_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `afhwp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `afhwp_mec_events` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `post_id` int(10) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `repeat` tinyint(4) NOT NULL DEFAULT '0',
  `rinterval` varchar(10) DEFAULT NULL,
  `year` varchar(80) DEFAULT NULL,
  `month` varchar(80) DEFAULT NULL,
  `day` varchar(80) DEFAULT NULL,
  `week` varchar(80) DEFAULT NULL,
  `weekday` varchar(80) DEFAULT NULL,
  `weekdays` varchar(80) DEFAULT NULL,
  `days` text NOT NULL,
  `not_in_days` text NOT NULL,
  `time_start` int(10) NOT NULL DEFAULT '0',
  `time_end` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID` (`id`),
  UNIQUE KEY `post_id` (`post_id`),
  KEY `start` (`start`,`end`,`repeat`,`rinterval`,`year`,`month`,`day`,`week`,`weekday`,`weekdays`,`time_start`,`time_end`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `afhwp_mec_events` VALUES ("1","84","2018-12-12","2018-12-12","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("2","85","2018-12-11","2018-12-11","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("3","86","2018-12-10","2018-12-10","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("4","87","2018-12-08","2018-12-08","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("5","88","2018-12-07","2018-12-07","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("6","134","2018-12-11","2018-12-11","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("7","136","2018-12-13","2018-12-13","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("8","137","2018-12-14","2018-12-14","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("9","138","2018-12-17","2018-12-17","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("10","139","2018-12-18","2018-12-18","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("11","140","2018-12-19","2018-12-19","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("12","141","2018-12-20","2018-12-20","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("13","142","2018-12-21","2018-12-21","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("14","143","2018-12-18","2018-12-19","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("15","144","2018-12-21","2018-12-21","0","","","","","","","","","","61200","64800");
INSERT INTO `afhwp_mec_events` VALUES ("16","145","2018-12-21","2018-12-24","0","","","","","","","","","","28800","64800");
INSERT INTO `afhwp_mec_events` VALUES ("17","147","2018-12-31","2018-12-31","0","","","","","","","","","","28800","61200");
INSERT INTO `afhwp_mec_events` VALUES ("18","174","2018-12-24","2018-12-28","0","","","","","","","","","","28800","64800");


CREATE TABLE IF NOT EXISTS `afhwp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=508 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_options` VALUES ("1","siteurl","http://hack.africa","yes");
INSERT INTO `afhwp_options` VALUES ("2","home","http://hack.africa","yes");
INSERT INTO `afhwp_options` VALUES ("3","blogname","Afrihack","yes");
INSERT INTO `afhwp_options` VALUES ("4","blogdescription","Learning through challenge","yes");
INSERT INTO `afhwp_options` VALUES ("5","users_can_register","0","yes");
INSERT INTO `afhwp_options` VALUES ("6","admin_email","ngunyimacharia@gmail.com","yes");
INSERT INTO `afhwp_options` VALUES ("7","start_of_week","1","yes");
INSERT INTO `afhwp_options` VALUES ("8","use_balanceTags","0","yes");
INSERT INTO `afhwp_options` VALUES ("9","use_smilies","1","yes");
INSERT INTO `afhwp_options` VALUES ("10","require_name_email","1","yes");
INSERT INTO `afhwp_options` VALUES ("11","comments_notify","1","yes");
INSERT INTO `afhwp_options` VALUES ("12","posts_per_rss","10","yes");
INSERT INTO `afhwp_options` VALUES ("13","rss_use_excerpt","0","yes");
INSERT INTO `afhwp_options` VALUES ("14","mailserver_url","mail.example.com","yes");
INSERT INTO `afhwp_options` VALUES ("15","mailserver_login","login@example.com","yes");
INSERT INTO `afhwp_options` VALUES ("16","mailserver_pass","password","yes");
INSERT INTO `afhwp_options` VALUES ("17","mailserver_port","110","yes");
INSERT INTO `afhwp_options` VALUES ("18","default_category","1","yes");
INSERT INTO `afhwp_options` VALUES ("19","default_comment_status","open","yes");
INSERT INTO `afhwp_options` VALUES ("20","default_ping_status","open","yes");
INSERT INTO `afhwp_options` VALUES ("21","default_pingback_flag","1","yes");
INSERT INTO `afhwp_options` VALUES ("22","posts_per_page","10","yes");
INSERT INTO `afhwp_options` VALUES ("23","date_format","F j, Y","yes");
INSERT INTO `afhwp_options` VALUES ("24","time_format","g:i a","yes");
INSERT INTO `afhwp_options` VALUES ("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `afhwp_options` VALUES ("26","comment_moderation","0","yes");
INSERT INTO `afhwp_options` VALUES ("27","moderation_notify","1","yes");
INSERT INTO `afhwp_options` VALUES ("28","permalink_structure","/%postname%/","yes");
INSERT INTO `afhwp_options` VALUES ("29","rewrite_rules","a:162:{s:32:\"(?:checkpoints)/(\\d{4}-\\d{2})/?$\";s:67:\"index.php?post_type=mec-events&MecDisplay=month&MecDate=$matches[1]\";s:29:\"(?:checkpoints)/(?:yearly)/?$\";s:46:\"index.php?post_type=mec-events&MecDisplay=year\";s:30:\"(?:checkpoints)/(?:monthly)/?$\";s:47:\"index.php?post_type=mec-events&MecDisplay=month\";s:29:\"(?:checkpoints)/(?:weekly)/?$\";s:46:\"index.php?post_type=mec-events&MecDisplay=week\";s:28:\"(?:checkpoints)/(?:daily)/?$\";s:45:\"index.php?post_type=mec-events&MecDisplay=day\";s:32:\"(?:checkpoints)/(?:timetable)/?$\";s:51:\"index.php?post_type=mec-events&MecDisplay=timetable\";s:26:\"(?:checkpoints)/(?:map)/?$\";s:45:\"index.php?post_type=mec-events&MecDisplay=map\";s:27:\"(?:checkpoints)/(?:list)/?$\";s:46:\"index.php?post_type=mec-events&MecDisplay=list\";s:27:\"(?:checkpoints)/(?:grid)/?$\";s:46:\"index.php?post_type=mec-events&MecDisplay=grid\";s:29:\"(?:checkpoints)/(?:agenda)/?$\";s:48:\"index.php?post_type=mec-events&MecDisplay=agenda\";s:30:\"(?:checkpoints)/(?:masonry)/?$\";s:49:\"index.php?post_type=mec-events&MecDisplay=masonry\";s:18:\"(?:checkpoints)/?$\";s:49:\"index.php?post_type=mec-events&MecDisplay=default\";s:43:\"(?:checkpoints)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=mec-events&feed=$matches[1]\";s:10:\"project/?$\";s:27:\"index.php?post_type=project\";s:40:\"project/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:35:\"project/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=project&feed=$matches[1]\";s:27:\"project/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=project&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:14:\"checkpoints/?$\";s:30:\"index.php?post_type=mec-events\";s:44:\"checkpoints/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=mec-events&feed=$matches[1]\";s:39:\"checkpoints/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=mec-events&feed=$matches[1]\";s:31:\"checkpoints/page/([0-9]{1,})/?$\";s:48:\"index.php?post_type=mec-events&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"project/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"project/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"project/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"project/([^/]+)/embed/?$\";s:40:\"index.php?project=$matches[1]&embed=true\";s:28:\"project/([^/]+)/trackback/?$\";s:34:\"index.php?project=$matches[1]&tb=1\";s:48:\"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:43:\"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?project=$matches[1]&feed=$matches[2]\";s:36:\"project/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&paged=$matches[2]\";s:43:\"project/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?project=$matches[1]&cpage=$matches[2]\";s:32:\"project/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?project=$matches[1]&page=$matches[2]\";s:24:\"project/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"project/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"project/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:57:\"project_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:52:\"project_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?project_category=$matches[1]&feed=$matches[2]\";s:33:\"project_category/([^/]+)/embed/?$\";s:49:\"index.php?project_category=$matches[1]&embed=true\";s:45:\"project_category/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?project_category=$matches[1]&paged=$matches[2]\";s:27:\"project_category/([^/]+)/?$\";s:38:\"index.php?project_category=$matches[1]\";s:52:\"project_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?project_tag=$matches[1]&feed=$matches[2]\";s:47:\"project_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?project_tag=$matches[1]&feed=$matches[2]\";s:28:\"project_tag/([^/]+)/embed/?$\";s:44:\"index.php?project_tag=$matches[1]&embed=true\";s:40:\"project_tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?project_tag=$matches[1]&paged=$matches[2]\";s:22:\"project_tag/([^/]+)/?$\";s:33:\"index.php?project_tag=$matches[1]\";s:39:\"checkpoints/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"checkpoints/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"checkpoints/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"checkpoints/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"checkpoints/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"checkpoints/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"checkpoints/([^/]+)/embed/?$\";s:43:\"index.php?mec-events=$matches[1]&embed=true\";s:32:\"checkpoints/([^/]+)/trackback/?$\";s:37:\"index.php?mec-events=$matches[1]&tb=1\";s:52:\"checkpoints/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?mec-events=$matches[1]&feed=$matches[2]\";s:47:\"checkpoints/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?mec-events=$matches[1]&feed=$matches[2]\";s:40:\"checkpoints/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?mec-events=$matches[1]&paged=$matches[2]\";s:47:\"checkpoints/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?mec-events=$matches[1]&cpage=$matches[2]\";s:36:\"checkpoints/([^/]+)(?:/([0-9]+))?/?$\";s:49:\"index.php?mec-events=$matches[1]&page=$matches[2]\";s:28:\"checkpoints/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"checkpoints/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"checkpoints/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"checkpoints/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"checkpoints/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"checkpoints/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"mec-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?mec_category=$matches[1]&feed=$matches[2]\";s:48:\"mec-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?mec_category=$matches[1]&feed=$matches[2]\";s:29:\"mec-category/([^/]+)/embed/?$\";s:45:\"index.php?mec_category=$matches[1]&embed=true\";s:41:\"mec-category/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?mec_category=$matches[1]&paged=$matches[2]\";s:23:\"mec-category/([^/]+)/?$\";s:34:\"index.php?mec_category=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=2&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `afhwp_options` VALUES ("30","hack_file","0","yes");
INSERT INTO `afhwp_options` VALUES ("31","blog_charset","UTF-8","yes");
INSERT INTO `afhwp_options` VALUES ("32","moderation_keys","","no");
INSERT INTO `afhwp_options` VALUES ("33","active_plugins","a:7:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"better-wp-security/better-wp-security.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:21:\"flamingo/flamingo.php\";i:4;s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";i:5;s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";i:6;s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";}","yes");
INSERT INTO `afhwp_options` VALUES ("34","category_base","","yes");
INSERT INTO `afhwp_options` VALUES ("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `afhwp_options` VALUES ("36","comment_max_links","2","yes");
INSERT INTO `afhwp_options` VALUES ("37","gmt_offset","0","yes");
INSERT INTO `afhwp_options` VALUES ("38","default_email_category","1","yes");
INSERT INTO `afhwp_options` VALUES ("39","recently_edited","","no");
INSERT INTO `afhwp_options` VALUES ("40","template","Divi","yes");
INSERT INTO `afhwp_options` VALUES ("41","stylesheet","Afrihack","yes");
INSERT INTO `afhwp_options` VALUES ("42","comment_whitelist","1","yes");
INSERT INTO `afhwp_options` VALUES ("43","blacklist_keys","","no");
INSERT INTO `afhwp_options` VALUES ("44","comment_registration","0","yes");
INSERT INTO `afhwp_options` VALUES ("45","html_type","text/html","yes");
INSERT INTO `afhwp_options` VALUES ("46","use_trackback","0","yes");
INSERT INTO `afhwp_options` VALUES ("47","default_role","subscriber","yes");
INSERT INTO `afhwp_options` VALUES ("48","db_version","38590","yes");
INSERT INTO `afhwp_options` VALUES ("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `afhwp_options` VALUES ("50","upload_path","","yes");
INSERT INTO `afhwp_options` VALUES ("51","blog_public","1","yes");
INSERT INTO `afhwp_options` VALUES ("52","default_link_category","2","yes");
INSERT INTO `afhwp_options` VALUES ("53","show_on_front","page","yes");
INSERT INTO `afhwp_options` VALUES ("54","tag_base","","yes");
INSERT INTO `afhwp_options` VALUES ("55","show_avatars","1","yes");
INSERT INTO `afhwp_options` VALUES ("56","avatar_rating","G","yes");
INSERT INTO `afhwp_options` VALUES ("57","upload_url_path","","yes");
INSERT INTO `afhwp_options` VALUES ("58","thumbnail_size_w","150","yes");
INSERT INTO `afhwp_options` VALUES ("59","thumbnail_size_h","150","yes");
INSERT INTO `afhwp_options` VALUES ("60","thumbnail_crop","1","yes");
INSERT INTO `afhwp_options` VALUES ("61","medium_size_w","300","yes");
INSERT INTO `afhwp_options` VALUES ("62","medium_size_h","300","yes");
INSERT INTO `afhwp_options` VALUES ("63","avatar_default","mystery","yes");
INSERT INTO `afhwp_options` VALUES ("64","large_size_w","1024","yes");
INSERT INTO `afhwp_options` VALUES ("65","large_size_h","1024","yes");
INSERT INTO `afhwp_options` VALUES ("66","image_default_link_type","none","yes");
INSERT INTO `afhwp_options` VALUES ("67","image_default_size","","yes");
INSERT INTO `afhwp_options` VALUES ("68","image_default_align","","yes");
INSERT INTO `afhwp_options` VALUES ("69","close_comments_for_old_posts","0","yes");
INSERT INTO `afhwp_options` VALUES ("70","close_comments_days_old","14","yes");
INSERT INTO `afhwp_options` VALUES ("71","thread_comments","1","yes");
INSERT INTO `afhwp_options` VALUES ("72","thread_comments_depth","5","yes");
INSERT INTO `afhwp_options` VALUES ("73","page_comments","0","yes");
INSERT INTO `afhwp_options` VALUES ("74","comments_per_page","50","yes");
INSERT INTO `afhwp_options` VALUES ("75","default_comments_page","newest","yes");
INSERT INTO `afhwp_options` VALUES ("76","comment_order","asc","yes");
INSERT INTO `afhwp_options` VALUES ("77","sticky_posts","a:0:{}","yes");
INSERT INTO `afhwp_options` VALUES ("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("79","widget_text","a:4:{i:1;a:0:{}i:2;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:15:\"<code>
</code>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;i:4;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:0:\"\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}}","yes");
INSERT INTO `afhwp_options` VALUES ("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("81","uninstall_plugins","a:4:{s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";a:2:{i:0;s:11:\"MEC_factory\";i:1;s:9:\"uninstall\";}s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";s:20:\"sfsi_Unistall_plugin\";s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";s:26:\"spacexchimp_p005_uninstall\";s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:16:\"handle_uninstall\";}}","no");
INSERT INTO `afhwp_options` VALUES ("82","timezone_string","","yes");
INSERT INTO `afhwp_options` VALUES ("83","page_for_posts","0","yes");
INSERT INTO `afhwp_options` VALUES ("84","page_on_front","2","yes");
INSERT INTO `afhwp_options` VALUES ("85","default_post_format","0","yes");
INSERT INTO `afhwp_options` VALUES ("86","link_manager_enabled","0","yes");
INSERT INTO `afhwp_options` VALUES ("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `afhwp_options` VALUES ("88","site_icon","40","yes");
INSERT INTO `afhwp_options` VALUES ("89","medium_large_size_w","768","yes");
INSERT INTO `afhwp_options` VALUES ("90","medium_large_size_h","0","yes");
INSERT INTO `afhwp_options` VALUES ("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `afhwp_options` VALUES ("92","show_comments_cookies_opt_in","0","yes");
INSERT INTO `afhwp_options` VALUES ("93","initial_db_version","38590","yes");
INSERT INTO `afhwp_options` VALUES ("94","afhwp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:73:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:11:\"edit_blocks\";b:1;s:18:\"edit_others_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:19:\"read_private_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:21:\"delete_private_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:20:\"delete_others_blocks\";b:1;s:19:\"edit_private_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:46:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:11:\"edit_blocks\";b:1;s:18:\"edit_others_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:19:\"read_private_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:21:\"delete_private_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:20:\"delete_others_blocks\";b:1;s:19:\"edit_private_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:17:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:11:\"edit_blocks\";b:1;s:14:\"publish_blocks\";b:1;s:11:\"read_blocks\";b:1;s:13:\"delete_blocks\";b:1;s:23:\"delete_published_blocks\";b:1;s:21:\"edit_published_blocks\";b:1;s:13:\"create_blocks\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:6:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:11:\"read_blocks\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `afhwp_options` VALUES ("95","fresh_site","0","yes");
INSERT INTO `afhwp_options` VALUES ("96","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("97","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("98","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("99","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("100","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("101","sidebars_widgets","a:8:{s:19:\"wp_inactive_widgets\";a:1:{i:0;s:6:\"text-4\";}s:18:\"mec-single-sidebar\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:1:{i:0;s:13:\"custom_html-2\";}s:9:\"sidebar-3\";a:1:{i:0;s:6:\"text-2\";}s:9:\"sidebar-4\";a:1:{i:0;s:13:\"custom_html-4\";}s:9:\"sidebar-5\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `afhwp_options` VALUES ("102","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("103","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("104","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("105","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("106","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("107","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("108","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("109","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("110","widget_custom_html","a:3:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:85:\"<div class=\"copyright\">© Copyright 2018 Afrihack. &nbsp;All rights reserved.</div>
\";}s:12:\"_multiwidget\";i:1;i:4;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:12:\"[smbtoolbar]\";}}","yes");
INSERT INTO `afhwp_options` VALUES ("111","cron","a:12:{i:1543143231;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"aa768a35ceed34e467f270ebdc5d82f4\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:14:\"purge-lockouts\";}s:8:\"interval\";i:86400;}}}i:1543143996;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1543144932;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543167989;a:1:{s:15:\"itsec_cron_test\";a:1:{s:32:\"852c5c478d0e3ab78f8784f9c0f9c87b\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:1543167989;}}}}i:1543179996;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1543223215;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543224455;a:1:{s:21:\"et_builder_fonts_cron\";a:1:{s:32:\"552cbb9d6515dadbbc4718ad75114f08\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{s:8:\"interval\";s:5:\"daily\";}s:8:\"interval\";i:86400;}}}i:1543227951;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"3ec3d6914daf50bcdb5e5b065213e29b\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:17:\"purge-log-entries\";}s:8:\"interval\";i:86400;}}}i:1543228251;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"7a0fd5d064c59cf40c3df9ad0bb6e63d\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:11:\"clear-locks\";}s:8:\"interval\";i:86400;}}}i:1543229331;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"e0d50030fc9bde5ba86be99826a116eb\";a:3:{s:8:\"schedule\";s:12:\"itsec-backup\";s:4:\"args\";a:1:{i:0;s:6:\"backup\";}s:8:\"interval\";i:86400;}}}i:1545556713;a:1:{s:32:\"et_core_page_resource_auto_clear\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2592000;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `afhwp_options` VALUES ("112","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1542964712;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `afhwp_options` VALUES ("116","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1543138050;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `afhwp_options` VALUES ("123","_site_transient_timeout_browser_5ac5ce57647169b251182b313622b37f","1543568816","no");
INSERT INTO `afhwp_options` VALUES ("124","_site_transient_browser_5ac5ce57647169b251182b313622b37f","a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"63.0\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `afhwp_options` VALUES ("128","can_compress_scripts","1","no");
INSERT INTO `afhwp_options` VALUES ("142","current_theme","Afrihack theme","yes");
INSERT INTO `afhwp_options` VALUES ("143","theme_mods_Afrihack","a:8:{i:0;b:0;s:18:\"custom_css_post_id\";i:41;s:16:\"et_pb_css_synced\";s:3:\"yes\";s:18:\"nav_menu_locations\";a:1:{s:12:\"primary-menu\";i:2;}s:21:\"et_pb_layouts_updated\";s:3:\"yes\";s:39:\"et_updated_layouts_built_for_post_types\";s:3:\"yes\";s:30:\"et_pb_predefined_layouts_added\";s:2:\"on\";s:34:\"et_pb_predefined_layouts_version_6\";s:2:\"on\";}","yes");
INSERT INTO `afhwp_options` VALUES ("144","theme_switched","","yes");
INSERT INTO `afhwp_options` VALUES ("145","et_pb_cache_notice","a:1:{s:6:\"3.0.98\";s:6:\"ignore\";}","yes");
INSERT INTO `afhwp_options` VALUES ("150","et_core_version","3.0.98","yes");
INSERT INTO `afhwp_options` VALUES ("152","et_divi","a:153:{s:39:\"static_css_custom_css_safety_check_done\";b:1;s:23:\"2_5_flush_rewrite_rules\";s:4:\"done\";s:25:\"3_0_flush_rewrite_rules_2\";s:4:\"done\";s:27:\"divi_skip_font_subset_force\";b:1;s:40:\"divi_email_provider_credentials_migrated\";b:1;s:15:\"divi_1_3_images\";s:7:\"checked\";s:30:\"divi_2_4_documentation_message\";s:9:\"triggered\";s:9:\"divi_logo\";s:44:\"/wp-content/uploads/2018/11/logo_cropped.png\";s:12:\"divi_favicon\";s:39:\"/wp-content/uploads/2018/11/favicon.png\";s:14:\"divi_fixed_nav\";s:2:\"on\";s:26:\"divi_gallery_layout_enable\";s:5:\"false\";s:18:\"divi_color_palette\";s:63:\"#151515|#ffffff|#f40612|#0a0908|#f46036|#2e294e|#0c71c3|#8300e9\";s:15:\"divi_grab_image\";s:5:\"false\";s:15:\"divi_blog_style\";s:5:\"false\";s:12:\"divi_sidebar\";s:16:\"et_right_sidebar\";s:22:\"divi_shop_page_sidebar\";s:16:\"et_right_sidebar\";s:23:\"divi_show_facebook_icon\";s:2:\"on\";s:22:\"divi_show_twitter_icon\";s:2:\"on\";s:21:\"divi_show_google_icon\";s:5:\"false\";s:18:\"divi_show_rss_icon\";s:5:\"false\";s:17:\"divi_facebook_url\";s:29:\"http://facebook.com/afrihack/\";s:16:\"divi_twitter_url\";s:27:\"http://twitter.com/afrihack\";s:15:\"divi_google_url\";s:1:\"#\";s:12:\"divi_rss_url\";s:0:\"\";s:34:\"divi_woocommerce_archive_num_posts\";i:9;s:17:\"divi_catnum_posts\";i:6;s:21:\"divi_archivenum_posts\";i:5;s:20:\"divi_searchnum_posts\";i:5;s:17:\"divi_tagnum_posts\";i:5;s:16:\"divi_date_format\";s:6:\"M j, Y\";s:16:\"divi_use_excerpt\";s:5:\"false\";s:26:\"divi_responsive_shortcodes\";s:2:\"on\";s:33:\"divi_gf_enable_all_character_sets\";s:5:\"false\";s:16:\"divi_back_to_top\";s:5:\"false\";s:18:\"divi_smooth_scroll\";s:5:\"false\";s:25:\"divi_disable_translations\";s:5:\"false\";s:27:\"divi_minify_combine_scripts\";s:2:\"on\";s:26:\"divi_minify_combine_styles\";s:2:\"on\";s:15:\"divi_custom_css\";s:0:\"\";s:21:\"divi_enable_dropdowns\";s:2:\"on\";s:14:\"divi_home_link\";s:5:\"false\";s:15:\"divi_sort_pages\";s:10:\"post_title\";s:15:\"divi_order_page\";s:3:\"asc\";s:22:\"divi_tiers_shown_pages\";i:3;s:32:\"divi_enable_dropdowns_categories\";s:2:\"on\";s:21:\"divi_categories_empty\";s:2:\"on\";s:27:\"divi_tiers_shown_categories\";i:3;s:13:\"divi_sort_cat\";s:4:\"name\";s:14:\"divi_order_cat\";s:3:\"asc\";s:20:\"divi_disable_toptier\";s:5:\"false\";s:25:\"divi_scroll_to_anchor_fix\";s:5:\"false\";s:21:\"et_pb_static_css_file\";s:2:\"on\";s:19:\"et_pb_css_in_footer\";s:3:\"off\";s:25:\"et_pb_product_tour_global\";s:2:\"on\";s:14:\"divi_postinfo2\";a:4:{i:0;s:6:\"author\";i:1;s:4:\"date\";i:2;s:10:\"categories\";i:3;s:8:\"comments\";}s:22:\"divi_show_postcomments\";s:2:\"on\";s:15:\"divi_thumbnails\";s:2:\"on\";s:20:\"divi_page_thumbnails\";s:5:\"false\";s:23:\"divi_show_pagescomments\";s:5:\"false\";s:14:\"divi_postinfo1\";a:3:{i:0;s:6:\"author\";i:1;s:4:\"date\";i:2;s:10:\"categories\";}s:21:\"divi_thumbnails_index\";s:2:\"on\";s:19:\"divi_seo_home_title\";s:5:\"false\";s:25:\"divi_seo_home_description\";s:5:\"false\";s:22:\"divi_seo_home_keywords\";s:5:\"false\";s:23:\"divi_seo_home_canonical\";s:5:\"false\";s:23:\"divi_seo_home_titletext\";s:0:\"\";s:29:\"divi_seo_home_descriptiontext\";s:0:\"\";s:26:\"divi_seo_home_keywordstext\";s:0:\"\";s:18:\"divi_seo_home_type\";s:27:\"BlogName | Blog description\";s:22:\"divi_seo_home_separate\";s:3:\" | \";s:21:\"divi_seo_single_title\";s:5:\"false\";s:27:\"divi_seo_single_description\";s:5:\"false\";s:24:\"divi_seo_single_keywords\";s:5:\"false\";s:25:\"divi_seo_single_canonical\";s:5:\"false\";s:27:\"divi_seo_single_field_title\";s:9:\"seo_title\";s:33:\"divi_seo_single_field_description\";s:15:\"seo_description\";s:30:\"divi_seo_single_field_keywords\";s:12:\"seo_keywords\";s:20:\"divi_seo_single_type\";s:21:\"Post title | BlogName\";s:24:\"divi_seo_single_separate\";s:3:\" | \";s:24:\"divi_seo_index_canonical\";s:5:\"false\";s:26:\"divi_seo_index_description\";s:5:\"false\";s:19:\"divi_seo_index_type\";s:24:\"Category name | BlogName\";s:23:\"divi_seo_index_separate\";s:3:\" | \";s:28:\"divi_integrate_header_enable\";s:2:\"on\";s:26:\"divi_integrate_body_enable\";s:2:\"on\";s:31:\"divi_integrate_singletop_enable\";s:2:\"on\";s:34:\"divi_integrate_singlebottom_enable\";s:2:\"on\";s:21:\"divi_integration_head\";s:0:\"\";s:21:\"divi_integration_body\";s:0:\"\";s:27:\"divi_integration_single_top\";s:0:\"\";s:30:\"divi_integration_single_bottom\";s:0:\"\";s:15:\"divi_468_enable\";s:5:\"false\";s:14:\"divi_468_image\";s:0:\"\";s:12:\"divi_468_url\";s:0:\"\";s:16:\"divi_468_adsense\";s:0:\"\";s:13:\"nav_fullwidth\";b:1;s:11:\"menu_height\";i:30;s:11:\"logo_height\";i:89;s:14:\"primary_nav_bg\";s:7:\"#151515\";s:24:\"footer_widget_text_color\";s:7:\"#ffffff\";s:24:\"footer_widget_link_color\";s:7:\"#ffffff\";s:12:\"boxed_layout\";b:0;s:12:\"heading_font\";s:6:\"Ubuntu\";s:12:\"accent_color\";s:7:\"#f40612\";s:9:\"body_font\";s:6:\"Ubuntu\";s:10:\"link_color\";s:7:\"#2e294e\";s:10:\"font_color\";s:7:\"#0a0908\";s:12:\"header_color\";s:7:\"#f40612\";s:12:\"header_style\";s:4:\"left\";s:9:\"menu_link\";s:22:\"rgba(255,255,255,0.56)\";s:16:\"menu_link_active\";s:7:\"#ffffff\";s:31:\"primary_nav_dropdown_line_color\";s:7:\"#f40612\";s:16:\"secondary_nav_bg\";s:7:\"#151515\";s:25:\"secondary_nav_dropdown_bg\";s:7:\"#0a0908\";s:22:\"fixed_secondary_nav_bg\";s:7:\"#151515\";s:22:\"fixed_menu_link_active\";s:7:\"#f40612\";s:24:\"show_header_social_icons\";b:0;s:16:\"show_search_icon\";b:0;s:24:\"show_footer_social_icons\";b:0;s:9:\"footer_bg\";s:7:\"#0a0908\";s:29:\"disable_custom_footer_credits\";b:1;s:19:\"product_tour_status\";a:1:{i:1;s:3:\"off\";}s:32:\"et_fb_pref_settings_bar_location\";s:6:\"bottom\";s:28:\"et_fb_pref_builder_animation\";s:4:\"true\";s:41:\"et_fb_pref_builder_display_modal_settings\";s:5:\"false\";s:21:\"et_fb_pref_event_mode\";s:5:\"hover\";s:32:\"et_fb_pref_hide_disabled_modules\";s:5:\"false\";s:28:\"et_fb_pref_history_intervals\";i:1;s:27:\"et_fb_pref_modal_preference\";s:7:\"default\";s:30:\"et_fb_pref_modal_snap_location\";s:5:\"false\";s:21:\"et_fb_pref_modal_snap\";s:5:\"false\";s:27:\"et_fb_pref_modal_fullscreen\";s:5:\"false\";s:32:\"et_fb_pref_modal_dimension_width\";i:400;s:33:\"et_fb_pref_modal_dimension_height\";i:400;s:27:\"et_fb_pref_modal_position_x\";i:314;s:27:\"et_fb_pref_modal_position_y\";i:61;s:24:\"et_fb_pref_toolbar_click\";s:5:\"false\";s:26:\"et_fb_pref_toolbar_desktop\";s:4:\"true\";s:23:\"et_fb_pref_toolbar_grid\";s:5:\"false\";s:24:\"et_fb_pref_toolbar_hover\";s:5:\"false\";s:24:\"et_fb_pref_toolbar_phone\";s:4:\"true\";s:25:\"et_fb_pref_toolbar_tablet\";s:4:\"true\";s:28:\"et_fb_pref_toolbar_wireframe\";s:4:\"true\";s:23:\"et_fb_pref_toolbar_zoom\";s:4:\"true\";s:21:\"all_buttons_font_size\";i:16;s:25:\"all_buttons_border_radius\";i:50;s:22:\"all_buttons_text_color\";s:7:\"#ffffff\";s:26:\"all_buttons_icon_placement\";s:5:\"right\";s:27:\"et_pb_clear_templates_cache\";b:1;s:22:\"primary_nav_font_style\";s:0:\"\";s:14:\"footer_columns\";s:1:\"3\";s:21:\"custom_footer_credits\";s:51:\"© Copyright 2018 hack.africa All rights reserved. \";s:22:\"footer_menu_font_style\";s:0:\"\";}","yes");
INSERT INTO `afhwp_options` VALUES ("153","widget_aboutmewidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("154","widget_adsensewidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("155","widget_advwidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("156","shop_catalog_image_size","a:3:{s:5:\"width\";s:3:\"400\";s:6:\"height\";s:3:\"400\";s:4:\"crop\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("157","shop_single_image_size","a:3:{s:5:\"width\";s:3:\"510\";s:6:\"height\";s:4:\"9999\";s:4:\"crop\";i:0;}","yes");
INSERT INTO `afhwp_options` VALUES ("158","shop_thumbnail_image_size","a:3:{s:5:\"width\";s:3:\"157\";s:6:\"height\";s:3:\"157\";s:4:\"crop\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("159","et_images_temp_folder","/opt/lampp/htdocs/afrihack/wp-content/uploads/et_temp","yes");
INSERT INTO `afhwp_options` VALUES ("160","et_schedule_clean_images_last_time","1542964713","yes");
INSERT INTO `afhwp_options` VALUES ("161","et_pb_builder_options","a:2:{i:0;b:0;s:35:\"email_provider_credentials_migrated\";b:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("163","et_account_status","active","yes");
INSERT INTO `afhwp_options` VALUES ("164","_site_transient_et_update_themes","O:8:\"stdClass\":3:{s:7:\"checked\";a:2:{s:8:\"Afrihack\";s:6:\"3.0.98\";s:4:\"Divi\";s:6:\"3.0.98\";}s:8:\"response\";a:1:{s:4:\"Divi\";a:2:{s:11:\"new_version\";s:6:\"3.17.6\";s:3:\"url\";s:52:\"https://www.elegantthemes.com/api/changelog/divi.txt\";}}s:12:\"last_checked\";i:1543052214;}","no");
INSERT INTO `afhwp_options` VALUES ("170","et_google_api_settings","a:2:{s:7:\"api_key\";s:0:\"\";s:26:\"enqueue_google_maps_script\";s:2:\"on\";}","yes");
INSERT INTO `afhwp_options` VALUES ("171","et_automatic_updates_options","a:2:{s:8:\"username\";s:0:\"\";s:7:\"api_key\";s:0:\"\";}","yes");
INSERT INTO `afhwp_options` VALUES ("172","category_children","a:0:{}","yes");
INSERT INTO `afhwp_options` VALUES ("193","_site_transient_et_update_all_plugins","O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1543052222;}","no");
INSERT INTO `afhwp_options` VALUES ("194","recently_activated","a:5:{s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";i:1543002837;s:23:\"gutenberg/gutenberg.php\";i:1542972171;s:39:\"widget-countdown/wpdevart-countdown.php\";i:1542969744;s:55:\"codeboxrflexiblecountdown/codeboxrflexiblecountdown.php\";i:1542969193;s:45:\"jquery-t-countdown-widget/countdown-timer.php\";i:1542968821;}","yes");
INSERT INTO `afhwp_options` VALUES ("199","widget_countdowntimer","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("200","_transient_timeout_plugin_slugs","1543140715","no");
INSERT INTO `afhwp_options` VALUES ("201","_transient_plugin_slugs","a:7:{i:0;s:19:\"akismet/akismet.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:21:\"flamingo/flamingo.php\";i:3;s:41:\"better-wp-security/better-wp-security.php\";i:4;s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";i:5;s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";i:6;s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";}","no");
INSERT INTO `afhwp_options` VALUES ("202","WP_TMC_options","a:2:{s:9:\"force_css\";s:5:\"darth\";s:10:\"custom_css\";s:0:\"\";}","yes");
INSERT INTO `afhwp_options` VALUES ("223","widget_cbfcwidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("224","cbfc_general_settings","a:4:{s:4:\"type\";s:10:\"cbfc_light\";s:4:\"date\";s:10:\"12/26/2018\";s:4:\"hour\";i:0;s:3:\"min\";i:0;}","yes");
INSERT INTO `afhwp_options` VALUES ("225","cbfc_light_settings","a:6:{s:9:\"num_color\";s:4:\"#333\";s:13:\"res_num_color\";s:4:\"#333\";s:12:\"num_bg_color\";s:7:\"#eaeaea\";s:10:\"text_color\";s:4:\"#fff\";s:14:\"res_text_color\";s:4:\"#333\";s:13:\"text_bg_color\";s:7:\"#f5832b\";}","yes");
INSERT INTO `afhwp_options` VALUES ("226","cbfc_circular_settings","a:8:{s:9:\"sec_color\";s:7:\"#7995D5\";s:9:\"min_color\";s:7:\"#ACC742\";s:10:\"hour_color\";s:7:\"#ECEFCB\";s:9:\"day_color\";s:7:\"#FF9900\";s:12:\"canvas_color\";s:7:\"#9c9c9c\";s:10:\"text_color\";s:7:\"#ffffff\";s:14:\"res_text_color\";s:4:\"#333\";s:12:\"border_width\";s:1:\"6\";}","yes");
INSERT INTO `afhwp_options` VALUES ("227","cbfc_kk_settings","a:3:{s:9:\"font_size\";s:2:\"30\";s:9:\"num_color\";s:7:\"#3767b9\";s:10:\"text_color\";s:7:\"#666333\";}","yes");
INSERT INTO `afhwp_options` VALUES ("228","cbfc_tools","a:2:{s:20:\"delete_global_config\";s:2:\"no\";s:10:\"reset_data\";s:3:\"off\";}","yes");
INSERT INTO `afhwp_options` VALUES ("243","widget_wpdevart_countdown","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("259","mec_options","a:4:{s:8:\"settings\";a:69:{s:11:\"time_format\";s:2:\"12\";s:16:\"hide_time_method\";s:5:\"start\";s:24:\"multiple_day_show_method\";s:18:\"first_day_listgrid\";s:24:\"remove_data_on_uninstall\";s:1:\"0\";s:11:\"date_suffix\";s:1:\"0\";s:8:\"weekdays\";a:5:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";}s:8:\"weekends\";a:2:{i:0;s:1:\"6\";i:1;s:1:\"7\";}s:13:\"archive_title\";s:10:\"Checkpoint\";s:20:\"default_skin_archive\";s:13:\"full_calendar\";s:21:\"default_skin_category\";s:4:\"list\";s:22:\"category_events_method\";s:1:\"1\";s:14:\"archive_status\";s:1:\"1\";s:4:\"slug\";s:11:\"checkpoints\";s:13:\"category_slug\";s:12:\"mec-category\";s:19:\"single_date_format1\";s:5:\"M d Y\";s:18:\"single_date_method\";s:4:\"next\";s:19:\"single_single_style\";s:7:\"default\";s:20:\"single_booking_style\";s:7:\"default\";s:8:\"currency\";s:3:\"GHS\";s:16:\"currency_symptom\";s:0:\"\";s:13:\"currency_sign\";s:6:\"before\";s:18:\"thousand_separator\";s:1:\",\";s:17:\"decimal_separator\";s:1:\".\";s:24:\"decimal_separator_status\";s:1:\"1\";s:15:\"speakers_status\";s:1:\"0\";s:23:\"google_recaptcha_status\";s:1:\"0\";s:24:\"google_recaptcha_booking\";s:1:\"0\";s:20:\"google_recaptcha_fes\";s:1:\"0\";s:24:\"google_recaptcha_sitekey\";s:0:\"\";s:26:\"google_recaptcha_secretkey\";s:0:\"\";s:20:\"export_module_status\";s:1:\"0\";s:2:\"sn\";a:8:{s:9:\"googlecal\";s:1:\"0\";s:4:\"ical\";s:1:\"0\";s:8:\"facebook\";s:1:\"1\";s:5:\"gplus\";s:1:\"1\";s:7:\"twitter\";s:1:\"1\";s:8:\"linkedin\";s:1:\"1\";s:2:\"vk\";s:1:\"1\";s:5:\"email\";s:1:\"1\";}s:24:\"local_time_module_status\";s:1:\"0\";s:16:\"countdown_status\";s:1:\"1\";s:14:\"countdown_list\";s:4:\"flip\";s:21:\"social_network_status\";s:1:\"1\";s:24:\"next_event_module_status\";s:1:\"0\";s:24:\"next_event_module_method\";s:10:\"occurrence\";s:30:\"next_event_module_date_format1\";s:5:\"M d Y\";s:13:\"fes_list_page\";s:0:\"\";s:13:\"fes_form_page\";s:0:\"\";s:16:\"fes_guest_status\";s:1:\"0\";s:20:\"fes_guest_name_email\";s:1:\"1\";s:23:\"fes_section_event_links\";s:1:\"1\";s:16:\"fes_section_cost\";s:1:\"1\";s:26:\"fes_section_featured_image\";s:1:\"1\";s:22:\"fes_section_categories\";s:1:\"1\";s:18:\"fes_section_labels\";s:1:\"1\";s:23:\"fes_section_event_color\";s:1:\"1\";s:16:\"fes_section_tags\";s:1:\"1\";s:20:\"fes_section_location\";s:1:\"1\";s:21:\"fes_section_organizer\";s:1:\"1\";s:19:\"fes_section_speaker\";s:1:\"0\";s:27:\"fes_section_hourly_schedule\";s:1:\"1\";s:19:\"fes_section_booking\";s:1:\"1\";s:16:\"fes_section_fees\";s:1:\"1\";s:29:\"fes_section_ticket_variations\";s:1:\"1\";s:8:\"fes_note\";s:1:\"0\";s:19:\"fes_note_visibility\";s:6:\"always\";s:16:\"exceptional_days\";s:1:\"0\";s:21:\"additional_organizers\";s:1:\"1\";s:9:\"bp_status\";s:1:\"0\";s:19:\"bp_attendees_module\";s:1:\"0\";s:25:\"bp_attendees_module_limit\";s:2:\"20\";s:15:\"bp_add_activity\";s:1:\"0\";s:13:\"mchimp_status\";s:1:\"0\";s:14:\"mchimp_api_key\";s:0:\"\";s:14:\"mchimp_list_id\";s:0:\"\";s:26:\"mchimp_subscription_status\";s:10:\"subscribed\";}s:6:\"styles\";a:1:{s:3:\"CSS\";s:0:\"\";}s:8:\"gateways\";a:1:{i:1;a:1:{s:6:\"status\";i:1;}}s:13:\"notifications\";a:5:{s:20:\"booking_notification\";a:3:{s:7:\"subject\";s:25:\"Your booking is received.\";s:10:\"recipients\";s:0:\"\";s:7:\"content\";s:238:\"Hello %%name%%,

                    Your booking is received. We will check and confirm your booking as soon as possible.
                    Thanks for your patience.

                    Regards,
                    %%blog_name%%\";}s:18:\"email_verification\";a:3:{s:7:\"subject\";s:27:\"Please verify your booking.\";s:10:\"recipients\";s:0:\"\";s:7:\"content\";s:205:\"Hi %%name%%,

                    Please verify your booking by clicking on following link:

                    %%verification_link%%

                    Regards,
                    %%blog_name%%\";}s:20:\"booking_confirmation\";a:3:{s:7:\"subject\";s:26:\"Your booking is confirmed.\";s:10:\"recipients\";s:0:\"\";s:7:\"content\";s:295:\"Hi %%name%%,

                    Your booking is confirmed. You should be available at %%book_date%% in %%event_location_address%%.

                    You can contact to event organizer by calling %%event_organizer_tel%%.

                    Regards,
                    %%blog_name%%\";}s:18:\"admin_notification\";a:3:{s:7:\"subject\";s:26:\"A new booking is received.\";s:10:\"recipients\";s:0:\"\";s:7:\"content\";s:282:\"Dear Admin,

                    A new booking is received. Please check and confirm it as soon as possible.

                    %%admin_link%%
                    
                    %%attendees_full_info%%

                    Regards,
                    %%blog_name%%\";}s:9:\"new_event\";a:4:{s:6:\"status\";s:1:\"1\";s:7:\"subject\";s:21:\"A new event is added.\";s:10:\"recipients\";s:0:\"\";s:7:\"content\";s:322:\"Hello,

                    A new event just added. The event title is %%event_title%% and its status is %%event_status%%.
                    The new event may need to be published. Please use this link for managing your website events: %%admin_link%%

                    Regards,
                    %%blog_name%%\";}}}","yes");
INSERT INTO `afhwp_options` VALUES ("260","mec_installed","1","yes");
INSERT INTO `afhwp_options` VALUES ("261","mec_version","3.3.0","yes");
INSERT INTO `afhwp_options` VALUES ("268","widget_mec_mec_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("269","widget_mec_single_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("270","mec_gfont","","yes");
INSERT INTO `afhwp_options` VALUES ("271","mec_dyncss","","yes");
INSERT INTO `afhwp_options` VALUES ("273","mec_colors","a:5:{i:0;s:6:\"fdd700\";i:1;s:6:\"00a0d2\";i:2;s:6:\"e14d43\";i:3;s:6:\"dd823b\";i:4;s:6:\"a3b745\";}","yes");
INSERT INTO `afhwp_options` VALUES ("283","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `afhwp_options` VALUES ("285","mec_category_children","a:0:{}","yes");
INSERT INTO `afhwp_options` VALUES ("301","wpcf7","a:2:{s:7:\"version\";s:5:\"5.0.5\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1542995793;s:7:\"version\";s:5:\"5.0.5\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `afhwp_options` VALUES ("345","widget_sfsi-widget","a:2:{i:2;a:2:{s:5:\"showf\";i:1;s:5:\"title\";s:26:\"Please follow & like us :)\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("365","spacexchimp_p005_service_info","a:4:{s:7:\"upgrade\";s:4:\"0002\";s:7:\"version\";s:4:\"4.44\";s:11:\"old_version\";s:1:\"0\";s:15:\"activation_date\";i:1543002957;}","yes");
INSERT INTO `afhwp_options` VALUES ("370","spacexchimp_p005_settings","a:6:{s:16:\"buttons-selected\";a:3:{s:8:\"facebook\";s:2:\"on\";s:7:\"twitter\";s:2:\"on\";s:5:\"email\";s:2:\"on\";}s:12:\"buttons-link\";a:100:{s:8:\"facebook\";s:29:\"http://facebook.com/afrihack/\";s:14:\"facebook-group\";s:0:\"\";s:7:\"twitter\";s:27:\"http://twitter.com/afrihack\";s:9:\"instagram\";s:0:\"\";s:11:\"google-plus\";s:0:\"\";s:7:\"youtube\";s:0:\"\";s:14:\"youtube-gaming\";s:0:\"\";s:11:\"google-play\";s:0:\"\";s:6:\"itunes\";s:0:\"\";s:15:\"itunes-podcasts\";s:0:\"\";s:11:\"apple-music\";s:0:\"\";s:9:\"periscope\";s:0:\"\";s:5:\"vimeo\";s:0:\"\";s:7:\"blogger\";s:0:\"\";s:10:\"buzzsprout\";s:0:\"\";s:11:\"livejournal\";s:0:\"\";s:6:\"reddit\";s:0:\"\";s:8:\"linkedin\";s:0:\"\";s:8:\"diaspora\";s:0:\"\";s:10:\"deviantart\";s:0:\"\";s:4:\"xing\";s:0:\"\";s:9:\"pinterest\";s:0:\"\";s:6:\"flickr\";s:0:\"\";s:6:\"tumblr\";s:0:\"\";s:8:\"snapchat\";s:0:\"\";s:6:\"twitch\";s:0:\"\";s:7:\"patreon\";s:0:\"\";s:4:\"imdb\";s:0:\"\";s:10:\"soundcloud\";s:0:\"\";s:6:\"plugdj\";s:0:\"\";s:7:\"spotify\";s:0:\"\";s:8:\"bandcamp\";s:0:\"\";s:5:\"dloky\";s:0:\"\";s:6:\"amazon\";s:0:\"\";s:7:\"bookbub\";s:0:\"\";s:9:\"goodreads\";s:0:\"\";s:8:\"meetvibe\";s:0:\"\";s:6:\"meetup\";s:0:\"\";s:5:\"steam\";s:0:\"\";s:5:\"mixer\";s:0:\"\";s:7:\"discord\";s:0:\"\";s:4:\"yelp\";s:0:\"\";s:11:\"stumbleupon\";s:0:\"\";s:9:\"bloglovin\";s:0:\"\";s:8:\"whatsapp\";s:0:\"\";s:6:\"medium\";s:0:\"\";s:5:\"500px\";s:0:\"\";s:7:\"behance\";s:0:\"\";s:8:\"polyvore\";s:0:\"\";s:11:\"yellowpages\";s:0:\"\";s:4:\"line\";s:0:\"\";s:4:\"itch\";s:0:\"\";s:8:\"mastodon\";s:0:\"\";s:6:\"remind\";s:0:\"\";s:7:\"trademe\";s:0:\"\";s:4:\"vsco\";s:0:\"\";s:9:\"hireology\";s:0:\"\";s:6:\"kompoz\";s:0:\"\";s:10:\"soundblend\";s:0:\"\";s:9:\"vkontakte\";s:0:\"\";s:13:\"odnoklassniki\";s:0:\"\";s:8:\"telegram\";s:0:\"\";s:6:\"github\";s:0:\"\";s:9:\"wordpress\";s:0:\"\";s:7:\"codepen\";s:0:\"\";s:5:\"askfm\";s:0:\"\";s:4:\"ebay\";s:0:\"\";s:8:\"hangouts\";s:0:\"\";s:5:\"houzz\";s:0:\"\";s:5:\"quora\";s:0:\"\";s:7:\"steemit\";s:0:\"\";s:11:\"theartstack\";s:0:\"\";s:7:\"theknot\";s:0:\"\";s:5:\"viber\";s:0:\"\";s:4:\"etsy\";s:0:\"\";s:11:\"tripadvisor\";s:0:\"\";s:13:\"stackoverflow\";s:0:\"\";s:13:\"stackexchange\";s:0:\"\";s:9:\"bitbucket\";s:0:\"\";s:15:\"dailypaintworks\";s:0:\"\";s:9:\"flipboard\";s:0:\"\";s:10:\"feedsfloor\";s:0:\"\";s:3:\"gab\";s:0:\"\";s:5:\"minds\";s:0:\"\";s:7:\"wattpad\";s:0:\"\";s:8:\"about-me\";s:0:\"\";s:8:\"stitcher\";s:0:\"\";s:6:\"strava\";s:0:\"\";s:6:\"wechat\";s:0:\"\";s:5:\"weibo\";s:0:\"\";s:7:\"untappd\";s:0:\"\";s:6:\"tunein\";s:0:\"\";s:6:\"iheart\";s:0:\"\";s:16:\"blackberry-world\";s:0:\"\";s:10:\"livestream\";s:0:\"\";s:5:\"skype\";s:0:\"\";s:9:\"telephone\";s:0:\"\";s:5:\"email\";s:24:\"mailto:email@hack.africa\";s:7:\"website\";s:0:\"\";s:8:\"rss-feed\";s:0:\"\";}s:9:\"icon-size\";s:2:\"30\";s:12:\"margin-right\";s:2:\"10\";s:9:\"alignment\";s:5:\"right\";s:7:\"caption\";s:25:\"Follow us on social media\";}","yes");
INSERT INTO `afhwp_options` VALUES ("401","WPLANG","","yes");
INSERT INTO `afhwp_options` VALUES ("402","new_admin_email","ngunyimacharia@gmail.com","yes");
INSERT INTO `afhwp_options` VALUES ("409","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1543138051;s:7:\"checked\";a:2:{s:8:\"Afrihack\";s:6:\"3.0.98\";s:4:\"Divi\";s:6:\"3.0.98\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `afhwp_options` VALUES ("416","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1543138051;s:7:\"checked\";a:7:{s:19:\"akismet/akismet.php\";s:3:\"4.1\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.5\";s:21:\"flamingo/flamingo.php\";s:3:\"1.9\";s:41:\"better-wp-security/better-wp-security.php\";s:5:\"7.2.0\";s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";s:5:\"3.3.0\";s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";s:4:\"4.44\";s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";s:5:\"3.2.8\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"flamingo/flamingo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/flamingo\";s:4:\"slug\";s:8:\"flamingo\";s:6:\"plugin\";s:21:\"flamingo/flamingo.php\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/flamingo/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/flamingo.1.9.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/flamingo/assets/icon-128x128.png?rev=1540977\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/flamingo/assets/banner-772x250.png?rev=544829\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/better-wp-security\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:5:\"7.2.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/better-wp-security.7.2.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:70:\"https://ps.w.org/better-wp-security/assets/icon-256x256.jpg?rev=969999\";s:2:\"1x\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";s:3:\"svg\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/better-wp-security/assets/banner-772x250.png?rev=881897\";}s:11:\"banners_rtl\";a:0:{}}s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:41:\"w.org/plugins/modern-events-calendar-lite\";s:4:\"slug\";s:27:\"modern-events-calendar-lite\";s:6:\"plugin\";s:59:\"modern-events-calendar-lite/modern-events-calendar-lite.php\";s:11:\"new_version\";s:5:\"3.3.0\";s:3:\"url\";s:58:\"https://wordpress.org/plugins/modern-events-calendar-lite/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/modern-events-calendar-lite.3.3.0.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:80:\"https://ps.w.org/modern-events-calendar-lite/assets/icon-128x128.png?rev=1912654\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:82:\"https://ps.w.org/modern-events-calendar-lite/assets/banner-772x250.png?rev=1912767\";}s:11:\"banners_rtl\";a:0:{}}s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:42:\"w.org/plugins/social-media-buttons-toolbar\";s:4:\"slug\";s:28:\"social-media-buttons-toolbar\";s:6:\"plugin\";s:61:\"social-media-buttons-toolbar/social-media-buttons-toolbar.php\";s:11:\"new_version\";s:4:\"4.44\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/social-media-buttons-toolbar/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/social-media-buttons-toolbar.4.44.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/social-media-buttons-toolbar/assets/icon-256x256.png?rev=1621322\";s:2:\"1x\";s:81:\"https://ps.w.org/social-media-buttons-toolbar/assets/icon-128x128.png?rev=1396749\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:83:\"https://ps.w.org/social-media-buttons-toolbar/assets/banner-772x250.png?rev=1621322\";}s:11:\"banners_rtl\";a:0:{}}s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/velvet-blues-update-urls\";s:4:\"slug\";s:24:\"velvet-blues-update-urls\";s:6:\"plugin\";s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";s:11:\"new_version\";s:5:\"3.2.8\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/velvet-blues-update-urls/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/velvet-blues-update-urls.3.2.8.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:75:\"https://s.w.org/plugins/geopattern-icon/velvet-blues-update-urls_727172.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/velvet-blues-update-urls/assets/banner-772x250.jpg?rev=486343\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `afhwp_options` VALUES ("430","itsec-storage","a:10:{s:6:\"global\";a:30:{s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:12:\"log_rotation\";i:60;s:17:\"file_log_rotation\";i:180;s:8:\"log_type\";s:8:\"database\";s:12:\"log_location\";s:61:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/logs\";s:8:\"log_info\";s:0:\"\";s:14:\"allow_tracking\";b:0;s:11:\"write_files\";b:1;s:10:\"nginx_file\";s:31:\"/var/www/hack.africa/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:11:\"did_upgrade\";b:0;s:9:\"lock_file\";b:0;s:5:\"proxy\";s:9:\"automatic\";s:12:\"proxy_header\";s:20:\"HTTP_X_FORWARDED_FOR\";s:14:\"hide_admin_bar\";b:0;s:16:\"show_error_codes\";b:0;s:19:\"show_security_check\";b:0;s:5:\"build\";i:4108;s:20:\"activation_timestamp\";i:1543052222;s:11:\"cron_status\";i:1;s:8:\"use_cron\";b:1;s:14:\"cron_test_time\";i:1543167989;s:19:\"enable_grade_report\";b:0;}s:21:\"password-requirements\";a:2:{s:20:\"enabled_requirements\";a:1:{s:8:\"strength\";b:1;}s:20:\"requirement_settings\";a:1:{s:8:\"strength\";a:1:{s:4:\"role\";s:13:\"administrator\";}}}s:16:\"wordpress-tweaks\";a:13:{s:18:\"wlwmanifest_header\";b:0;s:14:\"edituri_header\";b:0;s:12:\"comment_spam\";b:0;s:11:\"file_editor\";b:1;s:14:\"disable_xmlrpc\";i:0;s:22:\"allow_xmlrpc_multiauth\";b:0;s:8:\"rest_api\";s:15:\"restrict-access\";s:12:\"login_errors\";b:0;s:21:\"force_unique_nicename\";b:0;s:27:\"disable_unused_author_pages\";b:0;s:16:\"block_tabnapping\";b:0;s:21:\"valid_user_login_type\";s:4:\"both\";s:26:\"patch_thumb_file_traversal\";b:1;}s:19:\"network-brute-force\";a:5:{s:7:\"api_key\";s:32:\"yhpDY95xxT6Qj3J2LBqaJNQy68mmNPH5\";s:10:\"api_secret\";s:128:\"lld0SswqJZ0W2vp4i1z9j44Esqrtx3I4yM83rfvOFOz1523e0Z5z9KZmc7L7ont5PlMufoakP5apJ5aOn4ZBTd8y77nGEQrpH0Z5h5f9CQPu9VbJe3jwq8u88Gxq94p1\";s:10:\"enable_ban\";b:1;s:13:\"updates_optin\";b:1;s:7:\"api_nag\";b:0;}s:19:\"notification-center\";a:8:{s:9:\"last_sent\";a:1:{s:6:\"digest\";i:1543140401;}s:9:\"resend_at\";a:0:{}s:4:\"data\";a:1:{s:6:\"digest\";a:0:{}}s:15:\"last_mail_error\";s:36:\"Could not instantiate mail function.\";s:13:\"notifications\";a:5:{s:6:\"backup\";a:2:{s:10:\"email_list\";a:1:{i:0;s:24:\"ngunyimacharia@gmail.com\";}s:7:\"subject\";N;}s:6:\"digest\";a:5:{s:8:\"schedule\";s:5:\"daily\";s:7:\"enabled\";b:1;s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:14:\"recipient_type\";s:7:\"default\";s:7:\"subject\";N;}s:7:\"lockout\";a:4:{s:7:\"enabled\";b:1;s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:14:\"recipient_type\";s:7:\"default\";s:7:\"subject\";N;}s:11:\"file-change\";a:4:{s:7:\"enabled\";b:1;s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:14:\"recipient_type\";s:7:\"default\";s:7:\"subject\";N;}s:12:\"hide-backend\";a:4:{s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:14:\"recipient_type\";s:7:\"default\";s:7:\"subject\";N;s:7:\"message\";s:0:\"\";}}s:12:\"admin_emails\";a:0:{}s:10:\"from_email\";s:0:\"\";s:18:\"default_recipients\";a:1:{s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}}}s:6:\"backup\";a:9:{s:9:\"all_sites\";b:1;s:6:\"method\";i:0;s:8:\"location\";s:64:\"/var/www/hack.africa/wp-content/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:2:{i:0;s:14:\"itsec_lockouts\";i:1;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:8:\"last_run\";i:1543056570;}s:3:\"ssl\";a:3:{s:11:\"require_ssl\";s:8:\"disabled\";s:8:\"frontend\";i:0;s:5:\"admin\";b:0;}s:11:\"file-change\";a:6:{s:9:\"file_list\";a:0:{}s:5:\"types\";a:39:{i:0;s:4:\".log\";i:1;s:3:\".mo\";i:2;s:3:\".po\";i:3;s:4:\".bmp\";i:4;s:4:\".gif\";i:5;s:4:\".ico\";i:6;s:4:\".jpe\";i:7;s:5:\".jpeg\";i:8;s:4:\".jpg\";i:9;s:4:\".png\";i:10;s:4:\".psd\";i:11;s:4:\".raw\";i:12;s:4:\".svg\";i:13;s:4:\".tif\";i:14;s:5:\".tiff\";i:15;s:4:\".aif\";i:16;s:5:\".flac\";i:17;s:4:\".m4a\";i:18;s:4:\".mp3\";i:19;s:4:\".oga\";i:20;s:4:\".ogg\";i:22;s:3:\".ra\";i:23;s:4:\".wav\";i:24;s:4:\".wma\";i:25;s:4:\".asf\";i:26;s:4:\".avi\";i:27;s:4:\".mkv\";i:28;s:4:\".mov\";i:29;s:4:\".mp4\";i:30;s:4:\".mpe\";i:31;s:5:\".mpeg\";i:32;s:4:\".mpg\";i:33;s:4:\".ogv\";i:34;s:3:\".qt\";i:35;s:3:\".rm\";i:36;s:4:\".vob\";i:37;s:5:\".webm\";i:38;s:3:\".wm\";i:39;s:4:\".wmv\";}s:12:\"notify_admin\";b:1;s:12:\"show_warning\";b:0;s:15:\"expected_hashes\";a:2:{s:34:\"/var/www/hack.africa/wp-config.php\";s:32:\"5ebf7841087d93c8a09c6c81d6faefac\";s:30:\"/var/www/hack.africa/.htaccess\";s:32:\"274db00952f534a30dd4107d46aead75\";}s:9:\"last_scan\";i:0;}s:10:\"admin-user\";a:2:{s:9:\"change_id\";b:1;s:12:\"new_username\";N;}s:12:\"hide-backend\";a:6:{s:7:\"enabled\";b:1;s:4:\"slug\";s:8:\"ha_login\";s:12:\"theme_compat\";b:1;s:17:\"theme_compat_slug\";s:10:\"contact-us\";s:16:\"post_logout_slug\";s:0:\"\";s:8:\"register\";s:13:\"wp-signup.php\";}}","yes");
INSERT INTO `afhwp_options` VALUES ("437","itsec_active_modules","a:9:{s:9:\"ban-users\";b:1;s:6:\"backup\";b:1;s:11:\"brute-force\";b:1;s:19:\"network-brute-force\";b:1;s:16:\"wordpress-tweaks\";b:1;s:13:\"404-detection\";b:1;s:11:\"file-change\";b:1;s:3:\"ssl\";b:0;s:13:\"system-tweaks\";b:0;}","yes");
INSERT INTO `afhwp_options` VALUES ("466","itsec_cron","a:2:{s:6:\"single\";a:0:{}s:9:\"recurring\";a:4:{s:17:\"purge-log-entries\";a:1:{s:4:\"data\";a:0:{}}s:14:\"purge-lockouts\";a:1:{s:4:\"data\";a:0:{}}s:11:\"clear-locks\";a:1:{s:4:\"data\";a:0:{}}s:6:\"backup\";a:1:{s:4:\"data\";a:0:{}}}}","no");
INSERT INTO `afhwp_options` VALUES ("473","_site_transient_timeout_et_core_version","1543227988","no");
INSERT INTO `afhwp_options` VALUES ("474","_site_transient_et_core_version","3.0.98","no");
INSERT INTO `afhwp_options` VALUES ("475","itsec_temp_whitelist_ip","a:2:{s:11:\"154.160.3.7\";i:1543226800;s:14:\"154.160.21.234\";i:1543240862;}","no");
INSERT INTO `afhwp_options` VALUES ("476","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `afhwp_options` VALUES ("478","itsec_file_change_scan_destroyed","1543055092","no");
INSERT INTO `afhwp_options` VALUES ("495","_site_transient_timeout_theme_roots","1543139850","no");
INSERT INTO `afhwp_options` VALUES ("496","_site_transient_theme_roots","a:2:{s:8:\"Afrihack\";s:7:\"/themes\";s:4:\"Divi\";s:7:\"/themes\";}","no");
INSERT INTO `afhwp_options` VALUES ("501","_site_transient_timeout_itsec_wp_upload_dir","1543227988","no");
INSERT INTO `afhwp_options` VALUES ("502","_site_transient_itsec_wp_upload_dir","a:6:{s:4:\"path\";s:47:\"/var/www/hack.africa/wp-content/uploads/2018/11\";s:3:\"url\";s:45:\"http://hack.africa/wp-content/uploads/2018/11\";s:6:\"subdir\";s:8:\"/2018/11\";s:7:\"basedir\";s:39:\"/var/www/hack.africa/wp-content/uploads\";s:7:\"baseurl\";s:37:\"http://hack.africa/wp-content/uploads\";s:5:\"error\";b:0;}","no");
INSERT INTO `afhwp_options` VALUES ("503","_site_transient_timeout_et_core_path","1543227988","no");
INSERT INTO `afhwp_options` VALUES ("504","_site_transient_et_core_path","/var/www/hack.africa/wp-content/themes/Divi/core","no");
INSERT INTO `afhwp_options` VALUES ("506","_transient_doing_cron","1543154462.9072489738464355468750","yes");
INSERT INTO `afhwp_options` VALUES ("507","itsec-lock-backup","1543154642","no");


CREATE TABLE IF NOT EXISTS `afhwp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_postmeta` VALUES ("1","2","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("2","3","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("3","5","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("4","5","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("5","5","_et_pb_layout_applicability","product_tour");
INSERT INTO `afhwp_postmeta` VALUES ("6","6","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("7","6","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("8","7","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("9","7","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("10","8","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("11","8","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("12","9","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("13","9","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("14","10","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("15","10","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("16","11","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("17","11","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("18","12","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("19","12","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("20","13","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("21","13","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("22","14","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("23","14","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("24","15","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("25","15","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("26","16","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("27","16","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("28","17","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("29","17","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("30","18","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("31","18","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("32","19","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("33","19","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("34","20","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("35","20","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("36","21","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("37","21","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("38","22","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("39","22","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("40","23","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("41","23","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("42","24","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("43","24","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("44","25","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("45","25","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("46","26","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("47","26","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("48","27","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("49","27","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("50","28","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("51","28","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("52","29","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("53","29","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("54","30","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("55","30","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("56","31","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("57","31","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("58","32","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("59","32","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("60","33","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("61","33","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("62","34","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("63","34","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("64","35","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("65","35","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("66","36","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("67","36","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("68","37","_et_pb_predefined_layout","on");
INSERT INTO `afhwp_postmeta` VALUES ("69","37","_et_pb_built_for_post_type","page");
INSERT INTO `afhwp_postmeta` VALUES ("70","1","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("71","1","_wp_trash_meta_time","1542964849");
INSERT INTO `afhwp_postmeta` VALUES ("72","1","_wp_desired_post_slug","hello-world");
INSERT INTO `afhwp_postmeta` VALUES ("73","1","_wp_trash_meta_comments_status","a:1:{i:1;s:1:\"1\";}");
INSERT INTO `afhwp_postmeta` VALUES ("74","39","_wp_attached_file","2018/11/logo_cropped.png");
INSERT INTO `afhwp_postmeta` VALUES ("75","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:325;s:6:\"height\";i:121;s:4:\"file\";s:24:\"2018/11/logo_cropped.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"logo_cropped-150x121.png\";s:5:\"width\";i:150;s:6:\"height\";i:121;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"logo_cropped-300x112.png\";s:5:\"width\";i:300;s:6:\"height\";i:112;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `afhwp_postmeta` VALUES ("76","40","_wp_attached_file","2018/11/favicon.png");
INSERT INTO `afhwp_postmeta` VALUES ("77","40","_wp_attachment_metadata","a:5:{s:5:\"width\";i:99;s:6:\"height\";i:99;s:4:\"file\";s:19:\"2018/11/favicon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `afhwp_postmeta` VALUES ("78","43","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("79","43","_wp_trash_meta_time","1542965316");
INSERT INTO `afhwp_postmeta` VALUES ("80","44","_edit_lock","1542965618:1");
INSERT INTO `afhwp_postmeta` VALUES ("81","44","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("82","44","_wp_trash_meta_time","1542965620");
INSERT INTO `afhwp_postmeta` VALUES ("83","45","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("84","45","_wp_trash_meta_time","1542965645");
INSERT INTO `afhwp_postmeta` VALUES ("85","46","_edit_lock","1542965678:1");
INSERT INTO `afhwp_postmeta` VALUES ("86","46","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("87","46","_wp_trash_meta_time","1542965701");
INSERT INTO `afhwp_postmeta` VALUES ("88","47","_edit_lock","1542965784:1");
INSERT INTO `afhwp_postmeta` VALUES ("89","47","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("90","47","_wp_trash_meta_time","1542965819");
INSERT INTO `afhwp_postmeta` VALUES ("91","2","_edit_lock","1542968011:1");
INSERT INTO `afhwp_postmeta` VALUES ("92","2","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("93","2","_et_pb_post_hide_nav","default");
INSERT INTO `afhwp_postmeta` VALUES ("94","2","_et_pb_page_layout","et_full_width_page");
INSERT INTO `afhwp_postmeta` VALUES ("95","2","_et_pb_side_nav","off");
INSERT INTO `afhwp_postmeta` VALUES ("96","2","_et_pb_use_builder","on");
INSERT INTO `afhwp_postmeta` VALUES ("97","2","_et_builder_version","VB|Divi|3.0.98");
INSERT INTO `afhwp_postmeta` VALUES ("98","2","_et_pb_ab_stats_refresh_interval","hourly");
INSERT INTO `afhwp_postmeta` VALUES ("99","2","_et_pb_old_content","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href=\"http://afrihack.ls/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!");
INSERT INTO `afhwp_postmeta` VALUES ("100","2","_et_pb_enable_shortcode_tracking","");
INSERT INTO `afhwp_postmeta` VALUES ("101","2","_et_pb_custom_css","");
INSERT INTO `afhwp_postmeta` VALUES ("102","49","_wp_attached_file","2018/11/nesa-by-makers-701360-unsplash.jpg");
INSERT INTO `afhwp_postmeta` VALUES ("103","49","_wp_attachment_metadata","a:5:{s:5:\"width\";i:6720;s:6:\"height\";i:4480;s:4:\"file\";s:42:\"2018/11/nesa-by-makers-701360-unsplash.jpg\";s:5:\"sizes\";a:11:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:43:\"nesa-by-makers-701360-unsplash-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-post-main-image\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:31:\"et-pb-post-main-image-fullwidth\";a:4:{s:4:\"file\";s:43:\"nesa-by-makers-701360-unsplash-1080x675.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:675;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-portfolio-image\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"et-pb-portfolio-module-image\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"et-pb-portfolio-image-single\";a:4:{s:4:\"file\";s:43:\"nesa-by-makers-701360-unsplash-1080x720.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:720;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:35:\"et-pb-gallery-module-image-portrait\";a:4:{s:4:\"file\";s:42:\"nesa-by-makers-701360-unsplash-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:37:\"et-pb-post-main-image-fullwidth-large\";a:4:{s:4:\"file\";s:44:\"nesa-by-makers-701360-unsplash-2880x1800.jpg\";s:5:\"width\";i:2880;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `afhwp_postmeta` VALUES ("104","2","_thumbnail_id","49");
INSERT INTO `afhwp_postmeta` VALUES ("105","2","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("106","2","_et_pb_use_ab_testing","off");
INSERT INTO `afhwp_postmeta` VALUES ("108","2","_et_pb_ab_current_shortcode","[et_pb_split_track id=\"2\" /]");
INSERT INTO `afhwp_postmeta` VALUES ("109","58","_edit_lock","1542967993:1");
INSERT INTO `afhwp_postmeta` VALUES ("110","58","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("111","58","_wp_trash_meta_time","1542968005");
INSERT INTO `afhwp_postmeta` VALUES ("112","2","_et_pb_ab_subjects","");
INSERT INTO `afhwp_postmeta` VALUES ("113","82","_edit_lock","1542971939:1");
INSERT INTO `afhwp_postmeta` VALUES ("114","84","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("115","84","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("116","84","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("117","84","mec_start_date","2018-12-12");
INSERT INTO `afhwp_postmeta` VALUES ("118","84","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("119","84","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("120","84","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("121","84","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("122","84","mec_end_date","2018-12-12");
INSERT INTO `afhwp_postmeta` VALUES ("123","84","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("124","84","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("125","84","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("126","84","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("127","84","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("128","84","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("129","84","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("130","84","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("131","84","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-12\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-12\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("132","84","mec_color","00a0d2");
INSERT INTO `afhwp_postmeta` VALUES ("133","85","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("134","85","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("135","85","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("136","85","mec_start_date","2018-12-11");
INSERT INTO `afhwp_postmeta` VALUES ("137","85","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("138","85","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("139","85","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("140","85","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("141","85","mec_end_date","2018-12-11");
INSERT INTO `afhwp_postmeta` VALUES ("142","85","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("143","85","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("144","85","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("145","85","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("146","85","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("147","85","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("148","85","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("149","85","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("150","85","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-11\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-11\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("151","85","mec_color","00a0d2");
INSERT INTO `afhwp_postmeta` VALUES ("152","86","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("153","86","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("154","86","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("155","86","mec_start_date","2018-12-10");
INSERT INTO `afhwp_postmeta` VALUES ("156","86","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("157","86","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("158","86","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("159","86","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("160","86","mec_end_date","2018-12-10");
INSERT INTO `afhwp_postmeta` VALUES ("161","86","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("162","86","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("163","86","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("164","86","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("165","86","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("166","86","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("167","86","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("168","86","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("169","86","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-10\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-10\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("170","86","mec_color","00a0d2");
INSERT INTO `afhwp_postmeta` VALUES ("171","87","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("172","87","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("173","87","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("174","87","mec_start_date","2018-12-08");
INSERT INTO `afhwp_postmeta` VALUES ("175","87","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("176","87","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("177","87","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("178","87","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("179","87","mec_end_date","2018-12-08");
INSERT INTO `afhwp_postmeta` VALUES ("180","87","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("181","87","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("182","87","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("183","87","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("184","87","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("185","87","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("186","87","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("187","87","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("188","87","mec_date","a:6:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-08\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-08\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:7:\"monthly\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("189","87","mec_color","fdd700");
INSERT INTO `afhwp_postmeta` VALUES ("190","88","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("191","88","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("192","88","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("193","88","mec_start_date","2018-12-07");
INSERT INTO `afhwp_postmeta` VALUES ("194","88","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("195","88","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("196","88","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("197","88","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("198","88","mec_end_date","2018-12-07");
INSERT INTO `afhwp_postmeta` VALUES ("199","88","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("200","88","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("201","88","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("202","88","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("203","88","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("204","88","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("205","88","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("206","88","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("207","88","mec_date","a:6:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-07\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-07\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("208","88","mec_color","fdd700");
INSERT INTO `afhwp_postmeta` VALUES ("209","89","label","");
INSERT INTO `afhwp_postmeta` VALUES ("210","89","category","");
INSERT INTO `afhwp_postmeta` VALUES ("211","89","location","");
INSERT INTO `afhwp_postmeta` VALUES ("212","89","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("213","89","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("214","89","author","");
INSERT INTO `afhwp_postmeta` VALUES ("215","89","skin","full_calendar");
INSERT INTO `afhwp_postmeta` VALUES ("216","89","show_past_events","1");
INSERT INTO `afhwp_postmeta` VALUES ("217","89","sk-options","a:1:{s:13:\"full_calendar\";a:6:{s:15:\"start_date_type\";s:5:\"today\";s:12:\"default_view\";s:4:\"list\";s:7:\"monthly\";i:1;s:6:\"weekly\";i:1;s:5:\"daily\";i:1;s:4:\"list\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("218","89","sf-options","a:1:{s:13:\"full_calendar\";a:2:{s:12:\"month_filter\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("219","89","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("220","90","label","");
INSERT INTO `afhwp_postmeta` VALUES ("221","90","category","");
INSERT INTO `afhwp_postmeta` VALUES ("222","90","location","");
INSERT INTO `afhwp_postmeta` VALUES ("223","90","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("224","90","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("225","90","author","");
INSERT INTO `afhwp_postmeta` VALUES ("226","90","skin","monthly_view");
INSERT INTO `afhwp_postmeta` VALUES ("227","90","show_past_events","1");
INSERT INTO `afhwp_postmeta` VALUES ("228","90","sk-options","a:1:{s:12:\"monthly_view\";a:1:{s:20:\"next_previous_button\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("229","90","sf-options","a:1:{s:12:\"monthly_view\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("230","90","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("231","91","label","");
INSERT INTO `afhwp_postmeta` VALUES ("232","91","category","");
INSERT INTO `afhwp_postmeta` VALUES ("233","91","location","");
INSERT INTO `afhwp_postmeta` VALUES ("234","91","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("235","91","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("236","91","author","");
INSERT INTO `afhwp_postmeta` VALUES ("237","91","skin","weekly_view");
INSERT INTO `afhwp_postmeta` VALUES ("238","91","show_past_events","1");
INSERT INTO `afhwp_postmeta` VALUES ("239","91","sk-options","a:1:{s:11:\"weekly_view\";a:1:{s:20:\"next_previous_button\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("240","91","sf-options","a:1:{s:11:\"weekly_view\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("241","91","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("242","92","label","");
INSERT INTO `afhwp_postmeta` VALUES ("243","92","category","");
INSERT INTO `afhwp_postmeta` VALUES ("244","92","location","");
INSERT INTO `afhwp_postmeta` VALUES ("245","92","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("246","92","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("247","92","author","");
INSERT INTO `afhwp_postmeta` VALUES ("248","92","skin","daily_view");
INSERT INTO `afhwp_postmeta` VALUES ("249","92","show_past_events","1");
INSERT INTO `afhwp_postmeta` VALUES ("250","92","sk-options","a:1:{s:10:\"daily_view\";a:1:{s:20:\"next_previous_button\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("251","92","sf-options","a:1:{s:10:\"daily_view\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("252","92","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("253","93","label","");
INSERT INTO `afhwp_postmeta` VALUES ("254","93","category","");
INSERT INTO `afhwp_postmeta` VALUES ("255","93","location","");
INSERT INTO `afhwp_postmeta` VALUES ("256","93","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("257","93","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("258","93","author","");
INSERT INTO `afhwp_postmeta` VALUES ("259","93","skin","map");
INSERT INTO `afhwp_postmeta` VALUES ("260","93","show_past_events","1");
INSERT INTO `afhwp_postmeta` VALUES ("261","93","sk-options","a:1:{s:3:\"map\";a:1:{s:5:\"limit\";i:200;}}");
INSERT INTO `afhwp_postmeta` VALUES ("262","93","sf-options","a:1:{s:3:\"map\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("263","93","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("264","94","label","");
INSERT INTO `afhwp_postmeta` VALUES ("265","94","category","");
INSERT INTO `afhwp_postmeta` VALUES ("266","94","location","");
INSERT INTO `afhwp_postmeta` VALUES ("267","94","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("268","94","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("269","94","author","");
INSERT INTO `afhwp_postmeta` VALUES ("270","94","skin","list");
INSERT INTO `afhwp_postmeta` VALUES ("271","94","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("272","94","sk-options","a:1:{s:4:\"list\";a:1:{s:16:\"load_more_button\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("273","94","sf-options","a:1:{s:4:\"list\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("274","94","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("275","95","label","");
INSERT INTO `afhwp_postmeta` VALUES ("276","95","category","");
INSERT INTO `afhwp_postmeta` VALUES ("277","95","location","");
INSERT INTO `afhwp_postmeta` VALUES ("278","95","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("279","95","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("280","95","author","");
INSERT INTO `afhwp_postmeta` VALUES ("281","95","skin","grid");
INSERT INTO `afhwp_postmeta` VALUES ("282","95","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("283","95","sk-options","a:1:{s:4:\"grid\";a:1:{s:16:\"load_more_button\";i:1;}}");
INSERT INTO `afhwp_postmeta` VALUES ("284","95","sf-options","a:1:{s:4:\"grid\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("285","95","sf_status","1");
INSERT INTO `afhwp_postmeta` VALUES ("286","96","label","");
INSERT INTO `afhwp_postmeta` VALUES ("287","96","category","");
INSERT INTO `afhwp_postmeta` VALUES ("288","96","location","");
INSERT INTO `afhwp_postmeta` VALUES ("289","96","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("290","96","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("291","96","author","");
INSERT INTO `afhwp_postmeta` VALUES ("292","96","skin","carousel");
INSERT INTO `afhwp_postmeta` VALUES ("293","96","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("294","96","sk-options","a:1:{s:8:\"carousel\";a:2:{s:5:\"count\";i:3;s:5:\"limit\";i:12;}}");
INSERT INTO `afhwp_postmeta` VALUES ("295","96","sf-options","a:1:{s:8:\"carousel\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("296","96","sf_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("297","97","label","");
INSERT INTO `afhwp_postmeta` VALUES ("298","97","category","");
INSERT INTO `afhwp_postmeta` VALUES ("299","97","location","");
INSERT INTO `afhwp_postmeta` VALUES ("300","97","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("301","97","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("302","97","author","");
INSERT INTO `afhwp_postmeta` VALUES ("303","97","skin","countdown");
INSERT INTO `afhwp_postmeta` VALUES ("304","97","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("305","97","sk-options","a:16:{s:4:\"list\";a:18:{s:5:\"style\";s:7:\"classic\";s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:20:\"classic_date_format1\";s:5:\"M d Y\";s:20:\"minimal_date_format1\";s:1:\"d\";s:20:\"minimal_date_format2\";s:1:\"M\";s:20:\"minimal_date_format3\";s:1:\"l\";s:19:\"modern_date_format1\";s:1:\"d\";s:19:\"modern_date_format2\";s:1:\"F\";s:19:\"modern_date_format3\";s:1:\"l\";s:21:\"standard_date_format1\";s:3:\"d M\";s:22:\"accordion_date_format1\";s:1:\"d\";s:22:\"accordion_date_format2\";s:1:\"F\";s:5:\"limit\";s:0:\"\";s:16:\"load_more_button\";s:1:\"1\";s:13:\"month_divider\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";s:20:\"toggle_month_divider\";s:1:\"0\";}s:4:\"grid\";a:20:{s:5:\"style\";s:7:\"classic\";s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:20:\"classic_date_format1\";s:5:\"d F Y\";s:18:\"clean_date_format1\";s:1:\"d\";s:18:\"clean_date_format2\";s:1:\"F\";s:20:\"minimal_date_format1\";s:1:\"d\";s:20:\"minimal_date_format2\";s:1:\"M\";s:19:\"modern_date_format1\";s:1:\"d\";s:19:\"modern_date_format2\";s:1:\"F\";s:19:\"modern_date_format3\";s:1:\"l\";s:19:\"simple_date_format1\";s:5:\"M d Y\";s:21:\"colorful_date_format1\";s:1:\"d\";s:21:\"colorful_date_format2\";s:1:\"F\";s:21:\"colorful_date_format3\";s:1:\"l\";s:18:\"novel_date_format1\";s:5:\"d F Y\";s:5:\"count\";s:1:\"1\";s:5:\"limit\";s:0:\"\";s:16:\"load_more_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:6:\"agenda\";a:9:{s:5:\"style\";s:5:\"clean\";s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:18:\"clean_date_format1\";s:1:\"l\";s:18:\"clean_date_format2\";s:3:\"F j\";s:5:\"limit\";s:0:\"\";s:16:\"load_more_button\";s:1:\"1\";s:13:\"month_divider\";s:1:\"0\";s:10:\"sed_method\";s:1:\"0\";}s:13:\"full_calendar\";a:11:{s:15:\"start_date_type\";s:19:\"start_current_month\";s:10:\"start_date\";s:0:\"\";s:12:\"default_view\";s:4:\"list\";s:13:\"monthly_style\";s:5:\"clean\";s:4:\"list\";s:1:\"1\";s:6:\"yearly\";s:1:\"1\";s:7:\"monthly\";s:1:\"1\";s:6:\"weekly\";s:1:\"1\";s:5:\"daily\";s:1:\"1\";s:13:\"display_price\";s:1:\"0\";s:10:\"sed_method\";s:1:\"0\";}s:11:\"yearly_view\";a:8:{s:5:\"style\";s:6:\"modern\";s:15:\"start_date_type\";s:18:\"start_current_year\";s:10:\"start_date\";s:0:\"\";s:19:\"modern_date_format1\";s:1:\"l\";s:19:\"modern_date_format2\";s:3:\"F j\";s:5:\"limit\";s:0:\"\";s:20:\"next_previous_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:12:\"monthly_view\";a:6:{s:5:\"style\";s:7:\"classic\";s:15:\"start_date_type\";s:19:\"start_current_month\";s:10:\"start_date\";s:0:\"\";s:5:\"limit\";s:0:\"\";s:20:\"next_previous_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:3:\"map\";a:4:{s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:5:\"limit\";s:3:\"200\";s:11:\"geolocation\";s:1:\"0\";}s:10:\"daily_view\";a:5:{s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:5:\"limit\";s:0:\"\";s:20:\"next_previous_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:11:\"weekly_view\";a:5:{s:15:\"start_date_type\";s:18:\"start_current_week\";s:10:\"start_date\";s:0:\"\";s:5:\"limit\";s:0:\"\";s:20:\"next_previous_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:9:\"timetable\";a:6:{s:5:\"style\";s:6:\"modern\";s:15:\"start_date_type\";s:18:\"start_current_week\";s:10:\"start_date\";s:0:\"\";s:5:\"limit\";s:0:\"\";s:20:\"next_previous_button\";s:1:\"1\";s:10:\"sed_method\";s:1:\"0\";}s:7:\"masonry\";a:8:{s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:12:\"date_format1\";s:1:\"j\";s:12:\"date_format2\";s:1:\"F\";s:5:\"limit\";s:0:\"\";s:9:\"filter_by\";s:0:\"\";s:17:\"masonry_like_grid\";s:1:\"0\";s:10:\"sed_method\";s:1:\"0\";}s:5:\"cover\";a:8:{s:5:\"style\";s:7:\"classic\";s:18:\"date_format_clean1\";s:1:\"d\";s:18:\"date_format_clean2\";s:1:\"M\";s:18:\"date_format_clean3\";s:1:\"Y\";s:20:\"date_format_classic1\";s:3:\"F d\";s:20:\"date_format_classic2\";s:1:\"l\";s:19:\"date_format_modern1\";s:8:\"l, F d Y\";s:8:\"event_id\";s:2:\"88\";}s:9:\"countdown\";a:8:{s:5:\"style\";s:6:\"style3\";s:19:\"date_format_style11\";s:5:\"j F Y\";s:19:\"date_format_style21\";s:5:\"j F Y\";s:19:\"date_format_style31\";s:1:\"j\";s:19:\"date_format_style32\";s:1:\"F\";s:19:\"date_format_style33\";s:1:\"Y\";s:8:\"event_id\";s:2:\"-1\";s:8:\"bg_color\";s:7:\"#1e73be\";}s:14:\"available_spot\";a:3:{s:12:\"date_format1\";s:1:\"j\";s:12:\"date_format2\";s:1:\"F\";s:8:\"event_id\";s:2:\"-1\";}s:8:\"carousel\";a:11:{s:5:\"style\";s:5:\"type1\";s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:18:\"type1_date_format1\";s:1:\"d\";s:18:\"type1_date_format2\";s:1:\"F\";s:18:\"type1_date_format3\";s:1:\"Y\";s:18:\"type2_date_format1\";s:6:\"M d, Y\";s:18:\"type3_date_format1\";s:6:\"M d, Y\";s:5:\"count\";s:1:\"2\";s:5:\"limit\";s:0:\"\";s:8:\"autoplay\";s:0:\"\";}s:6:\"slider\";a:20:{s:5:\"style\";s:2:\"t1\";s:15:\"start_date_type\";s:5:\"today\";s:10:\"start_date\";s:0:\"\";s:18:\"type1_date_format1\";s:1:\"d\";s:18:\"type1_date_format2\";s:1:\"F\";s:18:\"type1_date_format3\";s:1:\"l\";s:18:\"type2_date_format1\";s:1:\"d\";s:18:\"type2_date_format2\";s:1:\"F\";s:18:\"type2_date_format3\";s:1:\"l\";s:18:\"type3_date_format1\";s:1:\"d\";s:18:\"type3_date_format2\";s:1:\"F\";s:18:\"type3_date_format3\";s:1:\"l\";s:18:\"type4_date_format1\";s:1:\"d\";s:18:\"type4_date_format2\";s:1:\"F\";s:18:\"type4_date_format3\";s:1:\"l\";s:18:\"type5_date_format1\";s:1:\"d\";s:18:\"type5_date_format2\";s:1:\"F\";s:18:\"type5_date_format3\";s:1:\"l\";s:5:\"limit\";s:0:\"\";s:8:\"autoplay\";s:0:\"\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("306","97","sf-options","a:10:{s:4:\"list\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:4:\"grid\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:6:\"agenda\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:13:\"full_calendar\";a:3:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:12:\"monthly_view\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:11:\"yearly_view\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:3:\"map\";a:5:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:10:\"daily_view\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:11:\"weekly_view\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}s:9:\"timetable\";a:6:{s:8:\"category\";a:1:{s:4:\"type\";s:1:\"0\";}s:8:\"location\";a:1:{s:4:\"type\";s:1:\"0\";}s:9:\"organizer\";a:1:{s:4:\"type\";s:1:\"0\";}s:5:\"label\";a:1:{s:4:\"type\";s:1:\"0\";}s:12:\"month_filter\";a:1:{s:4:\"type\";s:1:\"0\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:1:\"0\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("307","97","sf_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("308","98","label","");
INSERT INTO `afhwp_postmeta` VALUES ("309","98","category","");
INSERT INTO `afhwp_postmeta` VALUES ("310","98","location","");
INSERT INTO `afhwp_postmeta` VALUES ("311","98","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("312","98","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("313","98","author","");
INSERT INTO `afhwp_postmeta` VALUES ("314","98","skin","slider");
INSERT INTO `afhwp_postmeta` VALUES ("315","98","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("316","98","sk-options","a:1:{s:6:\"slider\";a:3:{s:5:\"style\";s:2:\"t1\";s:5:\"limit\";i:6;s:8:\"autoplay\";i:3000;}}");
INSERT INTO `afhwp_postmeta` VALUES ("317","98","sf-options","a:1:{s:6:\"slider\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("318","98","sf_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("319","99","label","");
INSERT INTO `afhwp_postmeta` VALUES ("320","99","category","");
INSERT INTO `afhwp_postmeta` VALUES ("321","99","location","");
INSERT INTO `afhwp_postmeta` VALUES ("322","99","organizer","");
INSERT INTO `afhwp_postmeta` VALUES ("323","99","tag","");
INSERT INTO `afhwp_postmeta` VALUES ("324","99","author","");
INSERT INTO `afhwp_postmeta` VALUES ("325","99","skin","masonry");
INSERT INTO `afhwp_postmeta` VALUES ("326","99","show_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("327","99","sk-options","a:1:{s:7:\"masonry\";a:2:{s:5:\"limit\";i:24;s:9:\"filter_by\";s:8:\"category\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("328","99","sf-options","a:1:{s:7:\"masonry\";a:2:{s:8:\"category\";a:1:{s:4:\"type\";s:8:\"dropdown\";}s:11:\"text_search\";a:1:{s:4:\"type\";s:10:\"text_input\";}}}");
INSERT INTO `afhwp_postmeta` VALUES ("329","99","sf_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("330","99","_edit_lock","1542969843:1");
INSERT INTO `afhwp_postmeta` VALUES ("331","99","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("332","99","_wp_trash_meta_time","1542969990");
INSERT INTO `afhwp_postmeta` VALUES ("333","99","_wp_desired_post_slug","masonry-view");
INSERT INTO `afhwp_postmeta` VALUES ("334","97","_edit_lock","1542978561:1");
INSERT INTO `afhwp_postmeta` VALUES ("335","97","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("336","97","show_only_past_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("337","97","show_only_ongoing_events","0");
INSERT INTO `afhwp_postmeta` VALUES ("338","98","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("339","98","_wp_trash_meta_time","1542970283");
INSERT INTO `afhwp_postmeta` VALUES ("340","98","_wp_desired_post_slug","slider-view");
INSERT INTO `afhwp_postmeta` VALUES ("341","85","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("342","96","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("343","96","_wp_trash_meta_time","1542970642");
INSERT INTO `afhwp_postmeta` VALUES ("344","96","_wp_desired_post_slug","carousel-view");
INSERT INTO `afhwp_postmeta` VALUES ("345","94","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("346","94","_wp_trash_meta_time","1542970648");
INSERT INTO `afhwp_postmeta` VALUES ("347","94","_wp_desired_post_slug","upcoming-events-list");
INSERT INTO `afhwp_postmeta` VALUES ("348","93","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("349","93","_wp_trash_meta_time","1542970651");
INSERT INTO `afhwp_postmeta` VALUES ("350","93","_wp_desired_post_slug","map-view");
INSERT INTO `afhwp_postmeta` VALUES ("351","91","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("352","91","_wp_trash_meta_time","1542970689");
INSERT INTO `afhwp_postmeta` VALUES ("353","91","_wp_desired_post_slug","weekly-view");
INSERT INTO `afhwp_postmeta` VALUES ("354","92","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("355","92","_wp_trash_meta_time","1542970691");
INSERT INTO `afhwp_postmeta` VALUES ("356","92","_wp_desired_post_slug","daily-view");
INSERT INTO `afhwp_postmeta` VALUES ("357","90","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("358","90","_wp_trash_meta_time","1542970694");
INSERT INTO `afhwp_postmeta` VALUES ("359","90","_wp_desired_post_slug","monthly-view");
INSERT INTO `afhwp_postmeta` VALUES ("360","89","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("361","89","_wp_trash_meta_time","1542970701");
INSERT INTO `afhwp_postmeta` VALUES ("362","89","_wp_desired_post_slug","full-calendar");
INSERT INTO `afhwp_postmeta` VALUES ("363","88","_edit_lock","1542972151:1");
INSERT INTO `afhwp_postmeta` VALUES ("364","88","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("365","88","_wp_old_slug","yearly-on-august-20th-and-21st");
INSERT INTO `afhwp_postmeta` VALUES ("366","88","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("367","88","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("368","88","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("369","88","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("370","88","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("371","88","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("372","88","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("373","88","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("374","88","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("375","88","mec_hide_end_time","0");
INSERT INTO `afhwp_postmeta` VALUES ("376","88","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("377","88","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("378","88","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("379","88","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("380","88","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("381","88","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("382","88","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("383","88","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("384","88","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("385","88","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("386","88","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("387","88","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("388","88","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("389","88","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("390","88","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("391","88","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("392","127","_edit_lock","1542972015:1");
INSERT INTO `afhwp_postmeta` VALUES ("393","128","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("394","128","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("395","128","_et_pb_post_hide_nav","default");
INSERT INTO `afhwp_postmeta` VALUES ("396","128","_et_pb_page_layout","et_right_sidebar");
INSERT INTO `afhwp_postmeta` VALUES ("397","128","_et_pb_side_nav","off");
INSERT INTO `afhwp_postmeta` VALUES ("398","128","_et_pb_use_builder","on");
INSERT INTO `afhwp_postmeta` VALUES ("399","128","_et_builder_version","VB|Divi|3.0.98");
INSERT INTO `afhwp_postmeta` VALUES ("400","128","_et_pb_ab_stats_refresh_interval","hourly");
INSERT INTO `afhwp_postmeta` VALUES ("401","128","_et_pb_old_content","");
INSERT INTO `afhwp_postmeta` VALUES ("402","128","_et_pb_enable_shortcode_tracking","");
INSERT INTO `afhwp_postmeta` VALUES ("403","128","_et_pb_custom_css","");
INSERT INTO `afhwp_postmeta` VALUES ("404","128","_edit_lock","1542972055:1");
INSERT INTO `afhwp_postmeta` VALUES ("405","87","_edit_lock","1542972451:1");
INSERT INTO `afhwp_postmeta` VALUES ("406","131","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("407","131","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("408","131","_et_pb_post_hide_nav","default");
INSERT INTO `afhwp_postmeta` VALUES ("409","131","_et_pb_page_layout","et_right_sidebar");
INSERT INTO `afhwp_postmeta` VALUES ("410","131","_et_pb_side_nav","off");
INSERT INTO `afhwp_postmeta` VALUES ("411","131","_et_pb_use_builder","");
INSERT INTO `afhwp_postmeta` VALUES ("412","131","_et_builder_version","BB|Divi|3.0.98");
INSERT INTO `afhwp_postmeta` VALUES ("413","131","_et_pb_ab_stats_refresh_interval","hourly");
INSERT INTO `afhwp_postmeta` VALUES ("414","131","_et_pb_old_content","");
INSERT INTO `afhwp_postmeta` VALUES ("415","131","_et_pb_enable_shortcode_tracking","");
INSERT INTO `afhwp_postmeta` VALUES ("416","131","_et_pb_custom_css","");
INSERT INTO `afhwp_postmeta` VALUES ("417","131","_edit_lock","1542972448:1");
INSERT INTO `afhwp_postmeta` VALUES ("418","87","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("419","87","_wp_old_slug","monthly-on-27th");
INSERT INTO `afhwp_postmeta` VALUES ("420","87","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("421","87","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("422","87","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("423","87","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("424","87","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("425","87","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("426","87","mec_repeat","a:5:{s:4:\"type\";s:7:\"monthly\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("427","87","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("428","87","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("429","87","mec_hide_end_time","0");
INSERT INTO `afhwp_postmeta` VALUES ("430","87","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("431","87","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("432","87","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("433","87","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("434","87","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("435","87","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("436","87","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("437","87","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("438","87","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("439","87","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("440","87","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("441","87","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("442","87","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("443","87","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("444","87","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("445","86","_edit_lock","1542976291:1");
INSERT INTO `afhwp_postmeta` VALUES ("446","86","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("447","86","_wp_old_slug","weekly-on-mondays");
INSERT INTO `afhwp_postmeta` VALUES ("448","86","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("449","86","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("450","86","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("451","86","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("452","86","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("453","86","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("454","86","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("455","86","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("456","86","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("457","86","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("458","86","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("459","86","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("460","86","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("461","86","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("462","86","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("463","86","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("464","86","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("465","86","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("466","86","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("467","86","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("468","86","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("469","86","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("470","86","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("471","86","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("472","86","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("473","87","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("474","86","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("475","85","_edit_lock","1542974815:1");
INSERT INTO `afhwp_postmeta` VALUES ("476","85","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("477","85","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("478","85","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("479","85","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("480","85","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("481","85","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("482","85","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("483","85","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("484","85","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("485","85","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("486","85","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("487","85","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("488","85","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("489","85","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("490","85","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("491","85","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("492","85","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("493","85","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("494","85","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("495","85","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("496","85","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("497","85","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("498","85","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("499","85","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("500","85","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("501","85","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("502","85","_wp_old_slug","daily-each-3-days");
INSERT INTO `afhwp_postmeta` VALUES ("503","84","_edit_lock","1542974816:1");
INSERT INTO `afhwp_postmeta` VALUES ("504","84","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("505","84","_wp_old_slug","one-time-multiple-day-event");
INSERT INTO `afhwp_postmeta` VALUES ("506","84","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("507","84","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("508","84","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("509","84","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("510","84","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("511","84","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("512","84","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("513","84","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("514","84","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("515","84","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("516","84","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("517","84","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("518","84","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("519","84","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("520","84","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("521","84","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("522","84","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("523","84","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("524","84","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("525","84","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("526","84","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("527","84","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("528","84","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("529","84","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("530","84","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("531","136","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("532","136","_edit_lock","1542975005:1");
INSERT INTO `afhwp_postmeta` VALUES ("533","136","mec_color","00a0d2");
INSERT INTO `afhwp_postmeta` VALUES ("534","136","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("535","136","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("536","136","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("537","136","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("538","136","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("539","136","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("540","136","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("541","136","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("542","136","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("543","136","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-13\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-13\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("544","136","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("545","136","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("546","136","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("547","136","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("548","136","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("549","136","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("550","136","mec_start_date","2018-12-13");
INSERT INTO `afhwp_postmeta` VALUES ("551","136","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("552","136","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("553","136","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("554","136","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("555","136","mec_end_date","2018-12-13");
INSERT INTO `afhwp_postmeta` VALUES ("556","136","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("557","136","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("558","136","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("559","136","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("560","136","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("561","136","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("562","136","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("563","136","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("564","136","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("565","136","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("566","136","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("567","136","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("568","136","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("569","136","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("570","136","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("571","136","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("572","136","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("573","136","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("574","136","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("575","136","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("576","136","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("577","136","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("578","136","_wp_old_slug","kata-4-games");
INSERT INTO `afhwp_postmeta` VALUES ("579","137","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("580","137","_edit_lock","1542975664:1");
INSERT INTO `afhwp_postmeta` VALUES ("581","137","mec_color","00a0d2");
INSERT INTO `afhwp_postmeta` VALUES ("582","137","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("583","137","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("584","137","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("585","137","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("586","137","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("587","137","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("588","137","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("589","137","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("590","137","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("591","137","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-14\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-14\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("592","137","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("593","137","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("594","137","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("595","137","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("596","137","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("597","137","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("598","137","mec_start_date","2018-12-14");
INSERT INTO `afhwp_postmeta` VALUES ("599","137","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("600","137","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("601","137","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("602","137","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("603","137","mec_end_date","2018-12-14");
INSERT INTO `afhwp_postmeta` VALUES ("604","137","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("605","137","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("606","137","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("607","137","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("608","137","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("609","137","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("610","137","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("611","137","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("612","137","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("613","137","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("614","137","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("615","137","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("616","137","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("617","137","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("618","137","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("619","137","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("620","137","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("621","137","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("622","137","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("623","137","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("624","137","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("625","138","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("626","138","_edit_lock","1542975997:1");
INSERT INTO `afhwp_postmeta` VALUES ("627","137","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("628","138","mec_color","e14d43");
INSERT INTO `afhwp_postmeta` VALUES ("629","138","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("630","138","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("631","138","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("632","138","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("633","138","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("634","138","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("635","138","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("636","138","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("637","138","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("638","138","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-17\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-17\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("639","138","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("640","138","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("641","138","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("642","138","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("643","138","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("644","138","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("645","138","mec_start_date","2018-12-17");
INSERT INTO `afhwp_postmeta` VALUES ("646","138","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("647","138","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("648","138","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("649","138","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("650","138","mec_end_date","2018-12-17");
INSERT INTO `afhwp_postmeta` VALUES ("651","138","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("652","138","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("653","138","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("654","138","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("655","138","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("656","138","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("657","138","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("658","138","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("659","138","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("660","138","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("661","138","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("662","138","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("663","138","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("664","138","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("665","138","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("666","138","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("667","138","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("668","138","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("669","138","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("670","138","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("671","138","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("672","139","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("673","139","_edit_lock","1542976035:1");
INSERT INTO `afhwp_postmeta` VALUES ("674","139","mec_color","e14d43");
INSERT INTO `afhwp_postmeta` VALUES ("675","139","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("676","139","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("677","139","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("678","139","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("679","139","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("680","139","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("681","139","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("682","139","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("683","139","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("684","139","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-18\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-18\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("685","139","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("686","139","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("687","139","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("688","139","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("689","139","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("690","139","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("691","139","mec_start_date","2018-12-18");
INSERT INTO `afhwp_postmeta` VALUES ("692","139","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("693","139","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("694","139","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("695","139","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("696","139","mec_end_date","2018-12-18");
INSERT INTO `afhwp_postmeta` VALUES ("697","139","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("698","139","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("699","139","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("700","139","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("701","139","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("702","139","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("703","139","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("704","139","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("705","139","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("706","139","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("707","139","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("708","139","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("709","139","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("710","139","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("711","139","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("712","139","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("713","139","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("714","139","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("715","139","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("716","139","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("717","139","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("718","140","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("719","140","_edit_lock","1542976148:1");
INSERT INTO `afhwp_postmeta` VALUES ("720","140","mec_color","e14d43");
INSERT INTO `afhwp_postmeta` VALUES ("721","140","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("722","140","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("723","140","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("724","140","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("725","140","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("726","140","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("727","140","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("728","140","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("729","140","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("730","140","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-19\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-19\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("731","140","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("732","140","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("733","140","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("734","140","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("735","140","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("736","140","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("737","140","mec_start_date","2018-12-19");
INSERT INTO `afhwp_postmeta` VALUES ("738","140","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("739","140","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("740","140","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("741","140","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("742","140","mec_end_date","2018-12-19");
INSERT INTO `afhwp_postmeta` VALUES ("743","140","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("744","140","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("745","140","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("746","140","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("747","140","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("748","140","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("749","140","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("750","140","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("751","140","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("752","140","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("753","140","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("754","140","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("755","140","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("756","140","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("757","140","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("758","140","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("759","140","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("760","140","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("761","140","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("762","140","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("763","140","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("764","141","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("765","141","_edit_lock","1542976493:1");
INSERT INTO `afhwp_postmeta` VALUES ("766","140","_wp_old_slug","kata-7-array-series-2");
INSERT INTO `afhwp_postmeta` VALUES ("767","141","mec_color","e14d43");
INSERT INTO `afhwp_postmeta` VALUES ("768","141","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("769","141","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("770","141","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("771","141","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("772","141","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("773","141","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("774","141","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("775","141","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("776","141","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("777","141","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-20\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-20\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("778","141","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("779","141","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("780","141","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("781","141","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("782","141","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("783","141","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("784","141","mec_start_date","2018-12-20");
INSERT INTO `afhwp_postmeta` VALUES ("785","141","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("786","141","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("787","141","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("788","141","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("789","141","mec_end_date","2018-12-20");
INSERT INTO `afhwp_postmeta` VALUES ("790","141","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("791","141","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("792","141","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("793","141","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("794","141","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("795","141","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("796","141","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("797","141","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("798","141","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("799","141","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("800","141","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("801","141","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("802","141","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("803","141","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("804","141","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("805","141","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("806","141","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("807","141","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("808","141","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("809","141","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("810","141","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("811","140","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("812","142","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("813","142","_edit_lock","1542976493:1");
INSERT INTO `afhwp_postmeta` VALUES ("814","142","mec_color","e14d43");
INSERT INTO `afhwp_postmeta` VALUES ("815","142","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("816","142","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("817","142","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("818","142","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("819","142","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("820","142","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("821","142","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("822","142","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("823","142","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("824","142","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-21\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-11-23\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("825","142","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("826","142","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("827","142","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("828","142","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("829","142","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("830","142","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("831","142","mec_start_date","2018-12-21");
INSERT INTO `afhwp_postmeta` VALUES ("832","142","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("833","142","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("834","142","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("835","142","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("836","142","mec_end_date","2018-12-21");
INSERT INTO `afhwp_postmeta` VALUES ("837","142","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("838","142","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("839","142","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("840","142","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("841","142","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("842","142","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("843","142","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("844","142","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("845","142","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("846","142","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("847","142","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("848","142","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("849","142","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("850","142","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("851","142","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("852","142","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("853","142","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("854","142","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("855","142","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("856","142","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("857","142","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("858","143","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("859","143","_edit_lock","1542979873:1");
INSERT INTO `afhwp_postmeta` VALUES ("860","143","mec_color","fdd700");
INSERT INTO `afhwp_postmeta` VALUES ("861","143","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("862","143","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("863","143","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("864","143","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("865","143","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("866","143","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("867","143","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("868","143","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("869","143","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("870","143","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-18\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-19\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("871","143","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("872","143","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("873","143","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("874","143","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("875","143","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("876","143","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("877","143","mec_start_date","2018-12-18");
INSERT INTO `afhwp_postmeta` VALUES ("878","143","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("879","143","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("880","143","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("881","143","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("882","143","mec_end_date","2018-12-19");
INSERT INTO `afhwp_postmeta` VALUES ("883","143","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("884","143","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("885","143","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("886","143","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("887","143","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("888","143","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("889","143","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("890","143","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("891","143","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("892","143","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("893","143","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("894","143","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("895","143","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("896","143","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("897","143","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("898","143","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("899","143","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("900","143","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("901","143","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("902","143","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("903","143","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("904","144","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("905","144","_edit_lock","1542995102:1");
INSERT INTO `afhwp_postmeta` VALUES ("906","144","mec_color","fdd700");
INSERT INTO `afhwp_postmeta` VALUES ("907","144","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("908","144","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("909","144","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("910","144","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("911","144","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("912","144","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("913","144","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("914","144","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("915","144","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("916","144","mec_date","a:6:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-21\";s:4:\"hour\";s:1:\"5\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-21\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("917","144","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("918","144","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("919","144","mec_allday","0");
INSERT INTO `afhwp_postmeta` VALUES ("920","144","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("921","144","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("922","144","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("923","144","mec_start_date","2018-12-21");
INSERT INTO `afhwp_postmeta` VALUES ("924","144","mec_start_time_hour","5");
INSERT INTO `afhwp_postmeta` VALUES ("925","144","mec_start_time_minutes","0");
INSERT INTO `afhwp_postmeta` VALUES ("926","144","mec_start_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("927","144","mec_start_day_seconds","61200");
INSERT INTO `afhwp_postmeta` VALUES ("928","144","mec_end_date","2018-12-21");
INSERT INTO `afhwp_postmeta` VALUES ("929","144","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("930","144","mec_end_time_minutes","0");
INSERT INTO `afhwp_postmeta` VALUES ("931","144","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("932","144","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("933","144","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("934","144","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("935","144","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("936","144","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("937","144","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("938","144","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("939","144","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("940","144","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("941","144","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("942","144","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("943","144","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("944","144","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("945","144","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("946","144","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("947","144","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("948","144","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("949","144","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("950","145","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("951","145","_edit_lock","1542995104:1");
INSERT INTO `afhwp_postmeta` VALUES ("952","145","mec_color","dd823b");
INSERT INTO `afhwp_postmeta` VALUES ("953","145","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("954","145","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("955","145","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("956","145","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("957","145","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("958","145","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("959","145","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("960","145","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("961","145","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("962","145","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-21\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-24\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("963","145","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:1:\"1\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("964","145","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("965","145","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("966","145","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("967","145","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("968","145","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("969","145","mec_start_date","2018-12-21");
INSERT INTO `afhwp_postmeta` VALUES ("970","145","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("971","145","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("972","145","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("973","145","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("974","145","mec_end_date","2018-12-24");
INSERT INTO `afhwp_postmeta` VALUES ("975","145","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("976","145","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("977","145","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("978","145","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("979","145","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("980","145","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("981","145","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("982","145","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("983","145","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("984","145","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("985","145","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("986","145","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("987","145","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("988","145","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("989","145","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("990","145","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("991","145","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("992","145","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("993","145","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("994","145","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("995","145","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("996","147","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("997","147","_edit_lock","1542977354:1");
INSERT INTO `afhwp_postmeta` VALUES ("998","147","mec_color","a3b745");
INSERT INTO `afhwp_postmeta` VALUES ("999","147","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("1000","147","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("1001","147","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("1002","147","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("1003","147","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("1004","147","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("1005","147","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("1006","147","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("1007","147","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1008","147","mec_date","a:4:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-31\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-31\";s:4:\"hour\";s:1:\"5\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1009","147","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1010","147","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1011","147","mec_allday","0");
INSERT INTO `afhwp_postmeta` VALUES ("1012","147","mec_hide_time","0");
INSERT INTO `afhwp_postmeta` VALUES ("1013","147","mec_hide_end_time","0");
INSERT INTO `afhwp_postmeta` VALUES ("1014","147","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("1015","147","mec_start_date","2018-12-31");
INSERT INTO `afhwp_postmeta` VALUES ("1016","147","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("1017","147","mec_start_time_minutes","0");
INSERT INTO `afhwp_postmeta` VALUES ("1018","147","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("1019","147","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("1020","147","mec_end_date","2018-12-31");
INSERT INTO `afhwp_postmeta` VALUES ("1021","147","mec_end_time_hour","5");
INSERT INTO `afhwp_postmeta` VALUES ("1022","147","mec_end_time_minutes","0");
INSERT INTO `afhwp_postmeta` VALUES ("1023","147","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("1024","147","mec_end_day_seconds","61200");
INSERT INTO `afhwp_postmeta` VALUES ("1025","147","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("1026","147","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("1027","147","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("1028","147","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("1029","147","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("1030","147","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("1031","147","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("1032","147","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("1033","147","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1034","147","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1035","147","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1036","147","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1037","147","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1038","147","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1039","147","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1040","147","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1041","147","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1042","131","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1043","128","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1044","145","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1045","147","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1046","143","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1056","158","_menu_item_type","post_type");
INSERT INTO `afhwp_postmeta` VALUES ("1057","158","_menu_item_menu_item_parent","0");
INSERT INTO `afhwp_postmeta` VALUES ("1058","158","_menu_item_object_id","128");
INSERT INTO `afhwp_postmeta` VALUES ("1059","158","_menu_item_object","page");
INSERT INTO `afhwp_postmeta` VALUES ("1060","158","_menu_item_target","");
INSERT INTO `afhwp_postmeta` VALUES ("1061","158","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1062","158","_menu_item_xfn","");
INSERT INTO `afhwp_postmeta` VALUES ("1063","158","_menu_item_url","");
INSERT INTO `afhwp_postmeta` VALUES ("1092","162","_menu_item_type","custom");
INSERT INTO `afhwp_postmeta` VALUES ("1093","162","_menu_item_menu_item_parent","0");
INSERT INTO `afhwp_postmeta` VALUES ("1094","162","_menu_item_object_id","162");
INSERT INTO `afhwp_postmeta` VALUES ("1095","162","_menu_item_object","custom");
INSERT INTO `afhwp_postmeta` VALUES ("1096","162","_menu_item_target","");
INSERT INTO `afhwp_postmeta` VALUES ("1097","162","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1098","162","_menu_item_xfn","");
INSERT INTO `afhwp_postmeta` VALUES ("1099","162","_menu_item_url","/#checkpoints");
INSERT INTO `afhwp_postmeta` VALUES ("1101","167","_menu_item_type","custom");
INSERT INTO `afhwp_postmeta` VALUES ("1102","167","_menu_item_menu_item_parent","0");
INSERT INTO `afhwp_postmeta` VALUES ("1103","167","_menu_item_object_id","167");
INSERT INTO `afhwp_postmeta` VALUES ("1104","167","_menu_item_object","custom");
INSERT INTO `afhwp_postmeta` VALUES ("1105","167","_menu_item_target","");
INSERT INTO `afhwp_postmeta` VALUES ("1106","167","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1107","167","_menu_item_xfn","");
INSERT INTO `afhwp_postmeta` VALUES ("1108","167","_menu_item_url","/#hero");
INSERT INTO `afhwp_postmeta` VALUES ("1110","168","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("1111","168","_edit_lock","1542981022:1");
INSERT INTO `afhwp_postmeta` VALUES ("1112","168","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("1113","168","_et_pb_post_hide_nav","default");
INSERT INTO `afhwp_postmeta` VALUES ("1114","168","_et_pb_page_layout","et_right_sidebar");
INSERT INTO `afhwp_postmeta` VALUES ("1115","168","_et_pb_side_nav","off");
INSERT INTO `afhwp_postmeta` VALUES ("1116","168","_et_pb_use_builder","");
INSERT INTO `afhwp_postmeta` VALUES ("1117","168","_et_builder_version","BB|Divi|3.0.98");
INSERT INTO `afhwp_postmeta` VALUES ("1118","168","_et_pb_ab_stats_refresh_interval","hourly");
INSERT INTO `afhwp_postmeta` VALUES ("1119","168","_et_pb_old_content","");
INSERT INTO `afhwp_postmeta` VALUES ("1120","168","_et_pb_enable_shortcode_tracking","");
INSERT INTO `afhwp_postmeta` VALUES ("1121","168","_et_pb_custom_css","");
INSERT INTO `afhwp_postmeta` VALUES ("1122","170","_menu_item_type","post_type");
INSERT INTO `afhwp_postmeta` VALUES ("1123","170","_menu_item_menu_item_parent","0");
INSERT INTO `afhwp_postmeta` VALUES ("1124","170","_menu_item_object_id","168");
INSERT INTO `afhwp_postmeta` VALUES ("1125","170","_menu_item_object","page");
INSERT INTO `afhwp_postmeta` VALUES ("1126","170","_menu_item_target","");
INSERT INTO `afhwp_postmeta` VALUES ("1127","170","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1128","170","_menu_item_xfn","");
INSERT INTO `afhwp_postmeta` VALUES ("1129","170","_menu_item_url","");
INSERT INTO `afhwp_postmeta` VALUES ("1131","171","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("1132","171","_wp_page_template","default");
INSERT INTO `afhwp_postmeta` VALUES ("1133","171","_et_pb_post_hide_nav","default");
INSERT INTO `afhwp_postmeta` VALUES ("1134","171","_et_pb_page_layout","et_right_sidebar");
INSERT INTO `afhwp_postmeta` VALUES ("1135","171","_et_pb_side_nav","off");
INSERT INTO `afhwp_postmeta` VALUES ("1136","171","_et_pb_use_builder","on");
INSERT INTO `afhwp_postmeta` VALUES ("1137","171","_et_builder_version","VB|Divi|3.0.98");
INSERT INTO `afhwp_postmeta` VALUES ("1138","171","_et_pb_ab_stats_refresh_interval","hourly");
INSERT INTO `afhwp_postmeta` VALUES ("1139","171","_et_pb_old_content","");
INSERT INTO `afhwp_postmeta` VALUES ("1140","171","_et_pb_enable_shortcode_tracking","");
INSERT INTO `afhwp_postmeta` VALUES ("1141","171","_et_pb_custom_css","");
INSERT INTO `afhwp_postmeta` VALUES ("1142","171","_edit_lock","1542995002:1");
INSERT INTO `afhwp_postmeta` VALUES ("1143","173","_menu_item_type","post_type");
INSERT INTO `afhwp_postmeta` VALUES ("1144","173","_menu_item_menu_item_parent","0");
INSERT INTO `afhwp_postmeta` VALUES ("1145","173","_menu_item_object_id","171");
INSERT INTO `afhwp_postmeta` VALUES ("1146","173","_menu_item_object","page");
INSERT INTO `afhwp_postmeta` VALUES ("1147","173","_menu_item_target","");
INSERT INTO `afhwp_postmeta` VALUES ("1148","173","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1149","173","_menu_item_xfn","");
INSERT INTO `afhwp_postmeta` VALUES ("1150","173","_menu_item_url","");
INSERT INTO `afhwp_postmeta` VALUES ("1152","168","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1153","171","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1154","144","et_enqueued_post_fonts","a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-ubuntu\";s:63:\"Ubuntu:300,300italic,regular,italic,500,500italic,700,700italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1155","174","_edit_last","1");
INSERT INTO `afhwp_postmeta` VALUES ("1156","174","_edit_lock","1542995275:1");
INSERT INTO `afhwp_postmeta` VALUES ("1157","174","mec_color","dd823b");
INSERT INTO `afhwp_postmeta` VALUES ("1158","174","mec_location_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("1159","174","mec_dont_show_map","0");
INSERT INTO `afhwp_postmeta` VALUES ("1160","174","mec_organizer_id","1");
INSERT INTO `afhwp_postmeta` VALUES ("1161","174","mec_read_more","");
INSERT INTO `afhwp_postmeta` VALUES ("1162","174","mec_more_info","");
INSERT INTO `afhwp_postmeta` VALUES ("1163","174","mec_more_info_title","");
INSERT INTO `afhwp_postmeta` VALUES ("1164","174","mec_more_info_target","_self");
INSERT INTO `afhwp_postmeta` VALUES ("1165","174","mec_cost","");
INSERT INTO `afhwp_postmeta` VALUES ("1166","174","mec_additional_organizer_ids","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1167","174","mec_date","a:7:{s:5:\"start\";a:4:{s:4:\"date\";s:10:\"2018-12-24\";s:4:\"hour\";s:1:\"8\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"AM\";}s:3:\"end\";a:4:{s:4:\"date\";s:10:\"2018-12-28\";s:4:\"hour\";s:1:\"6\";s:7:\"minutes\";s:1:\"0\";s:4:\"ampm\";s:2:\"PM\";}s:6:\"allday\";s:1:\"1\";s:9:\"hide_time\";s:1:\"1\";s:13:\"hide_end_time\";s:1:\"1\";s:7:\"comment\";s:0:\"\";s:6:\"repeat\";a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}}");
INSERT INTO `afhwp_postmeta` VALUES ("1168","174","mec_repeat","a:5:{s:4:\"type\";s:5:\"daily\";s:8:\"interval\";s:0:\"\";s:3:\"end\";s:5:\"never\";s:11:\"end_at_date\";s:0:\"\";s:18:\"end_at_occurrences\";s:2:\"10\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1169","174","mec_certain_weekdays","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1170","174","mec_allday","1");
INSERT INTO `afhwp_postmeta` VALUES ("1171","174","mec_hide_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("1172","174","mec_hide_end_time","1");
INSERT INTO `afhwp_postmeta` VALUES ("1173","174","mec_comment","");
INSERT INTO `afhwp_postmeta` VALUES ("1174","174","mec_start_date","2018-12-24");
INSERT INTO `afhwp_postmeta` VALUES ("1175","174","mec_start_time_hour","8");
INSERT INTO `afhwp_postmeta` VALUES ("1176","174","mec_start_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("1177","174","mec_start_time_ampm","AM");
INSERT INTO `afhwp_postmeta` VALUES ("1178","174","mec_start_day_seconds","28800");
INSERT INTO `afhwp_postmeta` VALUES ("1179","174","mec_end_date","2018-12-28");
INSERT INTO `afhwp_postmeta` VALUES ("1180","174","mec_end_time_hour","6");
INSERT INTO `afhwp_postmeta` VALUES ("1181","174","mec_end_time_minutes","00");
INSERT INTO `afhwp_postmeta` VALUES ("1182","174","mec_end_time_ampm","PM");
INSERT INTO `afhwp_postmeta` VALUES ("1183","174","mec_end_day_seconds","64800");
INSERT INTO `afhwp_postmeta` VALUES ("1184","174","mec_repeat_status","0");
INSERT INTO `afhwp_postmeta` VALUES ("1185","174","mec_repeat_type","");
INSERT INTO `afhwp_postmeta` VALUES ("1186","174","mec_repeat_interval","1");
INSERT INTO `afhwp_postmeta` VALUES ("1187","174","mec_repeat_end","");
INSERT INTO `afhwp_postmeta` VALUES ("1188","174","mec_repeat_end_at_occurrences","");
INSERT INTO `afhwp_postmeta` VALUES ("1189","174","mec_repeat_end_at_date","");
INSERT INTO `afhwp_postmeta` VALUES ("1190","174","mec_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("1191","174","mec_not_in_days","");
INSERT INTO `afhwp_postmeta` VALUES ("1192","174","mec_hourly_schedules","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1193","174","mec_booking","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1194","174","mec_tickets","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1195","174","mec_fees_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1196","174","mec_fees","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1197","174","mec_ticket_variations_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1198","174","mec_ticket_variations","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1199","174","mec_reg_fields_global_inheritance","1");
INSERT INTO `afhwp_postmeta` VALUES ("1200","174","mec_reg_fields","a:0:{}");
INSERT INTO `afhwp_postmeta` VALUES ("1201","177","_form","<label> 
    [text* first-name placeholder=\"First Name (required)\"] </label>

<label> 
    [text* last-name placeholder=\"Last Name (required)\"] </label>

<label> 
    [email* your-email placeholder=\"Your Email (required)\"] </label>

<label>  
    [tel* phone-number placeholder=\"Phone Number(required)\"] </label>

<label> 
    [text* twitter-username placeholder=\"Twitter Username (required)\"] </label>

[submit \"Participate\"]");
INSERT INTO `afhwp_postmeta` VALUES ("1202","177","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:25:\"Afrihack \"[your-subject]\"\";s:6:\"sender\";s:35:\"[your-name] <wordpress@hack.africa>\";s:9:\"recipient\";s:24:\"ngunyimacharia@gmail.com\";s:4:\"body\";s:165:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `afhwp_postmeta` VALUES ("1203","177","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:25:\"Afrihack \"[your-subject]\"\";s:6:\"sender\";s:32:\"Afrihack <wordpress@hack.africa>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:107:\"Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)\";s:18:\"additional_headers\";s:34:\"Reply-To: ngunyimacharia@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `afhwp_postmeta` VALUES ("1204","177","_messages","a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1205","177","_additional_settings","");
INSERT INTO `afhwp_postmeta` VALUES ("1206","177","_locale","en_US");
INSERT INTO `afhwp_postmeta` VALUES ("1207","178","_email","ngunyimacharia@gmail.com");
INSERT INTO `afhwp_postmeta` VALUES ("1208","178","_name","ngunyimacharia");
INSERT INTO `afhwp_postmeta` VALUES ("1209","178","_props","a:2:{s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1210","178","_last_contacted","2018-11-24 10:24:51");
INSERT INTO `afhwp_postmeta` VALUES ("1211","128","_et_pb_use_ab_testing","off");
INSERT INTO `afhwp_postmeta` VALUES ("1212","128","_et_pb_ab_subjects","");
INSERT INTO `afhwp_postmeta` VALUES ("1213","128","_et_pb_ab_current_shortcode","[et_pb_split_track id=\"128\" /]");
INSERT INTO `afhwp_postmeta` VALUES ("1214","183","_wp_attached_file","2018/11/oladimeji-odunsi-558609-unsplash.jpg");
INSERT INTO `afhwp_postmeta` VALUES ("1215","183","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2035;s:6:\"height\";i:2544;s:4:\"file\";s:44:\"2018/11/oladimeji-odunsi-558609-unsplash.jpg\";s:5:\"sizes\";a:13:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-768x960.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"oladimeji-odunsi-558609-unsplash-819x1024.jpg\";s:5:\"width\";i:819;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumblist\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"meccarouselthumb\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-474x324.jpg\";s:5:\"width\";i:474;s:6:\"height\";i:324;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-post-main-image\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:31:\"et-pb-post-main-image-fullwidth\";a:4:{s:4:\"file\";s:45:\"oladimeji-odunsi-558609-unsplash-1080x675.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:675;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-portfolio-image\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"et-pb-portfolio-module-image\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"et-pb-portfolio-image-single\";a:4:{s:4:\"file\";s:46:\"oladimeji-odunsi-558609-unsplash-1080x1350.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:1350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:35:\"et-pb-gallery-module-image-portrait\";a:4:{s:4:\"file\";s:44:\"oladimeji-odunsi-558609-unsplash-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:37:\"et-pb-post-main-image-fullwidth-large\";a:4:{s:4:\"file\";s:46:\"oladimeji-odunsi-558609-unsplash-2035x1800.jpg\";s:5:\"width\";i:2035;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `afhwp_postmeta` VALUES ("1216","168","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1217","168","_wp_trash_meta_time","1542998969");
INSERT INTO `afhwp_postmeta` VALUES ("1218","168","_wp_desired_post_slug","about-us");
INSERT INTO `afhwp_postmeta` VALUES ("1219","215","_wp_attached_file","2018/11/photo-1498732528303-ceac1ff31508.jpg");
INSERT INTO `afhwp_postmeta` VALUES ("1220","215","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:667;s:4:\"file\";s:44:\"2018/11/photo-1498732528303-ceac1ff31508.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumblist\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"meccarouselthumb\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-474x324.jpg\";s:5:\"width\";i:474;s:6:\"height\";i:324;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-post-main-image\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"et-pb-portfolio-image\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"et-pb-portfolio-module-image\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:35:\"et-pb-gallery-module-image-portrait\";a:4:{s:4:\"file\";s:44:\"photo-1498732528303-ceac1ff31508-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `afhwp_postmeta` VALUES ("1221","216","_form","<label> Your Name (required)
    [text* your-name] </label>

<label> Your Email (required)
    [email* your-email] </label>

<label> Subject
    [text your-subject] </label>

<label> Your Message
    [textarea your-message] </label>

[submit \"Send\"]");
INSERT INTO `afhwp_postmeta` VALUES ("1222","216","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:25:\"Afrihack \"[your-subject]\"\";s:6:\"sender\";s:35:\"[your-name] <wordpress@hack.africa>\";s:9:\"recipient\";s:24:\"ngunyimacharia@gmail.com\";s:4:\"body\";s:165:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `afhwp_postmeta` VALUES ("1223","216","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:25:\"Afrihack \"[your-subject]\"\";s:6:\"sender\";s:32:\"Afrihack <wordpress@hack.africa>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:107:\"Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)\";s:18:\"additional_headers\";s:34:\"Reply-To: ngunyimacharia@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `afhwp_postmeta` VALUES ("1224","216","_messages","a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO `afhwp_postmeta` VALUES ("1225","216","_additional_settings","");
INSERT INTO `afhwp_postmeta` VALUES ("1226","216","_locale","en_US");
INSERT INTO `afhwp_postmeta` VALUES ("1227","171","_et_pb_use_ab_testing","off");
INSERT INTO `afhwp_postmeta` VALUES ("1228","171","_et_pb_ab_subjects","");
INSERT INTO `afhwp_postmeta` VALUES ("1229","171","_et_pb_ab_current_shortcode","[et_pb_split_track id=\"171\" /]");
INSERT INTO `afhwp_postmeta` VALUES ("1230","82","_customize_restore_dismissed","1");
INSERT INTO `afhwp_postmeta` VALUES ("1231","223","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1232","223","_wp_trash_meta_time","1543001685");
INSERT INTO `afhwp_postmeta` VALUES ("1233","224","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1234","224","_wp_trash_meta_time","1543003334");
INSERT INTO `afhwp_postmeta` VALUES ("1235","225","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1236","225","_wp_trash_meta_time","1543003797");
INSERT INTO `afhwp_postmeta` VALUES ("1237","226","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1238","226","_wp_trash_meta_time","1543003851");
INSERT INTO `afhwp_postmeta` VALUES ("1239","227","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1240","227","_wp_trash_meta_time","1543004081");
INSERT INTO `afhwp_postmeta` VALUES ("1241","228","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1242","228","_wp_trash_meta_time","1543004133");
INSERT INTO `afhwp_postmeta` VALUES ("1243","229","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1244","229","_wp_trash_meta_time","1543004189");
INSERT INTO `afhwp_postmeta` VALUES ("1245","230","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1246","230","_wp_trash_meta_time","1543004564");
INSERT INTO `afhwp_postmeta` VALUES ("1247","231","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1248","231","_wp_trash_meta_time","1543004632");
INSERT INTO `afhwp_postmeta` VALUES ("1249","232","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1250","232","_wp_trash_meta_time","1543004804");
INSERT INTO `afhwp_postmeta` VALUES ("1251","233","_edit_lock","1543004813:1");
INSERT INTO `afhwp_postmeta` VALUES ("1252","233","_wp_trash_meta_status","publish");
INSERT INTO `afhwp_postmeta` VALUES ("1253","233","_wp_trash_meta_time","1543004833");
INSERT INTO `afhwp_postmeta` VALUES ("1254","178","_wp_old_date","2018-11-23");


CREATE TABLE IF NOT EXISTS `afhwp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_posts` VALUES ("1","2","2018-11-23 09:06:34","2018-11-23 09:06:34","Welcome to WordPress. This is your first post. Edit or delete it, then start writing!","Hello world!","","trash","open","open","","hello-world__trashed","","","2018-11-23 09:20:49","2018-11-23 09:20:49","","0","http://hack.africa/?p=1","0","post","","0");
INSERT INTO `afhwp_posts` VALUES ("2","2","2018-11-23 09:06:34","2018-11-23 09:06:34","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" module_id=\"hero\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\" button_one_url=\"/register\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" module_id=\"checkpoints\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|54px|0px\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\" header_text_align=\"center\" header_font_size=\"35px\"]<h1>Checkpoints</h1>[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","publish","closed","open","","sample-page","","","2018-11-23 20:31:56","2018-11-23 20:31:56","","0","http://hack.africa/?page_id=2","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("3","2","2018-11-23 09:06:34","2018-11-23 09:06:34","<h2>Who we are</h2><p>Our website address is: http://hack.africa.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>","Privacy Policy","","draft","closed","open","","privacy-policy","","","2018-11-23 09:06:34","2018-11-23 09:06:34","","0","http://hack.africa/?page_id=3","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("4","2","2018-11-23 09:06:56","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2018-11-23 09:06:56","0000-00-00 00:00:00","","0","http://hack.africa/?p=4","0","post","","0");
INSERT INTO `afhwp_posts` VALUES ("5","2","2018-11-23 09:18:34","2018-11-23 09:18:34","[et_pb_section fullwidth=\"on\" background_color=\"#1f0030\"][et_pb_fullwidth_header title=\"Divi Builder\" background_layout=\"dark\" text_orientation=\"center\" scroll_down_icon_color=\"#ffffff\" scroll_down_icon_size=\"36px\" content_font_color=\"rgba(255,255,255,0.85)\" max_width=\"700px\" button_one_text=\"Join Now\" button_one_url=\"Join today\" background_overlay_color=\"rgba(40,40,48,0.8)\" title_font=\"Old Standard TT|on||on|\" title_font_size=\"62px\" title_font_size_phone=\"48px\" title_font_size_last_edited=\"on|phone\" content_font=\"Raleway||||\" content_font_size=\"20px\" custom_button_one=\"on\" button_one_text_size=\"16px\" button_one_text_color=\"#ffffff\" button_one_bg_color=\"#e85929\" button_one_border_width=\"0px\" button_one_border_radius=\"2px\" button_one_letter_spacing=\"3px\" button_one_font=\"Raleway|on||on|\" button_one_use_icon=\"off\" button_one_bg_color_hover=\"rgba(232,89,41,0.85)\" button_one_letter_spacing_hover=\"2px\" custom_css_main_element=\"padding: 6% 0 12% 0;\" custom_css_header_container=\"width: 100%;\" custom_css_button_1=\"margin-top: 40px;\" background_image=\"https://cdn.elegantthemes.com/images/tour/hummus2.jpg\" header_fullscreen=\"off\" header_scroll_down=\"off\" image_orientation=\"center\" content_orientation=\"center\" button_one_icon_placement=\"right\" custom_button_two=\"off\" button_two_letter_spacing=\"0\" button_two_icon_placement=\"right\" button_two_letter_spacing_hover=\"0\"]Divi 3.0 introduces a completely new visual interface that will forever change how you build websites. This front end editor allows you to make changes to your website...on your actual website![/et_pb_fullwidth_header][/et_pb_section][et_pb_section background_color=\"#efefe8\" custom_css_main_element=\"z-index: 999;\"][et_pb_row use_custom_gutter=\"on\" gutter_width=\"1\" custom_padding=\"0px||0px|\" custom_margin=\"-100px||60px|\" make_equal=\"on\" background_color_1=\"#ffffff\" background_color_2=\"#ffffff\" bg_img_1=\"https://cdn.elegantthemes.com/images/tour/limes.jpg\" bg_img_2=\"https://cdn.elegantthemes.com/images/tour/springrolls.jpg\" bg_img_3=\"https://cdn.elegantthemes.com/images/tour/eggs.jpg\" bg_img_4=\"https://cdn.elegantthemes.com/images/tour/lemons.jpg\" background_position_1=\"bottom_center\" background_position_2=\"bottom_center\" background_position_3=\"bottom_center\" background_position_4=\"bottom_center\" background_repeat_1=\"no-repeat\" background_repeat_2=\"no-repeat\" background_repeat_3=\"no-repeat\" background_repeat_4=\"no-repeat\" custom_css_main_element=\"overflow: visible !important;||-webkit-box-shadow: 0px 4px 30px 4px rgba(0,0,0,0.08);||-moz-box-shadow: 0px 4px 30px 4px rgba(0,0,0,0.08);||box-shadow: 0px 4px 30px 4px rgba(0,0,0,0.08);\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"][et_pb_column type=\"1_4\"][et_pb_blurb title=\"Click & type\" use_icon=\"on\" font_icon=\"%%119%%\" icon_color=\"rgba(46,48,55,0.38)\" animation=\"off\" text_orientation=\"center\" use_icon_font_size=\"on\" icon_font_size=\"32px\" header_font=\"Raleway|on||on|\" header_font_size=\"20\" header_text_color=\"#3a3e59\" body_font_size=\"16px\" body_text_color=\"rgba(46,48,55,0.5)\" body_line_height=\"1.8em\" use_background_color_gradient=\"on\" background_color_gradient_start=\"#ffffff\" background_color_gradient_end=\"rgba(255,255,255,0)\" custom_padding=\"40px|24px|140%|24px\" custom_css_blurb_title=\"margin-bottom: 10px;\" saved_tabs=\"all\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]<p>Lorem ipsum dolor sit amet consectetur adipiscing elit el vivamus eu vehicula.</p>[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb title=\"Drag & Drop\" use_icon=\"on\" font_icon=\"%%372%%\" icon_color=\"rgba(46,48,55,0.38)\" animation=\"off\" text_orientation=\"center\" use_icon_font_size=\"on\" icon_font_size=\"32px\" header_font=\"Raleway|on||on|\" header_font_size=\"20\" header_text_color=\"#3a3e59\" body_font_size=\"16px\" body_text_color=\"rgba(46,48,55,0.5)\" body_line_height=\"1.8em\" use_background_color_gradient=\"on\" background_color_gradient_start=\"#e4e4e4\" background_color_gradient_end=\"rgba(228,228,228,0)\" background_color_gradient_start_position=\"30%\" background_color_gradient_end_position=\"90%\" custom_padding=\"40px|24px|140%|24px\" custom_css_blurb_title=\"margin-bottom: 10px;\" saved_tabs=\"all\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]<p>Lorem ipsum dolor sit amet consectetur adipiscing elit el vivamus eu vehicula.</p>[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb title=\"Fully Customize\" use_icon=\"on\" font_icon=\"%%70%%\" icon_color=\"rgba(46,48,55,0.38)\" animation=\"off\" text_orientation=\"center\" use_icon_font_size=\"on\" icon_font_size=\"32px\" header_font=\"Raleway|on||on|\" header_font_size=\"20\" header_text_color=\"#3a3e59\" body_font_size=\"16px\" body_text_color=\"rgba(46,48,55,0.5)\" body_line_height=\"1.8em\" use_background_color_gradient=\"on\" background_color_gradient_start=\"#efefef\" background_color_gradient_end=\"rgba(239,239,239,0)\" background_color_gradient_start_position=\"30%\" background_color_gradient_end_position=\"90%\" custom_padding=\"40px|24px|140%|24px\" custom_css_blurb_title=\"margin-bottom: 10px;\" saved_tabs=\"all\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]<p>Lorem ipsum dolor sit amet consectetur adipiscing elit el vivamus eu vehicula.</p>[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb title=\"Clone & Delete\" use_icon=\"on\" font_icon=\"%%100%%\" icon_color=\"rgba(46,48,55,0.38)\" animation=\"off\" text_orientation=\"center\" use_icon_font_size=\"on\" icon_font_size=\"32px\" header_font=\"Raleway|on||on|\" header_font_size=\"20\" header_text_color=\"#3a3e59\" body_font_size=\"16px\" body_text_color=\"rgba(46,48,55,0.5)\" body_line_height=\"1.8em\" use_background_color_gradient=\"on\" background_color_gradient_start=\"#d7d9d9\" background_color_gradient_end=\"rgba(215,217,217,0)\" background_color_gradient_start_position=\"30%\" background_color_gradient_end_position=\"90%\" custom_padding=\"40px|24px|140%|24px\" custom_css_blurb_title=\"margin-bottom: 10px;\" saved_tabs=\"all\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]<p>Lorem ipsum dolor sit amet consectetur adipiscing elit el vivamus eu vehicula.</p>[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" custom_padding=\"0px|||\" background_color=\"#efefe8\"][et_pb_row custom_margin=\"|||\" padding_top_1=\"10%\" background_position_1=\"top_left\" background_position_2=\"top_left\" background_repeat_1=\"no-repeat\" background_repeat_2=\"no-repeat\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"][et_pb_column type=\"1_2\"][et_pb_blurb title=\"So simple!\" animation=\"off\" text_orientation=\"right\" header_font=\"Raleway|on||on|\" header_font_size=\"36px\" header_text_color=\"#3a3e59\" custom_css_main_element=\"max-width: none;\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tempus sed odio non blandit. Ut varius purus eget erat ornare facilisis. Mauris pharetra lacus nec sapien iaculis, sit amet ullamcorper sapien finibus.[/et_pb_blurb][et_pb_button button_text=\"Learn more\" button_alignment=\"right\" background_layout=\"dark\" disabled_on=\"on|on|\" custom_button=\"on\" button_text_size=\"16px\" button_text_color=\"#ffffff\" button_bg_color=\"#e85929\" button_border_width=\"0px\" button_border_radius=\"3px\" button_letter_spacing=\"3px\" button_font=\"Raleway|on||on|\" button_use_icon=\"off\" button_bg_color_hover=\"#e84712\" button_letter_spacing_hover=\"2px\" background_color=\"#7EBEC5\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_image src=\"https://cdn.elegantthemes.com/images/tour/jar.jpg\" align=\"center\" max_width=\"510px\" /][/et_pb_column][/et_pb_row][et_pb_row custom_margin=\"|||\" make_equal=\"on\" padding_top_2=\"14%\" background_position_1=\"top_left\" background_position_2=\"top_left\" background_repeat_1=\"no-repeat\" background_repeat_2=\"no-repeat\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"][et_pb_column type=\"1_2\"][et_pb_image src=\"https://cdn.elegantthemes.com/images/tour/cake.jpg\" animation=\"right\" align=\"center\" max_width=\"510px\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_blurb title=\"So sweet!\" animation=\"off\" header_font=\"Raleway|on||on|\" header_font_size=\"36px\" header_text_color=\"#3a3e59\" custom_css_main_element=\"max-width: none;\" background_position=\"top_left\" background_repeat=\"repeat\" background_size=\"initial\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tempus sed odio non blandit. Ut varius purus eget erat ornare facilisis. Mauris pharetra lacus nec sapien iaculis, sit amet ullamcorper sapien finibus.[/et_pb_blurb][et_pb_button button_text=\"Learn more\" button_alignment=\"left\" background_layout=\"dark\" disabled_on=\"on|on|\" custom_button=\"on\" button_text_size=\"16px\" button_text_color=\"#ffffff\" button_bg_color=\"#e85929\" button_border_width=\"0px\" button_border_radius=\"2px\" button_letter_spacing=\"3px\" button_font=\"Raleway|on||on|\" button_use_icon=\"off\" button_bg_color_hover=\"#e84712\" button_letter_spacing_hover=\"2px\" background_color=\"#7EBEC5\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section background_color=\"#212127\" custom_padding=\"|||\" fullwidth=\"on\"][et_pb_fullwidth_header title=\"Perfectly Diverse\" background_layout=\"dark\" text_orientation=\"center\" scroll_down_icon_color=\"#ffffff\" scroll_down_icon_size=\"36px\" content_font_color=\"rgba(255,255,255,0.72)\" button_one_text=\"Download\" background_overlay_color=\"rgba(255,255,255,0)\" title_font=\"Old Standard TT|on||on|\" title_font_size=\"62px\" title_font_size_tablet=\"62px\" title_font_size_phone=\"48px\" title_font_size_last_edited=\"on|phone\" content_font=\"Raleway||||\" content_font_size=\"20px\" content_text_color=\"#ffffff\" custom_button_one=\"on\" button_one_text_size=\"16px\" button_one_text_color=\"#ffffff\" button_one_bg_color=\"#e85929\" button_one_border_width=\"0px\" button_one_border_radius=\"2px\" button_one_letter_spacing=\"3px\" button_one_font=\"Raleway|on||on|\" button_one_use_icon=\"off\" button_one_bg_color_hover=\"rgba(232,89,41,0.85)\" button_one_letter_spacing_hover=\"2px\" custom_css_main_element=\"padding: 6% 0;\" custom_css_header_container=\"width: 100%;\" custom_css_button_1=\"margin-top: 40px;\"]<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer vel mollis eros. Vestibulum in blandit massa. Nunc lorem lacus, lacinia ut lobortis id, tempor a sem. Vivamus rhoncus imperdiet quam quis vestibulum. Sed at dui orci. </p>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fullwidth=\"on\"][et_pb_fullwidth_image src=\"https://cdn.elegantthemes.com/images/tour/cheese.jpg\" animation=\"off\" /][/et_pb_section]","Divi Builder Demo","","publish","closed","closed","","divi-builder-demo","","","2018-11-23 09:18:34","2018-11-23 09:18:34","","0","http://hack.africa/index.php/et_pb_layout/divi-builder-demo/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("6","2","2018-11-23 09:18:35","2018-11-23 09:18:35","[et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_slider admin_label=\"Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Welcome To My Website\" button_text=\"Enter\" button_link=\"#\" background_color=\"#27c9b9\" alignment=\"center\" background_layout=\"dark\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus.[/et_pb_slide][/et_pb_slider][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"on\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"We Are a Company of Passionate Designers and Developers\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"on\" font_icon=\"h\" icon_color=\"#a8a8a8\" use_circle=\"on\" circle_color=\"#ffffff\" use_circle_border=\"on\" circle_border_color=\"#e0e0e0\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"on\" font_icon=\"\" icon_color=\"#a8a8a8\" use_circle=\"on\" circle_color=\"#ffffff\" use_circle_border=\"on\" circle_border_color=\"#e0e0e0\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"on\" font_icon=\"v\" icon_color=\"#a8a8a8\" use_circle=\"on\" circle_color=\"#ffffff\" use_circle_border=\"on\" circle_border_color=\"#e0e0e0\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"on\" font_icon=\"g\" icon_color=\"#a8a8a8\" use_circle=\"on\" circle_color=\"#ffffff\" use_circle_border=\"on\" circle_border_color=\"#e0e0e0\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Drop Me a Line\" button_url=\"#\" button_text=\"Contact\" background_color=\"#2ea3f2\" use_background_color=\"on\" background_layout=\"dark\" text_orientation=\"center\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Basic","","publish","closed","closed","","homepage-basic","","","2018-11-23 09:18:35","2018-11-23 09:18:35","","0","http://hack.africa/index.php/et_pb_layout/homepage-basic/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("7","2","2018-11-23 09:18:36","2018-11-23 09:18:36","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Welcome to Our Shop\" button_text=\"Shop Now\" background_color=\"#0194f3\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" alignment=\"center\" background_layout=\"dark\" button_link=\"#\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Featured Products</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_shop admin_label=\"Shop\" type=\"featured\" posts_number=\"4\" columns=\"4\" orderby=\"menu_order\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_column type=\"3_4\" specialty_columns=\"3\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Recent Products</h1>[/et_pb_text][et_pb_shop admin_label=\"Shop\" type=\"recent\" posts_number=\"6\" columns=\"3\" orderby=\"date\" /][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"Holiday Special Sale\" button_text=\"Shop Now\" background_color=\"#108bf5\" use_background_color=\"on\" background_layout=\"dark\" text_orientation=\"center\" button_url=\"#\"]Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui.[/et_pb_cta][/et_pb_column_inner][et_pb_column_inner type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"Become a Vendor\" button_text=\"Learn More\" background_color=\"#27c9b9\" use_background_color=\"on\" background_layout=\"dark\" text_orientation=\"center\" button_url=\"#\"]Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui.[/et_pb_cta][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"right\" background_layout=\"light\" /][/et_pb_column][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h1>What Our Customers are Saying</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.\"[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.\"[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.\"[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio.\"[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#27c9b9\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Browse Our Full Shop\" button_url=\"#\" button_text=\"Enter\" use_background_color=\"off\" background_color=\"#108bf5\" background_layout=\"dark\" text_orientation=\"center\"]Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Shop","","publish","closed","closed","","homepage-shop","","","2018-11-23 09:18:36","2018-11-23 09:18:36","","0","http://hack.africa/index.php/et_pb_layout/homepage-shop/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("8","2","2018-11-23 09:18:36","2018-11-23 09:18:36","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2e2e2e\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"on\" parallax=\"on\"][et_pb_slide background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" heading=\"Hello! Welcome To My Online Portfolio\" /][et_pb_slide background_color=\"#f84b48\" alignment=\"center\" background_layout=\"dark\" heading=\"Project Title\" button_text=\"View Project\" /][et_pb_slide background_color=\"#23a1f5\" alignment=\"center\" background_layout=\"dark\" heading=\"Project Title\" button_text=\"View Project\" /][et_pb_slide background_color=\"#27c8b8\" alignment=\"center\" background_layout=\"dark\" heading=\"Project Title\" button_text=\"View Project\" /][/et_pb_fullwidth_slider][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"on\" show_title=\"on\" show_date=\"on\" background_layout=\"dark\" auto=\"off\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"left\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"40\" /][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet.[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Coding Languages\" number=\"7\" percent_sign=\"off\" background_layout=\"light\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Loyal Clients\" number=\"65\" percent_sign=\"off\" background_layout=\"light\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"International Awards\" number=\"12\" percent_sign=\"off\" background_layout=\"light\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Years of Experience\" number=\"10\" percent_sign=\"off\" background_layout=\"light\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#27c8b8\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"View My Full Portfolio\" button_url=\"#\" button_text=\"Enter\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis ac lorema ac tincidunt.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Portfolio","","publish","closed","closed","","homepage-portfolio","","","2018-11-23 09:18:36","2018-11-23 09:18:36","","0","http://hack.africa/index.php/et_pb_layout/homepage-portfolio/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("9","2","2018-11-23 09:18:36","2018-11-23 09:18:36","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Our Company\" button_text=\"Features\" button_link=\"https://elegantthemes.com/preview/Divi2/features/\" background_color=\"#8d1bf4\" alignment=\"center\" background_layout=\"dark\" image=\"https://elegantthemesimages.com/images/premade/d2-300px.png\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\"]Quisque eleifend orci sit amet est semper, iaculis tempor mi volutpat. Phasellus consectetur justo sed tristique molestie. Cras lectus quam, vehicula eu dictum a, sollicitudin id velit.[/et_pb_slide][et_pb_slide heading=\"Slide Title\" button_text=\"Learn More\" button_link=\"#\" background_color=\"#f84c48\" alignment=\"center\" background_layout=\"dark\"]Quisque eleifend orci sit amet est semper, iaculis tempor mi volutpat. Phasellus consectetur justo sed tristique molestie. Cras lectus quam, vehicula eu dictum a, sollicitudin id velit.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Cras semper dictum lectus ac bibendum. Sed id massa vel lorem laoreet molestie. Nullam vulputate lacus at mauris molestie porttitor.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Cras semper dictum lectus ac bibendum. Sed id massa vel lorem laoreet molestie. Nullam vulputate lacus at mauris molestie porttitor.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Cras semper dictum lectus ac bibendum. Sed id massa vel lorem laoreet molestie. Nullam vulputate lacus at mauris molestie porttitor.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#4b4b4b\" inner_shadow=\"on\" parallax=\"off\"][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" title=\"Recent Work\" fullwidth=\"on\" show_title=\"on\" show_date=\"on\" background_layout=\"dark\" auto=\"off\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#eeeeee\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"top\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"top\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"top\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"top\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" company_name=\"Company\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\" job_title=\"Job Role\" url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" company_name=\"Company\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\" job_title=\"Job Role\" url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_testimonial][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" company_name=\"Company\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\" job_title=\"Job Role\" url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" company_name=\"Company\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\" job_title=\"Job Role\" url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_map admin_label=\"Fullwidth Map\" zoom_level=\"8\" address_lat=\"37.43410184255073\" address_lng=\"-122.04768412931253\"][et_pb_map_pin title=\"Elegant Themes\" pin_address=\"San Francisco, CA, USA\" pin_address_lat=\"37.7749295\" pin_address_lng=\"-122.41941550000001\" /][et_pb_map_pin title=\"Lorem Ipsum\" pin_address=\"San Jose, CA, USA\" pin_address_lat=\"37.3393857\" pin_address_lng=\"-121.89495549999998\" /][/et_pb_fullwidth_map][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_contact_form admin_label=\"Contact Form\" captcha=\"off\" title=\"Contact Us\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Company","","publish","closed","closed","","homepage-company","","","2018-11-23 09:18:36","2018-11-23 09:18:36","","0","http://hack.africa/index.php/et_pb_layout/homepage-company/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("10","2","2018-11-23 09:18:36","2018-11-23 09:18:36","[et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Our Company\" button_text=\"Learn More\" button_link=\"#\" background_color=\"#f7f7f7\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" alignment=\"center\" background_layout=\"light\"]Changing the way you build websites. Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#3a4149\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_circle_counter admin_label=\"Circle Counter\" title=\"Sales & Marketing\" number=\"70\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_circle_counter admin_label=\"Circle Counter\" title=\"Brand & Identity\" number=\"90\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_circle_counter admin_label=\"Circle Counter\" title=\"Web Design\" number=\"80\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_circle_counter admin_label=\"Circle Counter\" title=\"App Development\" number=\"50\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"2_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>What We Offer</h2>[/et_pb_text][et_pb_tabs admin_label=\"Tabs\"][et_pb_tab title=\"Overview\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_tab][et_pb_tab title=\"Mission Statement\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_tab][et_pb_tab title=\"Culture\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_tab][/et_pb_tabs][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"50\" /][et_pb_counters admin_label=\"Bar Counters\" background_layout=\"light\" background_color=\"#f4f4f4\"][et_pb_counter percent=\"80\"]Brand Consulting[/et_pb_counter][et_pb_counter percent=\"45\"]Marketing Campaigns [/et_pb_counter][et_pb_counter percent=\"95\"]Custom Website Design[/et_pb_counter][/et_pb_counters][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#eaeaea\" show_divider=\"on\" height=\"30\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"left\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Our Work Flow</h1>[/et_pb_text][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Upsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Upsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Upsum\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"on\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#212a34\" inner_shadow=\"off\" parallax=\"off\" background_image=\"https://www.elegantthemesimages.com/images/premade/d2-placeholder-1920.png\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"20\" /][et_pb_blurb admin_label=\"Blurb\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-300px.png\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>Frequently Asked Questions</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet. Morbi mollis mollis pellentesque. Aenean vitae erat velit. Maecenas urna sapien, dignissim a augue vitae, porttitor luctus urna. Morbi scelerisque semper congue. Donec vitae congue quam. Pellentesque convallis est a eros porta, ut porttitor magna convallis.

Donec quis felis imperdiet, vestibulum est ut, pulvinar dolor. Mauris laoreet varius sem, tempus congue nibh elementum facilisis. Aliquam ut odio risus. Mauris consectetur mi et ante aliquam, eget posuere urna semper. Vestibulum vestibulum rhoncus enim, id iaculis eros commodo non.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_accordion admin_label=\"Accordion\"][et_pb_accordion_item title=\"What kind of clients do you work with?\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet.[/et_pb_accordion_item][et_pb_accordion_item title=\"What is your turn around time?\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet. Morbi mollis mollis pellentesque. Aenean vitae erat velit. Maecenas urna sapien, dignissim a augue vitae, porttitor luctus urna.[/et_pb_accordion_item][et_pb_accordion_item title=\"Do you have an affiliate program?\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquam justo et nibh venenatis aliquet. Morbi mollis mollis pellentesque. Aenean vitae erat velit. Maecenas urna sapien, dignissim a augue vitae, porttitor luctus urna.[/et_pb_accordion_item][/et_pb_accordion][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#eaeaea\" show_divider=\"on\" height=\"30\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" quote_icon=\"on\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt qu[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" quote_icon=\"on\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt qu[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Lorem Ipsum\" url_new_window=\"off\" quote_icon=\"on\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Aenean consectetur ipsum ante, vel egestas enim tincidunt qu[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f74b47\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Email\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\" title=\"Don\'t Be Shy\"]Drop us a line anytime, and one of our customer service reps will respond to you as soon as possible[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Corporate","","publish","closed","closed","","homepage-corporate","","","2018-11-23 09:18:36","2018-11-23 09:18:36","","0","http://hack.africa/index.php/et_pb_layout/homepage-corporate/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("11","2","2018-11-23 09:18:36","2018-11-23 09:18:36","[et_pb_section fullwidth=\"on\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"Welcome To Our Website\" button_text=\"Learn More\" button_link=\"#\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" video_bg_width=\"1920\" video_bg_height=\"638\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Cras venenatis ac lorema ac tincidunt. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue.[/et_pb_slide][et_pb_slide heading=\"Sky\'s The Limit\" background_color=\"#444444\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" alignment=\"center\" background_layout=\"dark\" button_text=\"A Closer Look\" button_link=\"#\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" animation=\"off\" background_layout=\"light\" text_orientation=\"left\" icon_placement=\"left\" font_icon=\"\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#7c4dd5\" circle_color=\"#7c4dd5\" circle_border_color=\"#2caaca\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" background_color=\"#27c9b8\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Get Started\" background_color=\"#7ebec5\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\"]</p><h1>Building a website has never been so fun.</h1><p>[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" background_color=\"#27323a\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]</p><h1>Lorem Ipsum Dolor.</h1><p>Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus dolor ipsum amet sit. Nec  eleifend tincidunt nisi.Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.</p><p>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1080px.jpg\" url_new_window=\"off\" animation=\"right\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"left\"]</p><h3>Lorem Ipsum</h3><p><span style=\"color: #bbbbbb;\">Vestibulum lobortis. Donec at euismod nibh, eu ibendum quam. Nullam non gravida puruipsum amet sdum it. Nec ele bulum lobortis. Donec at euismod nibh, eu biben</span></p><p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"left\"]</p><h3>Lorem Ipsum</h3><p><span style=\"color: #bbbbbb;\">Vestibulum lobortis. Donec at euismod nibh, eu ibendum quam. Nullam non gravida puruipsum amet sdum it. Nec ele bulum lobortis. Donec at euismod nibh, eu biben</span></p><p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"left\"]</p><h3>Lorem Ipsum</h3><p><span style=\"color: #bbbbbb;\">Vestibulum lobortis. Donec at euismod nibh, eu ibendum quam. Nullam non gravida puruipsum amet sdum it. Nec ele bulum lobortis. Donec at euismod nibh, eu biben</span></p><p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" background_color=\"#22262e\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Lorem Ipsum\" number=\"2700\" percent_sign=\"off\" counter_color=\"#815ab4\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Lorem Ipsum\" number=\"30\" percent_sign=\"off\" counter_color=\"#2caaca\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Lorem Ipsum\" number=\"87\" percent_sign=\"off\" counter_color=\"#35bbaa\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Lorem Ipsum\" number=\"999\" percent_sign=\"off\" counter_color=\"#ef6462\" background_layout=\"dark\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\"][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"on\" show_title=\"on\" show_date=\"on\" background_layout=\"dark\" auto=\"on\" /][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Slide Title Here\" button_text=\"Shop Now\" button_link=\"https://elegantthemes.com/preview/Divi2/shop-extended/\" background_color=\"#1a86cf\" alignment=\"center\" background_layout=\"dark\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus.[/et_pb_slide][et_pb_slide heading=\"Slide Title Here\" alignment=\"center\" background_layout=\"dark\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam er
os at, laoreet metus.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]</p><h1>Core Features</h1><p>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-builder.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2caaca\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-layouts.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2caaca\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" url=\"https://elegantthemes.com/preview/Divi2/features/#predefined\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-export.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2caaca\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" url=\"https://elegantthemes.com/preview/Divi2/features/#layouts\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-modules.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" icon_placement=\"top\" use_icon=\"off\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#2caaca\" circle_color=\"#2caaca\" circle_border_color=\"#2caaca\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-mobile.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2caaca\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" url=\"https://elegantthemes.com/preview/Divi2/features/#mobile\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-commerce.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2caaca\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\"]Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi. Fusce at purus in massa laoreet[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"Slide Title Here\" button_text=\"Our Work\" button_link=\"#\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi.Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" background_color=\"#283139\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]</p><h1>Versatile Layout Options</h1><p>Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus dolor ipsum amet sit.</p><p>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" icon_placement=\"left\" font_icon=\"R\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#ec6d5f\" circle_color=\"#2caaca\" circle_border_color=\"#2caaca\" animation=\"bottom\" background_layout=\"dark\" text_orientation=\"center\"]<span style=\"color: #bbbbbb;\">Donec at euismod nibh, eu bibendum.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" icon_placement=\"left\" font_icon=\"R\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#1fa0e3\" circle_color=\"#2caaca\" circle_border_color=\"#2caaca\" animation=\"right\" background_layout=\"dark\" text_orientation=\"center\"]<span style=\"color: #bbbbbb;\">Donec at euismod nibh, eu bibendum.[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" icon_placement=\"left\" font_icon=\"R\" use_icon=\"on\" use_circle=\"off\" use_circle_border=\"off\" icon_color=\"#47bfa4\" circle_color=\"#2caaca\" circle_border_color=\"#2caaca\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\"]<span style=\"color: #bbbbbb;\">Donec at euismod nibh, eu bibendum.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" url_new_window=\"off\" animation=\"bottom\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" url_new_window=\"off\" animation=\"bottom\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" background_color=\"#ec6d5f\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" background_color=\"#7ebec5\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\" button_url=\"#\" button_text=\"Join Now\"]</p><h1>Look No Further. Get Started Today</h1><p>[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Homepage Extended","","publish","closed","closed","","homepage-extended","","","2018-11-23 09:18:36","2018-11-23 09:18:36","","0","http://hack.africa/index.php/et_pb_layout/homepage-extended/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("12","2","2018-11-23 09:18:37","2018-11-23 09:18:37","[et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\" background_color=\"#2ea3f2\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Page Title\" subhead=\"Here is a basic page layout with no sidebar\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\"]
<h2>Just A Standard Page</h2>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Page Fullwidth","","publish","closed","closed","","page-fullwidth","","","2018-11-23 09:18:37","2018-11-23 09:18:37","","0","http://hack.africa/index.php/et_pb_layout/page-fullwidth/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("13","2","2018-11-23 09:18:37","2018-11-23 09:18:37","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"on\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Page Title\" subhead=\"Here is a basic page layout with a right sidebar\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\"][et_pb_column type=\"3_4\" specialty_columns=\"3\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_text admin_label=\"Text\"]
<h2>Just A Standard Page</h2>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"right\" background_layout=\"light\" /][/et_pb_column][/et_pb_section]","Page Right Sidebar","","publish","closed","closed","","page-right-sidebar","","","2018-11-23 09:18:37","2018-11-23 09:18:37","","0","http://hack.africa/index.php/et_pb_layout/page-right-sidebar/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("14","2","2018-11-23 09:18:37","2018-11-23 09:18:37","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Page With Left Sidebar\" subhead=\"Here is a basic page layout with a left sidebar\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\"][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"left\" background_layout=\"light\" /][/et_pb_column][et_pb_column type=\"3_4\" specialty_columns=\"3\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_text admin_label=\"Text\"]
<h2>Just A Standard Page</h2>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h4>Lorem Ipsum Dolor</h4>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][/et_pb_section]","Page Left Sidebar","","publish","closed","closed","","page-left-sidebar","","","2018-11-23 09:18:37","2018-11-23 09:18:37","","0","http://hack.africa/index.php/et_pb_layout/page-left-sidebar/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("15","2","2018-11-23 09:18:37","2018-11-23 09:18:37","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Page With Dual Sidebars\" subhead=\"Here is a basic page layout with dual sidebars\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\"][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"left\" background_layout=\"light\" /][/et_pb_column][et_pb_column type=\"1_2\" specialty_columns=\"2\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_text admin_label=\"Text\"]
<h2>Just A Standard Page</h2>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

Sed sit amet blandit ipsum, et consectetur libero. Integer convallis at metus quis molestie. Morbi vitae odio ut ante molestie scelerisque. Aliquam erat volutpat. Vivamus dignissim fringilla semper. Aliquam imperdiet dui a purus pellentesque, non ornare ipsum blandit. Sed imperdiet elit in quam egestas lacinia nec sit amet dui. Cras malesuada tincidunt ante, in luctus tellus hendrerit at. Duis massa mauris, bibendum a mollis a, laoreet quis elit. Nulla pulvinar vestibulum est, in viverra nisi malesuada vel. Nam ut ipsum quis est faucibus mattis eu ut turpis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nunc felis, venenatis in fringilla vel, tempus in turpis. Mauris aliquam dictum dolor at varius. Fusce sed vestibulum metus. Vestibulum dictum ultrices nulla sit amet fermentum.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][et_pb_column_inner type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]
<h3>Lorem Ipsum Dolor</h3>
Nunc et vestibulum velit. Suspendisse euismod eros vel urna bibendum gravida. Phasellus et metus nec dui ornare molestie. In consequat urna sed tincidunt euismod. Praesent non pharetra arcu, at tincidunt sapien. Nullam lobortis ultricies bibendum. Duis elit leo, porta vel nisl in, ullamcorper scelerisque velit. Fusce volutpat purus dolor, vel pulvinar dui porttitor sed. Phasellus ac odio eu quam varius elementum sit amet euismod justo.

[/et_pb_text][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"right\" background_layout=\"light\" /][/et_pb_column][/et_pb_section]","Page Dual Sidebars","","publish","closed","closed","","page-dual-sidebars","","","2018-11-23 09:18:37","2018-11-23 09:18:37","","0","http://hack.africa/index.php/et_pb_layout/page-dual-sidebars/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("16","2","2018-11-23 09:18:37","2018-11-23 09:18:37","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"My Work\" subhead=\"Your Subtitle Goes Here\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_filterable_portfolio admin_label=\"Filterable Portfolio\" fullwidth=\"off\" posts_number=\"12\" show_title=\"on\" show_categories=\"on\" show_pagination=\"off\" background_layout=\"light\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Like What You See?\" button_url=\"#\" button_text=\"Contact Me\" use_background_color=\"off\" background_color=\"#108bf5\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Portfolio Grid","","publish","closed","closed","","portfolio-grid","","","2018-11-23 09:18:37","2018-11-23 09:18:37","","0","http://hack.africa/index.php/et_pb_layout/portfolio-grid/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("17","2","2018-11-23 09:18:38","2018-11-23 09:18:38","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" inner_shadow=\"off\" parallax=\"on\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"My Work\" subhead=\"Your Subtitle Goes Here\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_portfolio admin_label=\"Portfolio\" fullwidth=\"on\" posts_number=\"4\" show_title=\"on\" show_categories=\"on\" show_pagination=\"on\" background_layout=\"light\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"I Love Working With Creative Minds\" button_url=\"#\" button_text=\"Contact Me\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\"]If you are interested in working together, send me an inquiry and I will get back to you as soon as I can![/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Portfolio 1 Column","","publish","closed","closed","","portfolio-1-column","","","2018-11-23 09:18:38","2018-11-23 09:18:38","","0","http://hack.africa/index.php/et_pb_layout/portfolio-1-column/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("18","2","2018-11-23 09:18:38","2018-11-23 09:18:38","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"on\" parallax=\"off\"][et_pb_slide background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][et_pb_slide background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][et_pb_slide background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][/et_pb_fullwidth_slider][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"on\" show_title=\"on\" show_date=\"on\" background_layout=\"light\" auto=\"off\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Let\'s Build Something Together\" button_url=\"#\" button_text=\"Contact Me\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Portfolio Fullwidth Carousel","","publish","closed","closed","","portfolio-fullwidth-carousel","","","2018-11-23 09:18:38","2018-11-23 09:18:38","","0","http://hack.africa/index.php/et_pb_layout/portfolio-fullwidth-carousel/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("19","2","2018-11-23 09:18:38","2018-11-23 09:18:38","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"off\" show_title=\"on\" show_date=\"on\" background_layout=\"dark\" auto=\"off\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Interested In Working On A Project?\" button_url=\"#\" button_text=\"Contact Me\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Portfolio Fullwidth Grid","","publish","closed","closed","","portfolio-fullwidth-grid","","","2018-11-23 09:18:38","2018-11-23 09:18:38","","0","http://hack.africa/index.php/et_pb_layout/portfolio-fullwidth-grid/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("20","2","2018-11-23 09:18:38","2018-11-23 09:18:38","[et_pb_section background_color=\"#3a3a3a\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_blurb admin_label=\"Blurb\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#45c4ec\" use_circle=\"off\" circle_color=\"#45c4ec\" use_circle_border=\"off\" circle_border_color=\"#45c4ec\" icon_placement=\"top\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h1 style=\"font-size: 72px; font-weight: 300;\">Your Project Name</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>The Challenge</h2>
Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>The Solution</h2>
Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"on\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"Complete Corporate Identity\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][et_pb_slide heading=\"We Rethought Everything\" background_color=\"#2ea3f2\" alignment=\"center\" background_layout=\"dark\" /][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#353535\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Corporate Rebranding\" number=\"70\" percent_sign=\"on\" background_layout=\"dark\" counter_color=\"#2ea3f2\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Website Redesign\" number=\"30\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Day Turnaround\" number=\"60\" percent_sign=\"off\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Amazing Result\" number=\"1\" percent_sign=\"off\" background_layout=\"dark\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"90\" /][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"left\"]<h1>Mobile Site Boosted Sales By 50%</h1>[/et_pb_text][et_pb_blurb admin_label=\"Blurb\" title=\"Mobile Refresh\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Rebuilt From the Inside Out\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Extensive Demographic Studies\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/mobile-lockup.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#353535\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_counters admin_label=\"Bar Counters\" background_layout=\"light\" background_color=\"#2e2e2e\"][et_pb_counter percent=\"80\"]Mobile Sales[/et_pb_counter][et_pb_counter percent=\"50\"]Website Traffic[/et_pb_counter][et_pb_counter percent=\"75\"]Conversion Rate[/et_pb_counter][et_pb_counter percent=\"60\"]Email Subscribers[/et_pb_counter][/et_pb_counters][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"The Results Were Amazing\" button_url=\"#\" button_text=\"Live Project\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"left\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_cta][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"on\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"We Rethought Everything\" background_color=\"#2ea3f2\" alignment=\"center\" background_layout=\"dark\" /][et_pb_slide heading=\"Complete Corporate Identity\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Interested In Working With Us?\" button_url=\"#\" button_text=\"Get In Touch\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Project Extended","","publish","closed","closed","","project-extended","","","2018-11-23 09:18:38","2018-11-23 09:18:38","","0","http://hack.africa/index.php/et_pb_layout/project-extended/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("21","2","2018-11-23 09:18:39","2018-11-23 09:18:39","[et_pb_section][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Your Project Name</h1>[/et_pb_text][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" url_new_window=\"off\" animation=\"fade_in\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"3_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h4>Project Description</h4>
Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h4>Project Details</h4>
<strong>Client </strong>Client Name
<strong>Date </strong>Date of Completion
<strong>Skills </strong>Branding, Web Design
<strong>View </strong>elegantthemes.com[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][et_pb_cta admin_label=\"Call To Action\" title=\"Project Feature\" button_url=\"#\" button_text=\"Live Project\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"light\" text_orientation=\"left\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl quis nibh non, molestie tempus sapien.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"100\" /][et_pb_cta admin_label=\"Call To Action\" title=\"Project Feature\" button_url=\"#\" button_text=\"See More\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"light\" text_orientation=\"right\"]Vivamus ipsum velit, ullamcorper quis nibh, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_cta][/et_pb_column][et_pb_column type=\"2_3\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-700px.jpg\" url_new_window=\"off\" animation=\"right\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Like What You See?\" button_url=\"#\" button_text=\"Contact Us\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Project Extended 2","","publish","closed","closed","","project-extended-2","","","2018-11-23 09:18:39","2018-11-23 09:18:39","","0","http://hack.africa/index.php/et_pb_layout/project-extended-2/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("22","2","2018-11-23 09:18:39","2018-11-23 09:18:39","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"on\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Welcome to My Blog\" subhead=\"Here is a masonry blog layout with no sidebar\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_blog admin_label=\"Blog\" fullwidth=\"off\" posts_number=\"18\" meta_date=\"M j, Y\" show_thumbnail=\"on\" show_content=\"off\" show_author=\"on\" show_date=\"on\" show_categories=\"on\" show_pagination=\"on\" background_layout=\"light\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Blog Masonry","","publish","closed","closed","","blog-masonry","","","2018-11-23 09:18:39","2018-11-23 09:18:39","","0","http://hack.africa/index.php/et_pb_layout/blog-masonry/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("23","2","2018-11-23 09:18:39","2018-11-23 09:18:39","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"on\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Welcome to My Blog\" subhead=\"Here is a basic blog layout with a right sidebar\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\"][et_pb_column type=\"3_4\" specialty_columns=\"3\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_blog admin_label=\"Blog\" fullwidth=\"on\" posts_number=\"6\" meta_date=\"M j, Y\" show_thumbnail=\"on\" show_content=\"off\" show_author=\"on\" show_date=\"on\" show_categories=\"on\" show_pagination=\"on\" background_layout=\"light\" /][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"right\" background_layout=\"light\" /][/et_pb_column][/et_pb_section]","Blog Standard","","publish","closed","closed","","blog-standard","","","2018-11-23 09:18:39","2018-11-23 09:18:39","","0","http://hack.africa/index.php/et_pb_layout/blog-standard/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("24","2","2018-11-23 09:18:39","2018-11-23 09:18:39","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#f84b48\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"Welcome to Our Shop\" subhead=\"Divi gives you the power to run a full-fledged online storefront.\" background_layout=\"dark\" text_orientation=\"left\" /][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_shop admin_label=\"Shop\" type=\"recent\" posts_number=\"12\" columns=\"4\" orderby=\"menu_order\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"News & Events\" button_url=\"#\" button_text=\"Follow\" use_background_color=\"on\" background_color=\"#57ccc4\" background_layout=\"dark\" text_orientation=\"center\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Shop Basic","","publish","closed","closed","","shop-basic","","","2018-11-23 09:18:39","2018-11-23 09:18:39","","0","http://hack.africa/index.php/et_pb_layout/shop-basic/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("25","2","2018-11-23 09:18:39","2018-11-23 09:18:39","[et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#b2ede0\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"Our Shop\" button_text=\"Shop Now\" button_link=\"#\" background_color=\"#81dfde\" alignment=\"center\" background_layout=\"dark\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\"]Divi gives you the power to easily run a full-fledged online storefront. With the Divi Builder, you can create gorgeous shop pages, such as this one.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"on\"][et_pb_column type=\"3_4\" specialty_columns=\"3\"][et_pb_row_inner][et_pb_column_inner type=\"4_4\"][et_pb_shop admin_label=\"Shop\" type=\"recent\" posts_number=\"6\" columns=\"3\" orderby=\"menu_order\" /][/et_pb_column_inner][/et_pb_row_inner][et_pb_row_inner][et_pb_column_inner type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"Summer Sale!\" button_url=\"#\" button_text=\"Shop Now\" background_color=\"#ed5362\" use_background_color=\"on\" background_layout=\"dark\" text_orientation=\"center\"]For a limited time only, all of our vintage products are 50% off! Don\'t miss your chance to save big on these wonderful items.[/et_pb_cta][/et_pb_column_inner][et_pb_column_inner type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"Buy 2 Get 1 Free\" button_url=\"#\" button_text=\"Coupon Code\" background_color=\"#57ccc4\" use_background_color=\"on\" background_layout=\"dark\" text_orientation=\"center\"]For a limited time only, if you buy two of any item, you get the 3rd for free! Click below to redeem the coupon code to use at checkout.[/et_pb_cta][/et_pb_column_inner][/et_pb_row_inner][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_sidebar admin_label=\"Sidebar\" orientation=\"right\" background_layout=\"light\" /][/et_pb_column][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Our Most Popular Items</h1>[/et_pb_text][et_pb_shop admin_label=\"Shop\" type=\"best_selling\" posts_number=\"4\" columns=\"4\" orderby=\"menu_order\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#57ccc4\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"View All of Our On-Sale Items\" button_url=\"#\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\" button_text=\"Shop Now\"]For a limited time only, all of our vintage products are 50% off! Don’t miss your chance to save big on these wonderful items.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Shop Extended","","publish","closed","closed","","shop-extended","","","2018-11-23 09:18:39","2018-11-23 09:18:39","","0","http://hack.africa/index.php/et_pb_layout/shop-extended/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("26","2","2018-11-23 09:18:40","2018-11-23 09:18:40","[et_pb_section background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"150\" /][et_pb_blurb admin_label=\"Blurb\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/d2-300px.png\" animation=\"bottom\" background_layout=\"dark\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#108bf5\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"top\"]<h1></h1>[/et_pb_blurb][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h4><strong>Lorem Ipsum Dolor</strong></h4>
Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h4><strong>Lorem Ipsum Dolor</strong></h4>
Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h4><strong>Lorem Ipsum Dolor</strong></h4>
Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante.[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_text=\"Enter\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\" button_url=\"#\" /][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"400\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Splash Page","","publish","closed","closed","","splash-page","","","2018-11-23 09:18:40","2018-11-23 09:18:40","","0","http://hack.africa/index.php/et_pb_layout/splash-page/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("27","2","2018-11-23 09:18:40","2018-11-23 09:18:40","[et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][et_pb_blurb admin_label=\"Blurb\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-builder.jpg\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>We will Be back Soon</h1>
This is an example of a blank page with no header or footer.[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Undergoing Maintenance\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#63cde3\" use_circle=\"on\" circle_color=\"#f7f7f7\" use_circle_border=\"on\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Divi is here to stay, and you can rest easy knowing that our team will be updating and improving it for years to come.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Feature Updates\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#63cde3\" use_circle=\"on\" circle_color=\"#f7f7f7\" use_circle_border=\"on\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Divi is here to stay, and you can rest easy knowing that our team will be updating and improving it for years to come.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Bug Fixes\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#63cde3\" use_circle=\"on\" circle_color=\"#f7f7f7\" use_circle_border=\"on\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Divi is here to stay, and you can rest easy knowing that our team will be updating and improving it for years to come.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Contact Us\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Maintenance Mode","","publish","closed","closed","","maintenance-mode","","","2018-11-23 09:18:40","2018-11-23 09:18:40","","0","http://hack.africa/index.php/et_pb_layout/maintenance-mode/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("28","2","2018-11-23 09:18:40","2018-11-23 09:18:40","[et_pb_section inner_shadow=\"off\" parallax=\"off\" background_color=\"#8d1bf4\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"70\" /][et_pb_countdown_timer admin_label=\"Countdown Timer\" date_time=\"05/31/2014 05:15\" background_layout=\"dark\" background_color=\"#e03e3e\" use_background_color=\"off\" title=\"This Site Is Coming Soon\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_signup admin_label=\"Subscribe\" title=\"Sign Up to Receive Updates\" button_text=\"Submit\" background_color=\"#6e15c2\" use_background_color=\"on\" mailchimp_list=\"none\" background_layout=\"dark\" text_orientation=\"left\" provider=\"mailchimp\" aweber_list=\"none\"]Integer accumsan leo non nisi sollicitudin, sit amet eleifend dolor mollis. Donec sagittis posuere commodo. Aenean sed convallis lectus. Vivamus et nisi posuere erat aliquet adipiscing in non libero. Integer ornare dui at molestie dictum. Vivamus id aliquam urna. Duis quis fermentum lacus. Sed viverra dui leo, non auctor nisi porttitor a. Nunc a tristique lectus.[/et_pb_signup][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Contact Us\" background_color=\"#2caaca\" use_background_color=\"off\" background_layout=\"dark\" text_orientation=\"center\" /][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"600\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Coming Soon","","publish","closed","closed","","coming-soon","","","2018-11-23 09:18:40","2018-11-23 09:18:40","","0","http://hack.africa/index.php/et_pb_layout/coming-soon/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("29","2","2018-11-23 09:18:40","2018-11-23 09:18:40","[et_pb_section background_color=\"#27323a\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h1 style=\"font-size: 72px;\">My Website</h1>
<h2><em>My Tagline</em></h2>[/et_pb_text][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1080px.jpg\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"fade_in\" /][et_pb_cta admin_label=\"Call To Action\" title=\"Lorem ipsum dolor sit amet consectetur.\" button_url=\"#\" button_text=\"Learn More\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section background_color=\"#313f55\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum Dolor\" url_new_window=\"off\" use_icon=\"off\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" icon_placement=\"top\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section background_color=\"#27323a\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1080px.jpg\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"right\" /][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Get Started\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section]","Landing Page","","publish","closed","closed","","landing-page","","","2018-11-23 09:18:40","2018-11-23 09:18:40","","0","http://hack.africa/index.php/et_pb_layout/landing-page/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("30","2","2018-11-23 09:18:40","2018-11-23 09:18:40","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"My Name\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\"]Subheading[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>This is My Story</h1>
Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis, lobortis turpis. Tam sociis natoque. Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes.[/et_pb_text][/et_pb_column][et_pb_column type=\"2_3\"][et_pb_counters admin_label=\"Bar Counters\" background_layout=\"light\" background_color=\"#dddddd\" bar_bg_color=\"#2ea3f2\"][et_pb_counter percent=\"80\"]Brand Strategy[/et_pb_counter][et_pb_counter percent=\"60\"]Internet Marketing[/et_pb_counter][et_pb_counter percent=\"50\"]App Development[/et_pb_counter][et_pb_counter percent=\"90\"]Customer Happiness[/et_pb_counter][/et_pb_counters][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" background_color=\"#108bf5\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_header admin_label=\"Fullwidth Header\" title=\"My Recent Work\" background_layout=\"dark\" text_orientation=\"center\" /][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"on\" show_title=\"on\" show_date=\"on\" background_layout=\"light\" auto=\"on\" /][/et_pb_section]","About Me","","publish","closed","closed","","about-me","","","2018-11-23 09:18:40","2018-11-23 09:18:40","","0","http://hack.africa/index.php/et_pb_layout/about-me/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("31","2","2018-11-23 09:18:41","2018-11-23 09:18:41","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"Our Company\" button_text=\"Learn More\" button_link=\"#\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\"]Our Company Tagline lorem ipsum dolor sit amet.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"A Digital Agency\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#7c8d9b\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Curabitur quis dui volutpat, cursus eros elut commodo elit cum sociis natoque penatibus[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Forward Thinking\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#7c8d9b\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Curabitur quis dui volutpat, cursus eros elut commodo elit cum sociis natoque penatibus[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Problem Solvers\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#7c8d9b\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Curabitur quis dui volutpat, cursus eros elut commodo elit cum sociis natoque penatibus[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Customer Support\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#7c8d9b\" use_circle=\"off\" circle_color=\"#2ea3f2\" use_circle_border=\"off\" circle_border_color=\"#2ea3f2\" icon_placement=\"top\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Curabitur quis dui volutpat, cursus eros elut commodo elit cum sociis natoque penatibus[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h1>Our Story</h1>
Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id est euismod, rhoncus nunc quis, lobortis turpis. Tam sociis natoque. Curabitur quis dui volutpat, cursus eros ut, commodo elit. Cum sociis natoque penatibus et magnis dis parturient montes.[/et_pb_text][/et_pb_column][et_pb_column type=\"2_3\"][et_pb_counters admin_label=\"Bar Counters\" background_layout=\"light\" background_color=\"#dddddd\" bar_bg_color=\"#2ea3f2\"][et_pb_counter percent=\"80\"]Brand Strategy[/et_pb_counter][et_pb_counter percent=\"60\"]Internet Marketing[/et_pb_counter][et_pb_counter percent=\"50\"]App Development[/et_pb_counter][et_pb_counter percent=\"90\"]Customer Happiness[/et_pb_counter][/et_pb_counters][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Team Member 1\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"light\" facebook_url=\"#\" twitter_url=\"#\" google_url=\"#\" linkedin_url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc.[/et_pb_team_member][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Team Member 1\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"light\" facebook_url=\"#\" twitter_url=\"#\" google_url=\"#\" linkedin_url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc.[/et_pb_team_member][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Team Member 1\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"light\" facebook_url=\"#\" twitter_url=\"#\" google_url=\"#\" linkedin_url=\"#\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc.[/et_pb_team_member][/et_pb_column][/et_pb_row][/et_pb_section]","About Us","","publish","closed","closed","","about-us","","","2018-11-23 09:18:41","2018-11-23 09:18:41","","0","http://hack.africa/index.php/et_pb_layout/about-us/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("32","2","2018-11-23 09:18:41","2018-11-23 09:18:41","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_map admin_label=\"Fullwidth Map\" zoom_level=\"9\" address_lat=\"37.77492949999972\" address_lng=\"-122.41941550000001\"][et_pb_map_pin title=\"Headquarters\" pin_address=\"San Francisco, CA, USA\" pin_address_lat=\"37.7749295\" pin_address_lng=\"-122.41941550000001\" /][/et_pb_fullwidth_map][/et_pb_section][et_pb_section fullwidth=\"off\"][et_pb_row][et_pb_column type=\"2_3\"][et_pb_contact_form admin_label=\"Contact Form\" captcha=\"off\" title=\"Get In Touch\" /][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h3>More Info</h3>
<p>sit amet, consectetur adipiscing elit. Integer placerat metus id orci facilisis, in luctus eros laoreet. Mauris interdum augue varius, faucibus massa id, imperdiet tortor. Donec vel tortor molestie, hendrerit sem a, hendrerit arcu. Aliquam erat volutpat. Proin varius eros eros, non condimentum nis.</p>

<strong>Address:</strong> 890 Lorem Ipsum Street #12
San Francisco, California 65432

<strong>Phone:</strong> 123.4567.890

<strong>Business Hours:</strong> 8a-6:30p M-F, 9a-2p S-S[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Contact Us","","publish","closed","closed","","contact-us","","","2018-11-23 09:18:41","2018-11-23 09:18:41","","0","http://hack.africa/index.php/et_pb_layout/contact-us/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("33","2","2018-11-23 09:18:41","2018-11-23 09:18:41","[et_pb_section background_color=\"#6aceb6\" inner_shadow=\"on\" fullwidth=\"on\"]
[et_pb_fullwidth_header title=\"About Our Team\" subhead=\"Your subtitle goes right here.\" background_layout=\"dark\"][/et_pb_fullwidth_header]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type=\"1_3\"]
[et_pb_image src=\"https://www.elegantthemesimages.com/images/premade_image_800x600.png\" animation=\"left\"][/et_pb_image]
[et_pb_text]
<h2>Nick Roach</h2>
<em>President, CEO, Theme UI/UX Designer</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent=\"50\"]Design & UX[/et_pb_counter]
[et_pb_counter percent=\"80\"]Web Programming[/et_pb_counter]
[et_pb_counter percent=\"10\"]Internet Marketing[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type=\"1_3\"]
[et_pb_image src=\"https://www.elegantthemesimages.com/images/premade_image_800x600.png\" animation=\"top\"][/et_pb_image]
[et_pb_text]
<h2>Kenny Sing</h2>
<em>Lead Graphic Designers</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent=\"85\"]Photoshop[/et_pb_counter]
[et_pb_counter percent=\"70\"]After Effects[/et_pb_counter]
[et_pb_counter percent=\"50\"]Illustrator[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]

[et_pb_column type=\"1_3\"]
[et_pb_image src=\"https://www.elegantthemesimages.com/images/premade_image_800x600.png\" animation=\"right\"][/et_pb_image]
[et_pb_text]
<h2>Mitch Skolnik</h2>
<em>Community Manager</em>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mattis nec nisi non luctus. Donec aliquam non nisi ut rutrum. In sit amet vestibulum felis, id aliquet ipsum. Vestibulum feugiat lacinia aliquet.
[/et_pb_text]
[et_pb_counters]
[et_pb_counter percent=\"80\"]Customer Happiness[/et_pb_counter]
[et_pb_counter percent=\"30\"]Tech Support[/et_pb_counter]
[et_pb_counter percent=\"50\"]Community Management[/et_pb_counter]
[/et_pb_counters]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color=\"#2d3743\" inner_shadow=\"on\"]
[et_pb_row]
[et_pb_column type=\"1_4\"]
[et_pb_blurb background_layout=\"dark\" image=\"https://www.elegantthemesimages.com/images/premade_blurb_5.png\"  title=\"Timely Support\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type=\"1_4\"]
[et_pb_blurb background_layout=\"dark\" image=\"https://www.elegantthemesimages.com/images/premade_blurb_6.png\"  title=\"Innovative Ideas\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type=\"1_4\"]
[et_pb_blurb background_layout=\"dark\" image=\"https://www.elegantthemesimages.com/images/premade_blurb_7.png\"  title=\"Advanced Technology\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[et_pb_column type=\"1_4\"]
[et_pb_blurb background_layout=\"dark\" image=\"https://www.elegantthemesimages.com/images/premade_blurb_8.png\"  title=\"Clear Communication\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec eleifend tincidunt nisi. Fusce at purus in massa laoreet.[/et_pb_blurb]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color=\"#f5f5f5\" inner_shadow=\"on\"]
[et_pb_row]
[et_pb_column type=\"4_4\"]
[et_pb_text text_orientation=\"center\"]<h2>Recent Blog Posts</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type=\"4_4\"]
[et_pb_blog fullwidth=\"off\" show_pagination=\"off\" posts_number=\"3\" meta_date=\"M j, Y\" show_thumbnail=\"on\" show_content=\"off\" show_author=\"on\" show_date=\"on\" show_categories=\"on\"][/et_pb_blog]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section]
[et_pb_row]
[et_pb_column type=\"4_4\"]
[et_pb_text text_orientation=\"center\"]<h2>Recent Projects</h2>
Learn from the top thought leaders in the industry.
[/et_pb_text]
[/et_pb_column]
[/et_pb_row]
[et_pb_row]
[et_pb_column type=\"4_4\"]
[et_pb_portfolio categories=\"Portfolio\" fullwidth=\"off\"][/et_pb_portfolio]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]

[et_pb_section background_color=\"#7EBEC5\"]
[et_pb_row]
[et_pb_column type=\"4_4\"]
[et_pb_cta title=\"Don\'t Be Shy. Get In Touch.\" button_url=\"#\" button_text=\"Contact Us\" background_layout=\"dark\" background_color=\"none\"]
If you are interested in working together, send us an inquiry and we will get back to you as soon as we can!
[/et_pb_cta]
[/et_pb_column]
[/et_pb_row]
[/et_pb_section]","Our Team","","publish","closed","closed","","our-team","","","2018-11-23 09:18:41","2018-11-23 09:18:41","","0","http://hack.africa/index.php/et_pb_layout/our-team/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("34","2","2018-11-23 09:18:41","2018-11-23 09:18:41","[et_pb_section fullwidth=\"on\" specialty=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"WE ARE A CREATIVE AGENCY\" button_text=\"Our Work\" button_link=\"https://elegantthemes.com/preview/Divi2/fullwidth-grid/\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-mobile.jpg\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#108bf5\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-export.jpg\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#108bf5\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-layouts.jpg\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#108bf5\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Lorem Ipsum\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/builder-blurbs-commerce.jpg\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#108bf5\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"top\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f7f7f7\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>OUR LATEST WORK</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_portfolio admin_label=\"Portfolio\" fullwidth=\"off\" posts_number=\"8\" show_title=\"on\" show_categories=\"off\" show_pagination=\"off\" background_layout=\"light\" /][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Full Portfolio\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#222b34\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h1>MEET THE CREW</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][et_pb_team_member admin_label=\"Team Member\" name=\"Lorem Ipsum\" position=\"Company Role\" image_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-320px.jpg\" animation=\"fade_in\" background_layout=\"dark\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Full Profiles\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>OUR CLIENTS</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://www.elegantthemesimages.com/images/premade/et-logo.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" button_url=\"#\" button_text=\"Full List\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"light\" text_orientation=\"center\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\" background_color=\"#2ea3f2\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_signup admin_label=\"Subscribe\" provider=\"mailchimp\" mailc
himp_list=\"none\" aweber_list=\"3423452\" button_text=\"Sign Me Up\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"left\" title=\"Connect With Us\"]Aenean consectetur ipsum ante, vel egestas enim tincidunt quis. Pellentesque vitae congue neque, vel mattis ante. In vitae tempus nunc. Etiam adipiscing enim sed condimentum ultrices. Cras rutrum blandit sem, molestie consequat erat luctus vel. Cras nunc est, laoreet sit amet ligula et, eleifend commodo dui. Vivamus id blandit nisi, eu mattis odio. Nulla facilisi. Aenean in mi odio. Etiam adipiscing enim sed condimentum ultrices.[/et_pb_signup][/et_pb_column][/et_pb_row][/et_pb_section]","Creative Agency","","publish","closed","closed","","creative-agency","","","2018-11-23 09:18:41","2018-11-23 09:18:41","","0","http://hack.africa/index.php/et_pb_layout/creative-agency/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("35","2","2018-11-23 09:18:41","2018-11-23 09:18:41","[et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"A Brand New Product\" background_color=\"#efefef\" image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" alignment=\"center\" background_layout=\"light\" button_text=\"Buy Now\"]The Divi Builder allows you to create beautiful and unique layouts visually, without touching a single line of code.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Gorgeous Design\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Drag & Drop Builder\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"1\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_blurb admin_label=\"Blurb\" title=\"Fully Responsive\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#2ea3f2\" use_circle=\"off\" circle_color=\"#108bf5\" use_circle_border=\"off\" circle_border_color=\"#108bf5\" icon_placement=\"left\" animation=\"top\" background_layout=\"light\" text_orientation=\"center\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f3f3f3\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>Plans and Pricing</h1>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus. Proin ac eros eros. Suspendisse auctor, eros ac sollicitudin vulputate.[/et_pb_text][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][et_pb_pricing_tables admin_label=\"Pricing Table\"][et_pb_pricing_table featured=\"off\" title=\"Basic\" currency=\"$\" per=\"yr\" sum=\"39\" button_url=\"https://elegantthemes.com/\" button_text=\"Sign Up\"]+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Themes</a>
+Perpetual Theme Updates
-Premium Technical Support
-Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees[/et_pb_pricing_table][et_pb_pricing_table featured=\"off\" title=\"Personal\" currency=\"$\" per=\"yr\" sum=\"69\" button_url=\"https://elegantthemes.com/\" button_text=\"Sign Up\"]+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Themes</a>
+Perpetual Theme Updates
+Premium Technical Support
-Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Plugins</a>
-Layered Photoshop Files
-No Yearly Fees[/et_pb_pricing_table][et_pb_pricing_table featured=\"on\" title=\"Developer\" subtitle=\"Best Value\" currency=\"$\" per=\"yr\" sum=\"89\" button_url=\"https://elegantthemes.com/\" button_text=\"Sign Up\"]+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Themes</a>
+Perpetual Theme Updates
+Premium Technical Support
+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Plugins</a>
+Layered Photoshop Files
-No Yearly Fees[/et_pb_pricing_table][et_pb_pricing_table featured=\"off\" title=\"Lifetime\" currency=\"$\" sum=\"249\" button_url=\"https://elegantthemes.com/\" button_text=\"Sign Up\"]+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Themes</a>
+Perpetual Theme Updates
+Premium Technical Support
+Access to <a href=\"https://elegantthemes.com/preview/Divi/module-pricing-tables/#\">All Plugins</a>
+Layered Photoshop Files
+No Yearly Fees[/et_pb_pricing_table][/et_pb_pricing_tables][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>What Our Customers Are Saying</h1>
Don\'t just take it from us, let our customers do the talking![/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Luke Chapman\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus. Proin ac eros eros. Suspendisse auctor, eros ac sollicitudin vulputate, urna arcu sodales quam, eget faucibus eros ante nec enim.

Etiam quis eros in enim molestie tempus a non urna. Suspendisse nibh massa, tristique sit amet interdum non, fermentum in quam. \"[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Luke Chapman\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus. Proin ac eros eros. Suspendisse auctor, eros ac sollicitudin vulputate, urna arcu sodales quam, eget faucibus eros ante nec enim.

Etiam quis eros in enim molestie tempus a non urna. Suspendisse nibh massa, tristique sit amet interdum non, fermentum in quam. \"[/et_pb_testimonial][/et_pb_column][et_pb_column type=\"1_3\"][et_pb_testimonial admin_label=\"Testimonial\" author=\"Luke Chapman\" url_new_window=\"off\" portrait_url=\"https://elegantthemesimages.com/images/premade/d2-placeholder-225px.png\" quote_icon=\"off\" use_background_color=\"on\" background_color=\"#f5f5f5\" background_layout=\"light\" text_orientation=\"left\"]\"Lorem ipsum dolor sit amet, consectetur adipiscing elit. In in risus eget lectus suscipit malesuada. Maecenas ut urna mollis, aliquam eros at, laoreet metus. Proin ac eros eros. Suspendisse auctor, eros ac sollicitudin vulputate, urna arcu sodales quam, eget faucibus eros ante nec enim.

Etiam quis eros in enim molestie tempus a non urna. Suspendisse nibh massa, tristique sit amet interdum non, fermentum in quam. \"[/et_pb_testimonial][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#eeeeee\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"bottom\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"bottom\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"bottom\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/et-logo.png\" show_in_lightbox=\"off\" url_new_window=\"off\" animation=\"bottom\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>Frequently Asked Questions</h1>[/et_pb_text][et_pb_toggle admin_label=\"Toggle\" title=\"Can I use the themes on multiple sites?\" open=\"off\"]Yes, you are free to use our themes on as many websites as you like. We do not place any restrictions on how many times you can download or use a theme, nor do we limit the number of domains that you can install our themes to.[/et_pb_toggle][et_pb_toggle admin_label=\"Toggle\" title=\"What is your refund policy?\" open=\"on\"]We offer no-questions-asked refunds to all customers within 30 days of your purchase. If you are not satisfied with our product, then simply send us an email and we will refund your purchase right away. Our goal has always been to create a happy, thriving community. If you are not thrilled with the product or are not enjoying the experience, then we have no interest in forcing you to stay an unhappy member.[/et_pb_toggle][et_pb_toggle admin_label=\"Toggle\" title=\"What are Photoshop Files?\" open=\"off\"]Elegant Themes offers two different packages: Personal and Developer. The Personal Subscription is ideal for the average user while the Developers License is meant for experienced designers who wish to customize their themes using the original Photoshop files. Photoshop files are the original design files that were used to create the theme. They can be opened using Adobe Photoshop and edited, and prove very useful for customers wishing to change their theme\'s design in some way.[/et_pb_toggle][et_pb_toggle admin_label=\"Toggle\" title=\"Can I upgrade after signing up?\" open=\"off\"]Yes, you can upgrade at any time after signing up. When you log in as a \"personal\" subscriber, you will see a notice regarding your current package and instructions on how to upgrade.[/et_pb_toggle][et_pb_toggle admin_label=\"Toggle\" title=\"Can I use your themes with WP.com?\" open=\"off\"]Unfortunately WordPress.com does not allow the use of custom themes. If you would like to use a custom theme of any kind, you will need to purchase your own hosting account and install the free software from WordPress.org. If you are looking for great WordPress hosting, we recommend giving HostGator a try.[/et_pb_toggle][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" inner_shadow=\"on\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Don\'t Be Shy\" button_url=\"#\" button_text=\"Get In Touch\" use_background_color=\"off\" background_color=\"#108bf5\" background_layout=\"dark\" text_orientation=\"center\"]If we didn\'t answer all of your questions, feel free to drop us a line anytime.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Sales Page","","publish","closed","closed","","sales-page","","","2018-11-23 09:18:41","2018-11-23 09:18:41","","0","http://hack.africa/index.php/et_pb_layout/sales-page/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("36","2","2018-11-23 09:18:42","2018-11-23 09:18:42","[et_pb_section background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_blurb admin_label=\"Blurb\" url_new_window=\"off\" image=\"https://elegantthemesimages.com/images/premade/d2-300px.png\" animation=\"bottom\" background_layout=\"light\" text_orientation=\"center\" use_icon=\"off\" icon_color=\"#45c4ec\" use_circle=\"off\" circle_color=\"#45c4ec\" use_circle_border=\"off\" circle_border_color=\"#45c4ec\" icon_placement=\"top\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h1 style=\"font-size: 72px; font-weight: 300;\">Divi Case Study</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>The Challenge</h2>
Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"left\"]<h2>The Solution</h2>
Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"on\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"on\"][et_pb_slide heading=\"Complete Corporate Identity\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][et_pb_slide heading=\"We Rethought Everything\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" /][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#353535\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Corporate Rebranding\" number=\"70\" percent_sign=\"on\" background_layout=\"dark\" counter_color=\"#2ea3f2\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Website Redesign\" number=\"30\" percent_sign=\"on\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Day Turnaround\" number=\"60\" percent_sign=\"off\" background_layout=\"dark\" /][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_number_counter admin_label=\"Number Counter\" title=\"Amazing Result\" number=\"1\" percent_sign=\"off\" background_layout=\"dark\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#2ea3f2\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"90\" /][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"left\"]<h1>Mobile Site Boosted Sales By 50%</h1>[/et_pb_text][et_pb_blurb admin_label=\"Blurb\" title=\"Mobile Refresh\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Rebuilt From the Inside Out\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][et_pb_blurb admin_label=\"Blurb\" title=\"Extensive Demographic Studies\" url_new_window=\"off\" use_icon=\"on\" font_icon=\"\" icon_color=\"#ffffff\" use_circle=\"off\" circle_color=\"#2caaca\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"left\" animation=\"right\" background_layout=\"dark\" text_orientation=\"left\"]The Challenge Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/mobile-lockup.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#353535\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_counters admin_label=\"Bar Counters\" background_layout=\"light\" background_color=\"#2e2e2e\"][et_pb_counter percent=\"80\"]Mobile Sales[/et_pb_counter][et_pb_counter percent=\"50\"]Website Traffic[/et_pb_counter][et_pb_counter percent=\"75\"]Conversion Rate[/et_pb_counter][et_pb_counter percent=\"60\"]Email Subscribers[/et_pb_counter][/et_pb_counters][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_cta admin_label=\"Call To Action\" title=\"The Results Were Amazing\" button_url=\"#\" button_text=\"Live Project\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"left\"]Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl. Vivamus ipsum velit, ullamcorper quis nibh non, molestie tempus sapien. Mauris ultrices, felis ut eleifend auctor, leo felis vehicula quam, ut accumsan augue nunc at nisl.[/et_pb_cta][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\" background_color=\"#2e2e2e\"][et_pb_fullwidth_portfolio admin_label=\"Fullwidth Portfolio\" fullwidth=\"on\" show_title=\"on\" show_date=\"off\" background_layout=\"dark\" auto=\"off\" title=\"Related Case Studies\" /][/et_pb_section]","Case Study","","publish","closed","closed","","case-study","","","2018-11-23 09:18:42","2018-11-23 09:18:42","","0","http://hack.africa/index.php/et_pb_layout/case-study/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("37","2","2018-11-23 09:18:42","2018-11-23 09:18:42","[et_pb_section background_color=\"#132c47\" inner_shadow=\"off\" parallax=\"on\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"60\" /][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]<h1 style=\"font-size: 52px;\">Product Features</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\" url_new_window=\"off\" animation=\"bottom\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Advanced Page Builder\" url_new_window=\"off\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\" use_icon=\"on\" use_circle=\"on\" circle_color=\"#0d2035\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" font_icon=\"\" icon_color=\"#2ea3f2\"]Divi will change the way you build websites forever. The advanced page builder makes it possible to build truly dynamic pages without learning code.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Key Elements\" url_new_window=\"off\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\" use_icon=\"on\" use_circle=\"on\" circle_color=\"#0d2035\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" font_icon=\"\" icon_color=\"#2ad4e0\"]The builder comes packed with tons of great modules, and more are on the way! Combine and arrange them in any order. The possibilities are countless.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Target Audience\" url_new_window=\"off\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\" use_icon=\"on\" icon_color=\"#9633e8\" use_circle=\"on\" circle_color=\"#0d2035\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" font_icon=\"\"]Divi’s layout has been designed with mobile devices in mind. No matter how you use it, and no matter how you view it, your website is going to look great.[/et_pb_blurb][/et_pb_column][et_pb_column type=\"1_4\"][et_pb_blurb admin_label=\"Blurb\" title=\"Strategy\" url_new_window=\"off\" image=\"https://elegantthemes.com/preview/Divi2/wp-content/uploads/2014/04/blurb-icon-updates.png\" animation=\"top\" background_layout=\"dark\" text_orientation=\"center\" use_icon=\"on\" icon_color=\"#d85fd6\" use_circle=\"on\" circle_color=\"#0d2035\" use_circle_border=\"off\" circle_border_color=\"#2caaca\" icon_placement=\"top\" font_icon=\"\"]Divi is here to stay, and you can rest easy knowing that our team will be updating and improving it for years to come. Build on top of a powerful foundation.[/et_pb_blurb][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" inner_shadow=\"off\" parallax=\"off\" module_id=\"builder\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"light\" text_orientation=\"center\"]<h1>Advanced Drag & Drop Builder</h1>
The Divi Builder was made with user experience at the forefront of its priorities. The way it is broken up into sections, rows, columns and widgets, really allows you to understand and edit the structure of your page. Your editing controls are pulled out of the main content area so that you get a clear and concise representation of how your modules fit into your page layout.[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1080px.jpg\" url_new_window=\"off\" animation=\"right\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"on\" specialty=\"off\" inner_shadow=\"off\" parallax=\"on\" module_id=\"backgrounds\"][et_pb_fullwidth_slider admin_label=\"Fullwidth Slider\" show_arrows=\"on\" show_pagination=\"on\" auto=\"off\" parallax=\"off\"][et_pb_slide heading=\"All The Right Things\" background_color=\"#ffffff\" alignment=\"center\" background_layout=\"dark\" background_image=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1920.png\"]Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi.Vestibulum lobortis. Donec at euismod nibh, eu bibendum quam. Nullam non gravida purus, nec  eleifend tincidunt nisi.[/et_pb_slide][/et_pb_fullwidth_slider][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#283139\" inner_shadow=\"off\" parallax=\"off\" module_id=\"mobile\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_text admin_label=\"Text\" background_layout=\"dark\" text_orientation=\"center\"]
<h1>Fully Responsive Layouts</h1>
We know that your website needs to be accessible and readable on all devices. We made Divi fully responsive so that your designs look great no matter what. With the builder, you design your desktop website, and we make sure that Divi does the heavy lifting for you.

[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"4_4\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-1080px.jpg\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" inner_shadow=\"off\" parallax=\"off\" module_id=\"layouts\"][et_pb_row][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" url_new_window=\"off\" animation=\"right\" show_in_lightbox=\"off\" /][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"70\" /][et_pb_cta admin_label=\"Call To Action\" title=\"Product Feature\" button_url=\"#\" button_text=\"Learn More\" use_background_color=\"off\" background_color=\"#2caaca\" background_layout=\"light\" text_orientation=\"left\"]Divi Ships with a tone of great premade layouts to get you started with a homepage, a portfolio, an eCommerce Storefront, and much more! Check out the theme demo to preview a few of these premade layouts. We\'ve even realeased layout packs along the way for portfolios and business focused websites.[/et_pb_cta][/et_pb_column][/et_pb_row][et_pb_row][et_pb_column type=\"1_2\"][et_pb_divider admin_label=\"Divider\" color=\"#ffffff\" show_divider=\"off\" height=\"40\" /][et_pb_cta admin_label=\"Call To Action\" title=\"Product Feature\" button_url=\"#\" button_text=\"Learn More\" use_background_color=\"off\" background_color=\"#2caaca\" background_layout=\"light\" text_orientation=\"right\"]Divi Ships with a tone of great premade layouts to get you started with a homepage, a portfolio, an eCommerce Storefront, and much more! Check out the theme demo to preview a few of these premade layouts. We\'ve even realeased layout packs along the way for portfolios and business focused websites.[/et_pb_cta][/et_pb_column][et_pb_column type=\"1_2\"][et_pb_image admin_label=\"Image\" src=\"https://elegantthemesimages.com/images/premade/d2-placeholder-510px.png\" url_new_window=\"off\" animation=\"left\" show_in_lightbox=\"off\" /][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fullwidth=\"off\" specialty=\"off\" background_color=\"#f74b47\" inner_shadow=\"off\" parallax=\"off\"][et_pb_row][et_pb_column type=\"4_4\"][et_pb_cta admin_label=\"Call To Action\" title=\"Signup Today For Instant Access\" button_url=\"#\" button_text=\"Join Today\" use_background_color=\"off\" background_color=\"#2ea3f2\" background_layout=\"dark\" text_orientation=\"center\"]Join today and get access to Divi, as well as our other countless themes and plugins.[/et_pb_cta][/et_pb_column][/et_pb_row][/et_pb_section]","Product Features","","publish","closed","closed","","product-features","","","2018-11-23 09:18:42","2018-11-23 09:18:42","","0","http://hack.africa/index.php/et_pb_layout/product-features/","0","et_pb_layout","","0");
INSERT INTO `afhwp_posts` VALUES ("38","2","2018-11-23 09:20:49","2018-11-23 09:20:49","Welcome to WordPress. This is your first post. Edit or delete it, then start writing!","Hello world!","","inherit","closed","closed","","1-revision-v1","","","2018-11-23 09:20:49","2018-11-23 09:20:49","","1","http://hack.africa/index.php/2018/11/23/1-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("39","2","2018-11-23 09:22:37","2018-11-23 09:22:37","","logo_cropped","","inherit","open","closed","","logo_cropped","","","2018-11-23 09:22:37","2018-11-23 09:22:37","","0","http://hack.africa/wp-content/uploads/2018/11/logo_cropped.png","0","attachment","image/png","0");
INSERT INTO `afhwp_posts` VALUES ("40","2","2018-11-23 09:26:46","2018-11-23 09:26:46","","favicon","","inherit","open","closed","","favicon","","","2018-11-23 09:26:46","2018-11-23 09:26:46","","0","http://hack.africa/wp-content/uploads/2018/11/favicon.png","0","attachment","image/png","0");
INSERT INTO `afhwp_posts` VALUES ("41","2","2018-11-23 09:27:03","2018-11-23 09:27:03","","Afrihack","","publish","closed","closed","","afrihack","","","2018-11-24 08:51:10","2018-11-24 08:51:10","","0","http://hack.africa/index.php/2018/11/23/afrihack/","0","custom_css","","0");
INSERT INTO `afhwp_posts` VALUES ("42","2","2018-11-23 09:27:03","2018-11-23 09:27:03","","Afrihack","","inherit","closed","closed","","41-revision-v1","","","2018-11-23 09:27:03","2018-11-23 09:27:03","","41","http://hack.africa/index.php/2018/11/23/41-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("43","2","2018-11-23 09:28:35","2018-11-23 09:28:35","{
    \"et_divi[nav_fullwidth]\": {
        \"value\": true,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    },
    \"et_divi[menu_height]\": {
        \"value\": \"30\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    },
    \"et_divi[logo_height]\": {
        \"value\": \"89\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    },
    \"et_divi[primary_nav_bg]\": {
        \"value\": \"#151515\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    },
    \"et_divi[footer_widget_text_color]\": {
        \"value\": \"#ffffff\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    },
    \"et_divi[footer_widget_link_color]\": {
        \"value\": \"#ffffff\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:28:35\"
    }
}","","","trash","closed","closed","","459e16bf-2e72-48d8-9bfe-7de5bfd148f8","","","2018-11-23 09:28:35","2018-11-23 09:28:35","","0","http://hack.africa/index.php/2018/11/23/459e16bf-2e72-48d8-9bfe-7de5bfd148f8/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("44","2","2018-11-23 09:33:39","2018-11-23 09:33:39","{
    \"blogdescription\": {
        \"value\": \"Learning through challenge\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:32:38\"
    },
    \"site_icon\": {
        \"value\": 40,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:32:38\"
    },
    \"et_divi[boxed_layout]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:32:38\"
    },
    \"et_divi[heading_font]\": {
        \"value\": \"Ubuntu\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:32:38\"
    },
    \"et_divi[accent_color]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:32:38\"
    },
    \"et_divi[body_font]\": {
        \"value\": \"Ubuntu\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:33:38\"
    },
    \"et_divi[link_color]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:33:38\"
    },
    \"et_divi[font_color]\": {
        \"value\": \"#0a0908\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:33:38\"
    },
    \"et_divi[header_color]\": {
        \"value\": \"#ffffff\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:33:38\"
    }
}","","","trash","closed","closed","","7dab8772-a5df-43cb-a309-dd8d0210d25f","","","2018-11-23 09:33:39","2018-11-23 09:33:39","","0","http://hack.africa/?p=44","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("45","2","2018-11-23 09:34:05","2018-11-23 09:34:05","{
    \"et_divi[link_color]\": {
        \"value\": \"#2e294e\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:34:05\"
    },
    \"et_divi[header_color]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:34:05\"
    }
}","","","trash","closed","closed","","891100d1-6a96-4a76-893c-c4dea5ee5a68","","","2018-11-23 09:34:05","2018-11-23 09:34:05","","0","http://hack.africa/index.php/2018/11/23/891100d1-6a96-4a76-893c-c4dea5ee5a68/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("46","2","2018-11-23 09:35:01","2018-11-23 09:35:01","{
    \"et_divi[header_style]\": {
        \"value\": \"left\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:34:38\"
    },
    \"et_divi[menu_link]\": {
        \"value\": \"rgba(255,255,255,0.56)\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:35:01\"
    },
    \"et_divi[menu_link_active]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:35:01\"
    },
    \"et_divi[primary_nav_dropdown_line_color]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:35:01\"
    }
}","","","trash","closed","closed","","3ee4bf3d-9abb-44d6-9023-7cfd535625f7","","","2018-11-23 09:35:01","2018-11-23 09:35:01","","0","http://hack.africa/?p=46","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("47","2","2018-11-23 09:36:59","2018-11-23 09:36:59","{
    \"et_divi[secondary_nav_bg]\": {
        \"value\": \"#151515\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:07\"
    },
    \"et_divi[secondary_nav_dropdown_bg]\": {
        \"value\": \"#0a0908\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:07\"
    },
    \"et_divi[fixed_secondary_nav_bg]\": {
        \"value\": \"#151515\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:07\"
    },
    \"et_divi[fixed_menu_link_active]\": {
        \"value\": \"#f40612\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:07\"
    },
    \"et_divi[show_header_social_icons]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:59\"
    },
    \"et_divi[show_search_icon]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:59\"
    },
    \"et_divi[show_footer_social_icons]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:59\"
    },
    \"et_divi[footer_bg]\": {
        \"value\": \"#0a0908\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:59\"
    },
    \"et_divi[disable_custom_footer_credits]\": {
        \"value\": true,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 09:36:59\"
    }
}","","","trash","closed","closed","","e461b137-55ff-4ee0-98eb-6968dba93940","","","2018-11-23 09:36:59","2018-11-23 09:36:59","","0","http://hack.africa/?p=47","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("48","2","2018-11-23 09:37:52","2018-11-23 09:37:52","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href=\"http://hack.africa/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 09:37:52","2018-11-23 09:37:52","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("49","2","2018-11-23 09:38:17","2018-11-23 09:38:17","","nesa-by-makers-701360-unsplash","","inherit","open","closed","","nesa-by-makers-701360-unsplash","","","2018-11-23 09:38:17","2018-11-23 09:38:17","","2","http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg","0","attachment","image/jpeg","0");
INSERT INTO `afhwp_posts` VALUES ("50","2","2018-11-23 09:42:04","2018-11-23 09:42:04","[et_pb_section admin_label=\"section\"]
		[et_pb_row admin_label=\"row\"]
			[et_pb_column type=\"4_4\"]
				[et_pb_text admin_label=\"Text\"]
					This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href=\"http://hack.africa/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!
				[/et_pb_text]
			[/et_pb_column]
		[/et_pb_row]
	[/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 09:42:04","2018-11-23 09:42:04","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("52","2","2018-11-23 10:05:32","2018-11-23 10:05:32","[et_pb_section fb_built=\"1\" fullwidth=\"on\" _builder_version=\"3.0.98\" disabled=\"on\" disabled_on=\"on|on|on\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" button_one_text=\"Register now\" button_two_text=\"About Us\" _builder_version=\"3.0.98\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" custom_margin=\"|||\" custom_padding=\"|||\" background_overlay_color=\"rgba(10,9,8,0.85)\" title_font=\"|||||on|||\" title_font_size=\"50px\" title_text_color=\"#f40612\" title_line_height=\"1.3em\" title_text_shadow_style=\"preset1\" title_text_shadow_color=\"#0a0908\" content_font=\"||||||||\" content_line_height=\"2em\" content_font_size=\"16px\" subhead_font=\"|300|||||||\" subhead_font_size=\"21px\" subhead_line_height=\"3em\" subhead_text_align=\"center\"]<p><span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span></p>
<p><span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span></p>
<p><span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge! <br /></span></p>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:05:32","2018-11-23 10:05:32","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("55","2","2018-11-23 10:09:52","2018-11-23 10:09:52","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\" disabled=\"on\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"50px\" title_text_color=\"#f40612\" title_line_height=\"1.3em\" title_text_shadow_style=\"preset1\" title_text_shadow_color=\"#0a0908\" content_font=\"||||||||\" content_font_size=\"16px\" content_line_height=\"2em\" subhead_font=\"|300|||||||\" subhead_text_align=\"center\" subhead_font_size=\"21px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<p><span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span></p>
<p><span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span></p>
<p><span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge! <br /></span></p>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:09:52","2018-11-23 10:09:52","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("56","2","2018-11-23 10:10:56","2018-11-23 10:10:56","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\" disabled=\"on\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"50px\" title_text_color=\"#f40612\" title_line_height=\"1.3em\" title_text_shadow_style=\"preset1\" title_text_shadow_color=\"#0a0908\" content_font=\"||||||||\" content_font_size=\"16px\" content_line_height=\"2em\" subhead_font=\"|300|||||||\" subhead_text_align=\"center\" subhead_font_size=\"21px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<p><span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span></p>
<p><span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span></p>
<p><span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge! <br /></span></p>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:10:56","2018-11-23 10:10:56","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("57","2","2018-11-23 10:11:31","2018-11-23 10:11:31","[et_pb_section bb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\" disabled=\"off\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"50px\" title_text_color=\"#f40612\" title_line_height=\"1.3em\" title_text_shadow_style=\"preset1\" title_text_shadow_color=\"#0a0908\" content_font=\"||||||||\" content_font_size=\"16px\" content_line_height=\"2em\" subhead_font=\"|300|||||||\" subhead_text_align=\"center\" subhead_font_size=\"21px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]

<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>

[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:11:31","2018-11-23 10:11:31","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("58","2","2018-11-23 10:13:25","2018-11-23 10:13:25","{
    \"et_divi[all_buttons_font_size]\": {
        \"value\": \"16\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 10:13:13\"
    },
    \"et_divi[all_buttons_border_radius]\": {
        \"value\": \"50\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 10:12:13\"
    },
    \"et_divi[all_buttons_text_color]\": {
        \"value\": \"#ffffff\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 10:13:13\"
    },
    \"et_divi[all_buttons_icon_placement]\": {
        \"value\": \"right\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 10:13:25\"
    }
}","","","trash","closed","closed","","bd56ab4d-b7d1-4274-8b2b-afbebcd86e78","","","2018-11-23 10:13:25","2018-11-23 10:13:25","","0","http://hack.africa/?p=58","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("60","2","2018-11-23 10:17:32","2018-11-23 10:17:32","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"1.8em\" subhead_font=\"|600||on|||||\" subhead_text_align=\"center\" subhead_font_size=\"23px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:17:32","2018-11-23 10:17:32","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("61","2","2018-11-23 10:18:03","2018-11-23 10:18:03","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_text_align=\"center\" subhead_font_size=\"23px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:18:03","2018-11-23 10:18:03","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("63","2","2018-11-23 10:18:37","2018-11-23 10:18:37","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"center\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_text_align=\"center\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:18:37","2018-11-23 10:18:37","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("65","2","2018-11-23 10:20:08","2018-11-23 10:20:08","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:20:08","2018-11-23 10:20:08","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("66","2","2018-11-23 10:25:00","2018-11-23 10:25:00","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p><code>[tminus t=\"31-12-2012 23:59:59\" <span class=\"highlight\">id=\"new-years-eve\"</span>/]</code></p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:25:00","2018-11-23 10:25:00","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("68","2","2018-11-23 10:25:34","2018-11-23 10:25:34","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p><code>[tminus t=\"10-12-2018 23:59:59\" <span class=\"highlight\">id=\"event-countdown\"</span>/]</code></p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:25:34","2018-11-23 10:25:34","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("70","2","2018-11-23 10:29:57","2018-11-23 10:29:57","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown style=”light”  date=”12-10-19”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:29:57","2018-11-23 10:29:57","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("71","2","2018-11-23 10:30:11","2018-11-23 10:30:11","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown style=”light”  date=”12-10-18”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:30:11","2018-11-23 10:30:11","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("73","2","2018-11-23 10:31:09","2018-11-23 10:31:09","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown style=”light”  date=”12/10/18”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:31:09","2018-11-23 10:31:09","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("75","2","2018-11-23 10:31:27","2018-11-23 10:31:27","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown style=”light”  date=”12/10/2018”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:31:27","2018-11-23 10:31:27","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("76","2","2018-11-23 10:31:49","2018-11-23 10:31:49","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown type=”light”  date=”12/10/2018”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:31:49","2018-11-23 10:31:49","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("78","2","2018-11-23 10:32:30","2018-11-23 10:32:30","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown type=”circular”  date=”12/10/2018”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:32:30","2018-11-23 10:32:30","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("79","2","2018-11-23 10:32:46","2018-11-23 10:32:46","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[cbfccountdown type=”circular”  date=”12/12/2018”  ]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:32:46","2018-11-23 10:32:46","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("81","2","2018-11-23 10:41:19","2018-11-23 10:41:19","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h1 style=\"text-align: center;\">Registration ends on December 7th, 2019</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:41:19","2018-11-23 10:41:19","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("82","2","2018-11-23 10:41:55","0000-00-00 00:00:00","{
    \"et_divi[body_header_style]\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 10:41:55\"
    }
}","","","auto-draft","closed","closed","","91478686-40ad-4129-ac74-c826492a20fd","","","2018-11-23 10:41:55","0000-00-00 00:00:00","","0","http://hack.africa/?p=82","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("84","2","2018-11-23 10:44:25","2018-11-23 10:44:25","<div class=\"row vg-header\">
<div class=\"col\">
<h5>Definition of algorithm<em>
</em></h5>
<ul>
 	<li><span class=\"dt hasSdSense\"><span class=\"dtText\">a procedure for solving a mathematical problem (as of finding the greatest common divisor) in a finite number of steps that frequently involves repetition of an operation </span></span></li>
 	<li><span class=\"sdsense\"><span class=\"dtText\">a step-by-step procedure for solving a problem or accomplishing some end</span></span></li>
</ul>
<p style=\"text-align: right;\"><a href=\"https://www.merriam-webster.com/dictionary/algorithm\"> Merriam Webster Dictionary</a></p>

</div>
</div>
This challenge will test the participant\'s ability to disect a problem and create a finite number of steps that will solve the problem.

<em>[Kata URL will be posted on 12th December 2018 12:00 AM]</em>","Kata #3: Algorithms","","publish","open","closed","","kata-3-algorithms","","","2018-11-23 12:09:16","2018-11-23 12:09:16","","0","http://hack.africa/index.php/events/one-time-multiple-day-event/","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("85","2","2018-11-23 10:44:26","2018-11-23 10:44:26","Does the participant understand different data types in the programming language? Does the participant understand the operations that can be undertaken on the specific data types and the different results for the same operation?

<em>[Kata URL will be posted on 11th December 2018 12:00 AM]</em>","Kata #2: Data Types","","publish","open","closed","","kata-2-data-types","","","2018-11-23 12:09:10","2018-11-23 12:09:10","","0","http://hack.africa/index.php/events/daily-each-3-days/","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("86","2","2018-11-23 10:44:27","2018-11-23 10:44:27","The first Kata will test the participant\'s knowledge of the programming language\'s fundamental concepts. This aims at ensuring that the participant has a general understanding of the language enough to undertake basic tasks.

<em>[Kata URL will be posted on 10th December 2018 12:00 AM]</em>","Kata #1: Fundamentals","","publish","open","closed","","kata-1-fundamentals","","","2018-11-23 12:09:04","2018-11-23 12:09:04","","0","http://hack.africa/index.php/events/weekly-on-mondays/","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("87","2","2018-11-23 10:44:28","2018-11-23 10:44:28","The final list of the participants will be published. This will be the official reference for those who are legible for prizes and recognition.

The final participant list will be published in the following page:  http://hack.africa/participants/","Publishing of participant list","","publish","open","closed","","publishing-of-participant-list","","","2018-11-23 11:28:38","2018-11-23 11:28:38","","0","http://hack.africa/index.php/events/monthly-on-27th/","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("88","2","2018-11-23 10:44:29","2018-11-23 10:44:29","This is the official deadline for challenge registration. At 11:59 pm, the registration form will no longer be available.

To register, use the following link: <a href=\"http://hack.africa/register/\">http://hack.africa/register/</a>","Registration Deadline","","publish","open","closed","","registration-deadline","","","2018-11-23 11:24:44","2018-11-23 11:24:44","","0","http://hack.africa/index.php/events/yearly-on-august-20th-and-21st/","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("89","2","2018-11-23 10:44:30","2018-11-23 10:44:30","MEC","Full Calendar","","trash","closed","closed","","full-calendar__trashed","","","2018-11-23 10:58:21","2018-11-23 10:58:21","","0","http://hack.africa/index.php/2018/11/23/full-calendar/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("90","2","2018-11-23 10:44:31","2018-11-23 10:44:31","MEC","Monthly View","","trash","closed","closed","","monthly-view__trashed","","","2018-11-23 10:58:14","2018-11-23 10:58:14","","0","http://hack.africa/index.php/2018/11/23/monthly-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("91","2","2018-11-23 10:44:32","2018-11-23 10:44:32","MEC","Weekly View","","trash","closed","closed","","weekly-view__trashed","","","2018-11-23 10:58:09","2018-11-23 10:58:09","","0","http://hack.africa/index.php/2018/11/23/weekly-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("92","2","2018-11-23 10:44:32","2018-11-23 10:44:32","MEC","Daily View","","trash","closed","closed","","daily-view__trashed","","","2018-11-23 10:58:11","2018-11-23 10:58:11","","0","http://hack.africa/index.php/2018/11/23/daily-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("93","2","2018-11-23 10:44:33","2018-11-23 10:44:33","MEC","Map View","","trash","closed","closed","","map-view__trashed","","","2018-11-23 10:57:31","2018-11-23 10:57:31","","0","http://hack.africa/index.php/2018/11/23/map-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("94","2","2018-11-23 10:44:34","2018-11-23 10:44:34","MEC","Upcoming events (List)","","trash","closed","closed","","upcoming-events-list__trashed","","","2018-11-23 10:57:28","2018-11-23 10:57:28","","0","http://hack.africa/index.php/2018/11/23/upcoming-events-list/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("95","2","2018-11-23 10:44:35","2018-11-23 10:44:35","MEC","Upcoming events (Grid)","","publish","closed","closed","","upcoming-events-grid","","","2018-11-23 10:44:35","2018-11-23 10:44:35","","0","http://hack.africa/index.php/2018/11/23/upcoming-events-grid/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("96","2","2018-11-23 10:44:35","2018-11-23 10:44:35","MEC","Carousel View","","trash","closed","closed","","carousel-view__trashed","","","2018-11-23 10:57:22","2018-11-23 10:57:22","","0","http://hack.africa/index.php/2018/11/23/carousel-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("97","2","2018-11-23 10:44:40","2018-11-23 10:44:40","MEC","Countdown View","","publish","closed","closed","","countdown-view","","","2018-11-23 12:54:50","2018-11-23 12:54:50","","0","http://hack.africa/index.php/2018/11/23/countdown-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("98","2","2018-11-23 10:44:42","2018-11-23 10:44:42","MEC","Slider View","","trash","closed","closed","","slider-view__trashed","","","2018-11-23 10:51:23","2018-11-23 10:51:23","","0","http://hack.africa/index.php/2018/11/23/slider-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("99","2","2018-11-23 10:44:43","2018-11-23 10:44:43","MEC","Masonry View","","trash","closed","closed","","masonry-view__trashed","","","2018-11-23 10:46:30","2018-11-23 10:46:30","","0","http://hack.africa/index.php/2018/11/23/masonry-view/","0","mec_calendars","","0");
INSERT INTO `afhwp_posts` VALUES ("100","2","2018-11-23 10:45:59","2018-11-23 10:45:59","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Registration ends on December 7th, 2019</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"99\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:45:59","2018-11-23 10:45:59","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("101","2","2018-11-23 10:46:40","2018-11-23 10:46:40","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Registration ends on December 7th, 2019</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"98\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:46:40","2018-11-23 10:46:40","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("103","2","2018-11-23 10:47:31","2018-11-23 10:47:31","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Registration ends on December 7th, 2019</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:47:31","2018-11-23 10:47:31","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("105","2","2018-11-23 10:51:42","2018-11-23 10:51:42","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Registration ends on December 7th, 2019</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:51:42","2018-11-23 10:51:42","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("107","2","2018-11-23 10:52:40","2018-11-23 10:52:40","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:52:40","2018-11-23 10:52:40","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("109","2","2018-11-23 10:54:02","2018-11-23 10:54:02","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:54:02","2018-11-23 10:54:02","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("111","2","2018-11-23 10:55:31","2018-11-23 10:55:31","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"94\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:55:31","2018-11-23 10:55:31","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("113","2","2018-11-23 10:55:55","2018-11-23 10:55:55","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:55:55","2018-11-23 10:55:55","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("115","2","2018-11-23 10:56:57","2018-11-23 10:56:57","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"96\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:56:57","2018-11-23 10:56:57","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("116","2","2018-11-23 10:57:17","2018-11-23 10:57:17","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:57:17","2018-11-23 10:57:17","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("118","2","2018-11-23 10:57:45","2018-11-23 10:57:45","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"91\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:57:45","2018-11-23 10:57:45","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("119","2","2018-11-23 10:58:04","2018-11-23 10:58:04","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">About the event</h3>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 10:58:04","2018-11-23 10:58:04","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("121","2","2018-11-23 11:01:53","2018-11-23 11:01:53","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h3 class=\"title\">Think you got what it takes?</h3>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 11:01:53","2018-11-23 11:01:53","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("122","2","2018-11-23 11:02:11","2018-11-23 11:02:11","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>This is a 2-day Hackathon happening at the Ashesi University campus from 30th November 2018 to 1st December 2018. API: Connect would have cash prizes and swags for the winning teams which would be the best 3 projects. The participating teams would have a number of 3 to 4 individuals each. Food and all required logistics would be provided for participants except transportation to the venue.</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<div class=\"col-12 col-md-6\">
<p>Each participant is free to build awesome products on provided APIs and services but must meet certain criteria, including:</p>
<ul>
<li>Solutions must have a real-world use case.</li>
<li>Participants must utilize at least one of the sponsors API. (Cloudinary API). Familiarize themselves with the API but trainers will be on sight to assist them with the integration</li>
<li>Solutions will be open-sourced on GitHub.</li>
</ul>
</div>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 11:02:11","2018-11-23 11:02:11","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("124","2","2018-11-23 11:16:43","2018-11-23 11:16:43","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row _builder_version=\"3.0.98\" custom_padding=\"27px|0px|0px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p>&nbsp;</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative to the problem.</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" header_font=\"|||||on|||\" text_font=\"||||||||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 11:16:43","2018-11-23 11:16:43","","2","http://hack.africa/index.php/2018/11/23/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("126","2","2018-11-23 11:20:38","2018-11-23 11:20:38","","Registration Deadline","","inherit","closed","closed","","88-autosave-v1","","","2018-11-23 11:20:38","2018-11-23 11:20:38","","88","http://hack.africa/index.php/2018/11/23/88-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("127","2","2018-11-23 11:22:12","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-11-23 11:22:12","0000-00-00 00:00:00","","0","http://hack.africa/?page_id=127","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("128","2","2018-11-23 11:23:05","2018-11-23 11:23:05","[et_pb_section fb_built=\"1\" background_color=\"#151515\" admin_label=\"section\" _builder_version=\"3.0.98\"][et_pb_row custom_padding=\"0px|5%|0%|5%\" background_color=\"#0a0908\" admin_label=\"row\" module_id=\"register-form\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" border_color_all=\"#ffffff\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" admin_label=\"Text\" _builder_version=\"3.0.98\" text_font=\"||||||||\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" text_orientation=\"center\"]				[/et_pb_text][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\" text_orientation=\"center\"]<h1>Welcome to the Dojo, Brave one</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row custom_padding=\"0px|5%|2%|5%\" make_equal=\"on\" background_color=\"#0a0908\" padding_top_2=\"5%\" admin_label=\"row\" module_id=\"custom-form\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" border_color_all=\"#ffffff\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" admin_label=\"Text\" _builder_version=\"3.0.98\" text_font=\"||||||||\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" text_orientation=\"center\"][/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\" custom_margin=\"||5px|\" custom_padding=\"||0px|\"][/et_pb_image][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"|300|||||||\" text_font_size=\"12px\" text_orientation=\"center\" custom_margin=\"0px|0px|0px|0px\" custom_padding=\"0px|0px|0px|0px\"]<p>Photo by Oladimeji Odunsi on Unsplash</p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","publish","closed","closed","","register","","","2018-11-23 19:23:59","2018-11-23 19:23:59","","0","http://hack.africa/?page_id=128","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("129","2","2018-11-23 11:23:05","2018-11-23 11:23:05","","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 11:23:05","2018-11-23 11:23:05","","128","http://hack.africa/index.php/2018/11/23/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("130","2","2018-11-23 11:26:00","2018-11-23 11:26:00","The final list of the participants will be published. This will be the official reference for participants and","Publishing of participant list","","inherit","closed","closed","","87-autosave-v1","","","2018-11-23 11:26:00","2018-11-23 11:26:00","","87","http://hack.africa/87-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("131","2","2018-11-23 11:27:18","2018-11-23 11:27:18","","Participants","","publish","closed","closed","","participants","","","2018-11-23 11:27:18","2018-11-23 11:27:18","","0","http://hack.africa/?page_id=131","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("132","2","2018-11-23 11:27:18","2018-11-23 11:27:18","","Participants","","inherit","closed","closed","","131-revision-v1","","","2018-11-23 11:27:18","2018-11-23 11:27:18","","131","http://hack.africa/131-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("133","2","2018-11-23 11:35:02","2018-11-23 11:35:02","The first Kata will test the participant\'s knowledge of the programming language\'s fundamental concepts. This aims at ensuring that the participant has a general understanding of the language enough to","Kata #1: Fundamentals","","inherit","closed","closed","","86-autosave-v1","","","2018-11-23 11:35:02","2018-11-23 11:35:02","","86","http://hack.africa/86-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("134","2","2018-11-23 11:45:02","2018-11-23 11:45:02","Does the participant understand different data types in the programming language? Does the participant understand the operations that can be undertaken on the specific data types and the different results for the same operation?

<em>[Kata URL will be posted on 10th December 2019 12:00 AM]</em>","Kata 2: Data Types","","inherit","closed","closed","","85-autosave-v1","","","2018-11-23 11:45:02","2018-11-23 11:45:02","","85","http://hack.africa/85-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("135","2","2018-11-23 11:52:38","2018-11-23 11:52:38","<div class=\"row vg-header\">
<div class=\"col\">
<h5>Definition of <em>algorithm
</em></h5>
<ul>
 	<li><span class=\"dt hasSdSense\"><span class=\"dtText\">a procedure for solving a mathematical problem (as of finding the greatest common divisor) in a finite number of steps that frequently involves repetition of an operation </span></span></li>
 	<li><span class=\"sdsense\"><span class=\"dtText\">a step-by-step procedure for solving a problem or accomplishing some end</span></span></li>
</ul>
<h5><a href=\"https://www.merriam-webster.com/dictionary/algorithm\"> Merriam Webster Dictionary</a></h5>
</div>
</div>
This challenge will test the participant\'s ability to disect a problem and create a finite number of steps that will solve the problem.

<em>[Kata URL will be posted on 12th December 2019 12:00 AM]</em>","Kata #3: Algorithms","","inherit","closed","closed","","84-autosave-v1","","","2018-11-23 11:52:38","2018-11-23 11:52:38","","84","http://hack.africa/84-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("136","2","2018-11-23 12:08:10","2018-11-23 12:08:10","Games will test the participants creative thinking and agility. Is the participant able to think outside normal programming contexts and deliver fun, working interations?

<em>[Kata URL will be posted on 13th December 2018 12:00 AM]</em>","Kata #4: Puzzles and Games","","publish","open","closed","","kata-4-puzzles-and-games","","","2018-11-23 12:12:20","2018-11-23 12:12:20","","0","http://hack.africa/?post_type=mec-events&#038;p=136","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("137","2","2018-11-23 12:19:04","2018-11-23 12:19:04","An important aspect of life is being able to read and understand context, internalize the  situation, draw conclusions and perform based on those conclusions. This Kata will test the logical thinking abilities of the participant.

<em>[Kata URL will be posted on 14th December 2018 12:00 AM]</em>","Kata #5: Logic","","publish","open","closed","","kata-5-logic","","","2018-11-23 12:20:53","2018-11-23 12:20:53","","0","http://hack.africa/?post_type=mec-events&#038;p=137","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("138","2","2018-11-23 12:27:46","2018-11-23 12:27:46","Arrays allow for storage of multiple data values in one variable/object. They form a critical basis for all advanced data-storage systems from Relational to Non-Relational Databases. This is true also for big data, arrays are used to understand and process the data. Thus it is critical for the participant to understand them.

<em>[Kata URL will be posted on 17th December 2018 12:00 AM]</em>","Kata #6: Array Series","","publish","open","closed","","kata-6-array-series","","","2018-11-23 12:28:33","2018-11-23 12:28:33","","0","http://hack.africa/?post_type=mec-events&#038;p=138","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("139","2","2018-11-23 12:28:54","2018-11-23 12:28:54","Arrays allow for storage of multiple data values in one variable/object. They form a critical basis for all advanced data-storage systems from Relational to Non-Relational Databases. This is true also for big data, arrays are used to understand and process the data. Thus it is critical for the participant to understand them.

<em>[Kata URL will be posted on 18th December 2018 12:00 AM]</em>","Kata #7: Array Series","","publish","open","closed","","kata-7-array-series","","","2018-11-23 12:28:54","2018-11-23 12:28:54","","0","http://hack.africa/?post_type=mec-events&#038;p=139","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("140","2","2018-11-23 12:29:34","2018-11-23 12:29:34","Arrays allow for storage of multiple data values in one variable/object. They form a critical basis for all advanced data-storage systems from Relational to Non-Relational Databases. This is true also for big data, arrays are used to understand and process the data. Thus it is critical for the participant to understand them.

<em>[Kata URL will be posted on 19th December 2018 12:00 AM]</em>","Kata #8: Array Series","","publish","open","closed","","kata-8-array-series","","","2018-11-23 12:31:26","2018-11-23 12:31:26","","0","http://hack.africa/?post_type=mec-events&#038;p=140","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("141","2","2018-11-23 12:30:49","2018-11-23 12:30:49","Arrays allow for storage of multiple data values in one variable/object. They form a critical basis for all advanced data-storage systems from Relational to Non-Relational Databases. This is true also for big data, arrays are used to understand and process the data. Thus it is critical for the participant to understand them.

<em>[Kata URL will be posted on 20th December 2018 12:00 AM]</em>","Kata #9: Array Series","","publish","open","closed","","kata-9-array-series","","","2018-11-23 12:30:49","2018-11-23 12:30:49","","0","http://hack.africa/?post_type=mec-events&#038;p=141","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("142","2","2018-11-23 12:31:50","2018-11-23 12:31:50","Arrays allow for storage of multiple data values in one variable/object. They form a critical basis for all advanced data-storage systems from Relational to Non-Relational Databases. This is true also for big data, arrays are used to understand and process the data. Thus it is critical for the participant to understand them.

<em>[Kata URL will be posted on 21th December 2018 12:00 AM]</em>","Kata #10: Array Series","","publish","open","closed","","kata-10-array-series","","","2018-11-23 12:32:13","2018-11-23 12:32:13","","0","http://hack.africa/?post_type=mec-events&#038;p=142","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("143","2","2018-11-23 12:36:46","2018-11-23 12:36:46","The next week, the participants will receive a data-set and analyse it for possible problems and prospective solutions using the programming language they had selected. During this step, they will select one out-of three datasets.

<em>[Form will be sent on 22nd </em>December,<em> 2018 12:00 am]</em>","Data Category Selection","","publish","open","closed","","data-category-selection","","","2018-11-23 13:31:31","2018-11-23 13:31:31","","0","http://hack.africa/?post_type=mec-events&#038;p=143","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("144","2","2018-11-23 12:39:22","2018-11-23 12:39:22","The participants will have selected a specific sector for analysis. The participants will then now receive the datasets and specific instructions on how they are to analyse the data to ensure transparency and accountability.

<em>[Data-set and Instructions will be sent on 21st </em>December,<em> 2018 12:00 am]</em>","Data-set and Instructions Release","","publish","open","closed","","data-set-and-instructions-release","","","2018-11-23 17:46:44","2018-11-23 17:46:44","","0","http://hack.africa/?post_type=mec-events&#038;p=144","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("145","2","2018-11-23 12:41:58","2018-11-23 12:41:58","The participants will have the week to analyse the information given to them. They are expected to form hypothesis statements, confirm their hypotheses using data-analysis and plotting techniques. They will then submit their analysis as part of their submissions as well as assumptions made during analysis.

From their analysis, the participants will look for possible problems. They will need to submit their analysis and problem statement(s) by 24th December 2018.

<em>[Submission instructions will be sent on 24th </em>December,<em> 2018]</em>","Data analysis","","publish","open","closed","","data-analysis","","","2018-11-23 17:45:03","2018-11-23 17:45:03","","0","http://hack.africa/?post_type=mec-events&#038;p=145","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("146","2","2018-11-23 12:45:04","2018-11-23 12:45:04","The participants will have the week to analyse the information given to them. They are expected to form hypothesis statements, confirm their hypotheses using data-analysis and plotting techniques. They will then submit their analysis as part of their submissions as well as assumptions made during analysis.

From their analysis, the participants will look for possible problems. They will then develop a Solution draft which should be submitted by","Data analysis","","inherit","closed","closed","","145-autosave-v1","","","2018-11-23 12:45:04","2018-11-23 12:45:04","","145","http://hack.africa/145-autosave-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("147","2","2018-11-23 12:50:04","2018-11-23 12:50:04","Pre-selected judges will analyse the participant\'s submission, their Twitter engagement, online code solutions. From these, they will then select the winners of the challenge. The prizes will be submitted electronically before 5pm, 31st December 2018.
<blockquote>Happy New Year to all the participants, bravo to the winners!!</blockquote>","Awarding Ceremony","","publish","open","closed","","awarding-ceremony","","","2018-11-23 12:50:04","2018-11-23 12:50:04","","0","http://hack.africa/?post_type=mec-events&#038;p=147","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("148","2","2018-11-23 13:11:38","2018-11-23 13:11:38","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:11:38","2018-11-23 13:11:38","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("150","2","2018-11-23 13:33:51","2018-11-23 13:33:51","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:33:51","2018-11-23 13:33:51","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("152","2","2018-11-23 13:41:47","2018-11-23 13:41:47","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h1>Challenge checkpoints</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:41:47","2018-11-23 13:41:47","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("153","2","2018-11-23 13:42:23","2018-11-23 13:42:23","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Challenge checkpoints</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:42:23","2018-11-23 13:42:23","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("155","2","2018-11-23 13:43:22","2018-11-23 13:43:22","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\" header_font=\"|||||on|||\" header_font_size=\"35px\" header_text_align=\"center\"]<h1>Checkpoints</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:43:22","2018-11-23 13:43:22","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("158","2","2018-11-23 13:48:03","2018-11-23 13:48:03"," ","","","publish","closed","closed","","158","","","2018-11-23 13:54:15","2018-11-23 13:54:15","","0","http://hack.africa/?p=158","3","nav_menu_item","","0");
INSERT INTO `afhwp_posts` VALUES ("162","2","2018-11-23 13:50:07","2018-11-23 13:50:07","","Checkpoints","","publish","closed","closed","","checkpoints","","","2018-11-23 13:54:15","2018-11-23 13:54:15","","0","http://hack.africa/?p=162","2","nav_menu_item","","0");
INSERT INTO `afhwp_posts` VALUES ("163","2","2018-11-23 13:50:58","2018-11-23 13:50:58","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|54px|0px\" module_id=\"checkpoints\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\" header_font=\"|||||on|||\" header_font_size=\"35px\" header_text_align=\"center\"]<h1>Checkpoints</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:50:58","2018-11-23 13:50:58","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("165","2","2018-11-23 13:51:22","2018-11-23 13:51:22","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" _builder_version=\"3.0.98\" module_id=\"hero\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" button_two_text=\"About Us\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|54px|0px\" module_id=\"checkpoints\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\" header_font=\"|||||on|||\" header_font_size=\"35px\" header_text_align=\"center\"]<h1>Checkpoints</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 13:51:22","2018-11-23 13:51:22","","2","http://hack.africa/2-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("167","2","2018-11-23 13:51:52","2018-11-23 13:51:52","","#100KataChallenge","","publish","closed","closed","","100katachallenge","","","2018-11-23 13:54:15","2018-11-23 13:54:15","","0","http://hack.africa/?p=167","1","nav_menu_item","","0");
INSERT INTO `afhwp_posts` VALUES ("168","2","2018-11-23 13:52:33","2018-11-23 13:52:33","","About Us","","trash","closed","closed","","about-us__trashed","","","2018-11-23 18:49:29","2018-11-23 18:49:29","","0","http://hack.africa/?page_id=168","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("169","2","2018-11-23 13:52:33","2018-11-23 13:52:33","","About Us","","inherit","closed","closed","","168-revision-v1","","","2018-11-23 13:52:33","2018-11-23 13:52:33","","168","http://hack.africa/168-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("170","2","2018-11-23 13:52:56","2018-11-23 13:52:56"," ","","","publish","closed","closed","","170","","","2018-11-23 13:54:15","2018-11-23 13:54:15","","0","http://hack.africa/?p=170","4","nav_menu_item","","0");
INSERT INTO `afhwp_posts` VALUES ("171","2","2018-11-23 13:53:19","2018-11-23 13:53:19","[et_pb_section fb_built=\"1\" fullwidth=\"on\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"Contact Us\" _builder_version=\"3.0.98\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/photo-1498732528303-ceac1ff31508.jpg\" background_layout=\"dark\" title_font=\"|||||on|||\" background_overlay_color=\"rgba(0,0,0,0.2)\" title_font_size=\"44px\" content_font=\"|300|||||||\" content_font_size=\"12px\" subhead=\"Want to Partner with us?  Have questions about the competition?  Feel free to contact us\" subhead_font=\"|||||on|||\" subhead_font_size=\"15px\" content_line_height=\"3em\" subhead_line_height=\"3em\" custom_padding=\"15vh||15vh|\" subhead_letter_spacing=\"3px\"]<p>Photo by Nate Greno on Unsplash</p>
[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" module_id=\"custom-form\"]<p>[contact-form-7 id=\"216\" title=\"Contact Us Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Contact Us","","publish","closed","closed","","contact-us","","","2018-11-23 19:31:35","2018-11-23 19:31:35","","0","http://hack.africa/?page_id=171","0","page","","0");
INSERT INTO `afhwp_posts` VALUES ("172","2","2018-11-23 13:53:19","2018-11-23 13:53:19","","Contact Us","","inherit","closed","closed","","171-revision-v1","","","2018-11-23 13:53:19","2018-11-23 13:53:19","","171","http://hack.africa/171-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("173","2","2018-11-23 13:53:45","2018-11-23 13:53:45"," ","","","publish","closed","closed","","173","","","2018-11-23 13:54:15","2018-11-23 13:54:15","","0","http://hack.africa/?p=173","5","nav_menu_item","","0");
INSERT INTO `afhwp_posts` VALUES ("174","2","2018-11-23 17:50:14","2018-11-23 17:50:14","After submitting their problem drafts, the participants will send out their final solution papers to the participants. The papers should be submitted by 5:00 pm 28th December, 2018.

<em>[Submission instructions will be sent out on 28th </em>December,<em> 2018]</em>","Solution Ideation and Presentation","","publish","open","closed","","solution-ideation-and-presentation","","","2018-11-23 17:50:14","2018-11-23 17:50:14","","0","http://hack.africa/?post_type=mec-events&#038;p=174","0","mec-events","","0");
INSERT INTO `afhwp_posts` VALUES ("175","2","2018-11-23 17:51:39","2018-11-23 17:51:39","[et_pb_section admin_label=\"section\"]
		[et_pb_row admin_label=\"row\"]
			[et_pb_column type=\"4_4\"]
				[et_pb_text admin_label=\"Text\"]
					
				[/et_pb_text]
			[/et_pb_column]
		[/et_pb_row]
	[/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 17:51:39","2018-11-23 17:51:39","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("177","2","2018-11-23 17:56:33","2018-11-23 17:56:33","<label> 
    [text* first-name placeholder=\"First Name (required)\"] </label>

<label> 
    [text* last-name placeholder=\"Last Name (required)\"] </label>

<label> 
    [email* your-email placeholder=\"Your Email (required)\"] </label>

<label>  
    [tel* phone-number placeholder=\"Phone Number(required)\"] </label>

<label> 
    [text* twitter-username placeholder=\"Twitter Username (required)\"] </label>

[submit \"Participate\"]
1
Afrihack \"[your-subject]\"
[your-name] <wordpress@hack.africa>
ngunyimacharia@gmail.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)
Reply-To: [your-email]




Afrihack \"[your-subject]\"
Afrihack <wordpress@hack.africa>
[your-email]
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)
Reply-To: ngunyimacharia@gmail.com



Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.
The date format is incorrect.
The date is before the earliest one allowed.
The date is after the latest one allowed.
There was an unknown error uploading the file.
You are not allowed to upload files of this type.
The file is too big.
There was an error uploading the file.
The number format is invalid.
The number is smaller than the minimum allowed.
The number is larger than the maximum allowed.
The answer to the quiz is incorrect.
Your entered code is incorrect.
The e-mail address entered is invalid.
The URL is invalid.
The telephone number is invalid.","Registration Form","","publish","closed","closed","","contact-form-1","","","2018-11-23 18:37:53","2018-11-23 18:37:53","","0","http://hack.africa/?post_type=wpcf7_contact_form&#038;p=177","0","wpcf7_contact_form","","0");
INSERT INTO `afhwp_posts` VALUES ("178","2","2018-11-24 10:24:51","2018-11-24 10:24:51","ngunyimacharia@gmail.com
ngunyimacharia","ngunyimacharia@gmail.com","","publish","closed","closed","","ngunyimacharia-gmail-com","","","2018-11-24 10:24:51","2018-11-24 10:24:51","","0","http://hack.africa/ngunyimacharia-gmail-com/","0","flamingo_contact","","0");
INSERT INTO `afhwp_posts` VALUES ("179","2","2018-11-23 18:01:50","2018-11-23 18:01:50","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:01:50","2018-11-23 18:01:50","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("181","2","2018-11-23 18:07:55","2018-11-23 18:07:55","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:07:55","2018-11-23 18:07:55","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("183","2","2018-11-23 18:11:55","2018-11-23 18:11:55","Photo by Oladimeji Odunsi on Unsplash","oladimeji-odunsi-558609-unsplash","Photo by Oladimeji Odunsi on Unsplash","inherit","open","closed","","oladimeji-odunsi-558609-unsplash","","","2018-11-23 18:12:02","2018-11-23 18:12:02","","0","http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg","0","attachment","image/jpeg","0");
INSERT INTO `afhwp_posts` VALUES ("184","2","2018-11-23 18:12:24","2018-11-23 18:12:24","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" bg_img_1=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" bg_img=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:12:24","2018-11-23 18:12:24","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("186","2","2018-11-23 18:15:05","2018-11-23 18:15:05","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" bg_img_1=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" bg_img=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:15:05","2018-11-23 18:15:05","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("187","2","2018-11-23 18:15:33","2018-11-23 18:15:33","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" bg_img_1=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" bg_img=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:15:33","2018-11-23 18:15:33","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("189","2","2018-11-23 18:15:56","2018-11-23 18:15:56","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" bg_img_1=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\"][et_pb_column type=\"1_3\" _builder_version=\"3.0.47\" bg_img=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][/et_pb_column][et_pb_column type=\"2_3\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:15:56","2018-11-23 18:15:56","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("191","2","2018-11-23 18:25:59","2018-11-23 18:25:59","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" bg_img_1=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" bg_img=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:25:59","2018-11-23 18:25:59","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("193","2","2018-11-23 18:27:14","2018-11-23 18:27:14","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:27:14","2018-11-23 18:27:14","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("194","2","2018-11-23 18:27:42","2018-11-23 18:27:42","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:27:42","2018-11-23 18:27:42","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("196","2","2018-11-23 18:28:17","2018-11-23 18:28:17","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:28:17","2018-11-23 18:28:17","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("198","2","2018-11-23 18:29:39","2018-11-23 18:29:39","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:29:39","2018-11-23 18:29:39","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("200","2","2018-11-23 18:30:15","2018-11-23 18:30:15","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h2>Fill the form below to join the #100KataChallenge</h2>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:30:15","2018-11-23 18:30:15","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("201","2","2018-11-23 18:30:33","2018-11-23 18:30:33","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:30:33","2018-11-23 18:30:33","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("203","2","2018-11-23 18:31:11","2018-11-23 18:31:11","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:31:11","2018-11-23 18:31:11","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("204","2","2018-11-23 18:31:36","2018-11-23 18:31:36","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:31:36","2018-11-23 18:31:36","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("206","2","2018-11-23 18:32:39","2018-11-23 18:32:39","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"||||||||\"]<div class=\"_3bJ2H CHExY\">
<div class=\"_1l8RX _1ByhS\"><span>Photo by <a href=\"https://unsplash.com/photos/e-TuK4z2LhY?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText\">Oladimeji Odunsi</a> on <a href=\"https://unsplash.com/search/photos/african?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText\">Unsplash</a></span></div>
</div>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:32:39","2018-11-23 18:32:39","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("208","2","2018-11-23 18:34:31","2018-11-23 18:34:31","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\" custom_padding=\"||0px|\" custom_margin=\"||5px|\"][/et_pb_image][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"|300|||||||\" custom_margin=\"0px|0px|0px|0px\" custom_padding=\"0px|0px|0px|0px\" text_font_size=\"12px\"]<div class=\"_3bJ2H CHExY\">
<div class=\"_1l8RX _1ByhS\"><span><em>Photo by</em> <a href=\"https://unsplash.com/photos/e-TuK4z2LhY?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText\">Oladimeji Odunsi</a> on <a href=\"https://unsplash.com/search/photos/african?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText\">Unsplash</a></span></div>
</div>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:34:31","2018-11-23 18:34:31","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("209","2","2018-11-23 18:40:28","2018-11-23 18:40:28","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|5%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\" custom_padding=\"||0px|\" custom_margin=\"||5px|\"][/et_pb_image][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"|300|||||||\" custom_margin=\"0px|0px|0px|0px\" custom_padding=\"0px|0px|0px|0px\" text_font_size=\"12px\"]<p>Photo by Oladimeji Odunsi on Unsplash</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:40:28","2018-11-23 18:40:28","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("211","2","2018-11-23 18:42:43","2018-11-23 18:42:43","[et_pb_section fb_built=\"1\" admin_label=\"section\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|0%|5%\" module_id=\"register-form\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]				[/et_pb_text][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1>Welcome to the Dojo, Brave one</h1>
[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row admin_label=\"row\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_color=\"#0a0908\" make_equal=\"on\" border_color_all=\"#ffffff\" custom_padding=\"0px|5%|2%|5%\" module_id=\"register-form\" padding_top_2=\"5%\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text admin_label=\"Text\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"||||||||\"]<br />
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\" custom_padding=\"||0px|\" custom_margin=\"||5px|\"][/et_pb_image][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_orientation=\"center\" text_font=\"|300|||||||\" custom_margin=\"0px|0px|0px|0px\" custom_padding=\"0px|0px|0px|0px\" text_font_size=\"12px\"]<p>Photo by Oladimeji Odunsi on Unsplash</p>
[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" background_layout=\"dark\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>
[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 18:42:43","2018-11-23 18:42:43","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("213","2","2018-11-23 18:52:10","2018-11-23 18:52:10","[et_pb_section admin_label=\"section\"]
		[et_pb_row admin_label=\"row\"]
			[et_pb_column type=\"4_4\"]
				[et_pb_text admin_label=\"Text\"]
					
				[/et_pb_text]
			[/et_pb_column]
		[/et_pb_row]
	[/et_pb_section]","Contact Us","","inherit","closed","closed","","171-revision-v1","","","2018-11-23 18:52:10","2018-11-23 18:52:10","","171","http://hack.africa/171-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("215","2","2018-11-23 18:58:22","2018-11-23 18:58:22","","photo-1498732528303-ceac1ff31508","","inherit","open","closed","","photo-1498732528303-ceac1ff31508","","","2018-11-23 18:58:22","2018-11-23 18:58:22","","0","http://hack.africa/wp-content/uploads/2018/11/photo-1498732528303-ceac1ff31508.jpg","0","attachment","image/jpeg","0");
INSERT INTO `afhwp_posts` VALUES ("216","2","2018-11-23 19:22:56","2018-11-23 19:22:56","<label> Your Name (required)
    [text* your-name] </label>

<label> Your Email (required)
    [email* your-email] </label>

<label> Subject
    [text your-subject] </label>

<label> Your Message
    [textarea your-message] </label>

[submit \"Send\"]
1
Afrihack \"[your-subject]\"
[your-name] <wordpress@hack.africa>
ngunyimacharia@gmail.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)
Reply-To: [your-email]




Afrihack \"[your-subject]\"
Afrihack <wordpress@hack.africa>
[your-email]
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Afrihack (http://hack.africa)
Reply-To: ngunyimacharia@gmail.com



Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.
The date format is incorrect.
The date is before the earliest one allowed.
The date is after the latest one allowed.
There was an unknown error uploading the file.
You are not allowed to upload files of this type.
The file is too big.
There was an error uploading the file.
The number format is invalid.
The number is smaller than the minimum allowed.
The number is larger than the maximum allowed.
The answer to the quiz is incorrect.
Your entered code is incorrect.
The e-mail address entered is invalid.
The URL is invalid.
The telephone number is invalid.","Contact Us Form","","publish","closed","closed","","contact-us-form","","","2018-11-23 19:22:56","2018-11-23 19:22:56","","0","http://hack.africa/?post_type=wpcf7_contact_form&p=216","0","wpcf7_contact_form","","0");
INSERT INTO `afhwp_posts` VALUES ("217","2","2018-11-23 19:23:59","2018-11-23 19:23:59","[et_pb_section fb_built=\"1\" background_color=\"#151515\" admin_label=\"section\" _builder_version=\"3.0.98\"][et_pb_row custom_padding=\"0px|5%|0%|5%\" background_color=\"#0a0908\" admin_label=\"row\" module_id=\"register-form\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" border_color_all=\"#ffffff\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" admin_label=\"Text\" _builder_version=\"3.0.98\" text_font=\"||||||||\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" text_orientation=\"center\"]				[/et_pb_text][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\" text_orientation=\"center\"]<h1>Welcome to the Dojo, Brave one</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row custom_padding=\"0px|5%|2%|5%\" make_equal=\"on\" background_color=\"#0a0908\" padding_top_2=\"5%\" admin_label=\"row\" module_id=\"custom-form\" _builder_version=\"3.0.98\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" border_color_all=\"#ffffff\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" admin_label=\"Text\" _builder_version=\"3.0.98\" text_font=\"||||||||\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" text_orientation=\"center\"][/et_pb_text][et_pb_text _builder_version=\"3.0.98\"][/et_pb_text][et_pb_image src=\"http://hack.africa/wp-content/uploads/2018/11/oladimeji-odunsi-558609-unsplash.jpg\" _builder_version=\"3.0.98\" max_width=\"80%\" module_alignment=\"center\" custom_margin=\"||5px|\" custom_padding=\"||0px|\"][/et_pb_image][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"|300|||||||\" text_font_size=\"12px\" text_orientation=\"center\" custom_margin=\"0px|0px|0px|0px\" custom_padding=\"0px|0px|0px|0px\"]<p>Photo by Oladimeji Odunsi on Unsplash</p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.47\" padding_top=\"5%\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"|||||on|||\" header_font=\"|||||on|||\"]<h4>Fill the form below to join the #100KataChallenge</h4>[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[contact-form-7 id=\"177\" title=\"Registration Form\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Register","","inherit","closed","closed","","128-revision-v1","","","2018-11-23 19:23:59","2018-11-23 19:23:59","","128","http://hack.africa/128-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("219","2","2018-11-23 19:25:00","2018-11-23 19:25:00","[et_pb_section fb_built=\"1\" fullwidth=\"on\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"Contact Us\" _builder_version=\"3.0.98\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/photo-1498732528303-ceac1ff31508.jpg\" background_layout=\"dark\" title_font=\"|||||on|||\" background_overlay_color=\"rgba(0,0,0,0.2)\" title_font_size=\"44px\" title_line_height=\"1.5em\" content_font=\"|||||on|||\" content_font_size=\"17px\"]<p>Want to Partner with us?  Have questions about the competition?  Feel free to contact us</p>
[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" module_id=\"custom-form\"]<p>[contact-form-7 id=\"216\" title=\"Contact Us Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Contact Us","","inherit","closed","closed","","171-revision-v1","","","2018-11-23 19:25:00","2018-11-23 19:25:00","","171","http://hack.africa/171-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("221","2","2018-11-23 19:31:35","2018-11-23 19:31:35","[et_pb_section fb_built=\"1\" fullwidth=\"on\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"Contact Us\" _builder_version=\"3.0.98\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/photo-1498732528303-ceac1ff31508.jpg\" background_layout=\"dark\" title_font=\"|||||on|||\" background_overlay_color=\"rgba(0,0,0,0.2)\" title_font_size=\"44px\" content_font=\"|300|||||||\" content_font_size=\"12px\" subhead=\"Want to Partner with us?  Have questions about the competition?  Feel free to contact us\" subhead_font=\"|||||on|||\" subhead_font_size=\"15px\" content_line_height=\"3em\" subhead_line_height=\"3em\" custom_padding=\"15vh||15vh|\" subhead_letter_spacing=\"3px\"]<p>Photo by Nate Greno on Unsplash</p>
[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" background_color=\"#151515\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" module_id=\"custom-form\"]<p>[contact-form-7 id=\"216\" title=\"Contact Us Form\"]</p>
[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Contact Us","","inherit","closed","closed","","171-revision-v1","","","2018-11-23 19:31:35","2018-11-23 19:31:35","","171","http://hack.africa/171-revision-v1/","0","revision","","0");
INSERT INTO `afhwp_posts` VALUES ("223","2","2018-11-23 19:34:44","2018-11-23 19:34:44","{
    \"et_divi[primary_nav_font_style]\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 19:34:44\"
    },
    \"et_divi[menu_link_active]\": {
        \"value\": \"#ffffff\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 19:34:44\"
    }
}","","","trash","closed","closed","","b3fe0db4-7a05-4045-843c-4f7ebc9b1159","","","2018-11-23 19:34:44","2018-11-23 19:34:44","","0","http://hack.africa/b3fe0db4-7a05-4045-843c-4f7ebc9b1159/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("224","2","2018-11-23 20:02:14","2018-11-23 20:02:14","{
    \"et_divi[footer_columns]\": {
        \"value\": \"2\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:02:14\"
    }
}","","","trash","closed","closed","","d1b7fd55-7b9c-4458-82a3-3a8fdb87f372","","","2018-11-23 20:02:14","2018-11-23 20:02:14","","0","http://hack.africa/d1b7fd55-7b9c-4458-82a3-3a8fdb87f372/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("225","2","2018-11-23 20:09:57","2018-11-23 20:09:57","{
    \"et_divi[disable_custom_footer_credits]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:09:57\"
    },
    \"et_divi[custom_footer_credits]\": {
        \"value\": \"\\u00a9 Copyright 2018 hack.africa All rights reserved. \",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:09:57\"
    }
}","","","trash","closed","closed","","b79cad57-e7f3-406e-afcd-dbfb73418b56","","","2018-11-23 20:09:57","2018-11-23 20:09:57","","0","http://hack.africa/b79cad57-e7f3-406e-afcd-dbfb73418b56/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("226","2","2018-11-23 20:10:51","2018-11-23 20:10:51","{
    \"et_divi[show_footer_social_icons]\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:10:51\"
    },
    \"et_divi[disable_custom_footer_credits]\": {
        \"value\": true,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:10:51\"
    }
}","","","trash","closed","closed","","e89c1837-3fe6-44ba-91cd-5bcd19011ca8","","","2018-11-23 20:10:51","2018-11-23 20:10:51","","0","http://hack.africa/e89c1837-3fe6-44ba-91cd-5bcd19011ca8/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("227","2","2018-11-23 20:14:41","2018-11-23 20:14:41","{
    \"et_divi[footer_columns]\": {
        \"value\": \"3\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:14:41\"
    }
}","","","trash","closed","closed","","ea3ffc20-333c-4f1f-a936-0b0e971b1544","","","2018-11-23 20:14:41","2018-11-23 20:14:41","","0","http://hack.africa/ea3ffc20-333c-4f1f-a936-0b0e971b1544/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("228","2","2018-11-23 20:15:33","2018-11-23 20:15:33","{
    \"widget_text[2]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJ0ZXh0IjtzOjE1OiI8Y29kZT4NCjwvY29kZT4iO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"82b024a727aebbd0c155b4be80f4ab46\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:15:33\"
    },
    \"sidebars_widgets[sidebar-4]\": {
        \"value\": [
            \"text-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:15:33\"
    },
    \"widget_text[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJ0ZXh0IjtzOjI1OiI8Y29kZT5bc21idG9vbGJhcl08L2NvZGU+IjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"41c14f84258c66002d67a5b895fbfae0\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:15:33\"
    }
}","","","trash","closed","closed","","f46ac6d8-a828-4430-a4d8-bf932ec32aef","","","2018-11-23 20:15:33","2018-11-23 20:15:33","","0","http://hack.africa/f46ac6d8-a828-4430-a4d8-bf932ec32aef/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("229","2","2018-11-23 20:16:28","2018-11-23 20:16:28","{
    \"et_divi[footer_menu_font_style]\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:16:28\"
    }
}","","","trash","closed","closed","","bc4bba24-7bbf-4c21-86aa-c40282195745","","","2018-11-23 20:16:28","2018-11-23 20:16:28","","0","http://hack.africa/bc4bba24-7bbf-4c21-86aa-c40282195745/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("230","2","2018-11-23 20:22:44","2018-11-23 20:22:44","{
    \"widget_text[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJ0ZXh0IjtzOjQ1OiI8Y29kZSBzdHlsZT0iZmxvYXQ6cmlnaHQiPltzbWJ0b29sYmFyXTwvY29kZT4iO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"2d39a0ebd485b1872ee41c71240a9f95\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:22:44\"
    }
}","","","trash","closed","closed","","1436bc21-fcca-4f51-9ed7-ff3418c8a20b","","","2018-11-23 20:22:44","2018-11-23 20:22:44","","0","http://hack.africa/1436bc21-fcca-4f51-9ed7-ff3418c8a20b/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("231","2","2018-11-23 20:23:51","2018-11-23 20:23:51","{
    \"sidebars_widgets[wp_inactive_widgets]\": {
        \"value\": [
            \"text-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:23:51\"
    },
    \"sidebars_widgets[sidebar-4]\": {
        \"value\": [
            \"custom_html-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:23:51\"
    },
    \"widget_text[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJ0ZXh0IjtzOjA6IiI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"7f31f0e137411800074b18494513116e\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:23:51\"
    },
    \"widget_custom_html[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjEyOiJbc21idG9vbGJhcl0iO30=\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"98d1b8477880e7e96315d95516dc14c2\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:23:51\"
    }
}","","","trash","closed","closed","","944d03ab-0dd4-4d9d-a0f5-a7f68ca87f18","","","2018-11-23 20:23:51","2018-11-23 20:23:51","","0","http://hack.africa/944d03ab-0dd4-4d9d-a0f5-a7f68ca87f18/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("232","2","2018-11-23 20:26:43","2018-11-23 20:26:43","{
    \"widget_custom_html[2]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjU2OiLCqSBDb3B5cmlnaHQgMjAxOCBBZnJpaGFjay4gJm5ic3A7QWxsIHJpZ2h0cyByZXNlcnZlZC4NCiI7fQ==\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"596b29dc6a951f80692212ea2b72b182\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:26:43\"
    }
}","","","trash","closed","closed","","40f9ef86-dc5f-4ad9-b176-6c8d4a14ba69","","","2018-11-23 20:26:43","2018-11-23 20:26:43","","0","http://hack.africa/40f9ef86-dc5f-4ad9-b176-6c8d4a14ba69/","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("233","2","2018-11-23 20:27:13","2018-11-23 20:27:13","{
    \"widget_custom_html[2]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjg1OiI8ZGl2IGNsYXNzPSJjb3B5cmlnaHQiPsKpIENvcHlyaWdodCAyMDE4IEFmcmloYWNrLiAmbmJzcDtBbGwgcmlnaHRzIHJlc2VydmVkLjwvZGl2Pg0KIjt9\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"5084b10144659d2ff28e8e6ccc92c332\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-23 20:27:13\"
    }
}","","","trash","closed","closed","","f43dc6a6-cd32-4c82-a5ed-c5dd656b5a7f","","","2018-11-23 20:27:13","2018-11-23 20:27:13","","0","http://hack.africa/?p=233","0","customize_changeset","","0");
INSERT INTO `afhwp_posts` VALUES ("234","2","2018-11-23 20:31:56","2018-11-23 20:31:56","[et_pb_section fb_built=\"1\" fullwidth=\"on\" disabled_on=\"off|off|off\" module_id=\"hero\" _builder_version=\"3.0.98\"][et_pb_fullwidth_header title=\"#100KataChallenge\" subhead=\"December 10th to 31st, 2019\" background_layout=\"dark\" text_orientation=\"right\" header_fullscreen=\"on\" button_one_text=\"Register Now\" background_overlay_color=\"rgba(10,9,8,0.85)\" _builder_version=\"3.0.98\" title_font=\"|||||on|||\" title_font_size=\"90px\" title_text_color=\"#f40612\" content_font=\"|600||||on|||\" content_font_size=\"18px\" content_line_height=\"3em\" subhead_font=\"|600||on|||||\" subhead_font_size=\"24px\" subhead_line_height=\"3em\" background_color=\"#151515\" background_image=\"http://hack.africa/wp-content/uploads/2018/11/nesa-by-makers-701360-unsplash.jpg\" parallax=\"on\" custom_margin=\"|||\" custom_padding=\"|||\" button_one_url=\"/register\"]<span style=\"font-weight: 400;\">Want to showcase and improve your data science skills?</span>

<span style=\"font-weight: 400;\">Interested in learning and challenging your skills using <strong>Python</strong> or <strong>R</strong> programming languages?</span>

<span style=\"font-weight: 400;\">Sign-up for the #100KataChallenge!
</span>[/et_pb_fullwidth_header][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|0px|0px\"][et_pb_row custom_padding=\"27px|0px|0px|0px\" _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\" text_font=\"|||||on|||\"]<h1 class=\"title\">Think you got what it takes?</h1>[/et_pb_text][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>Kata (型 or 形 literally: \"form\"), a Japanese word, are detailed choreographed patterns of movements practised either solo or in pairs.</p>
<p>The <span style=\"color: #ff0000;\"><strong>#100KataChallenge</strong></span> is an online challenge that will take place for 22 days between 10th - 31st December 2018. Challenges will be delivered on a day-to-day basis and engagement will be driven through Twitter.</p>
<p>The participants will receive daily challenges they are expected to complete and post their completion status on a single thread on their Twitter accounts.</p>
<p>Each participant will have to complete the day\'s challenge before the day ends. They need to post their completion status on Twitter before 11:59 pm.</p>
<p>The next challenge will be automatically sent out at midnight for participants to complete. For answer validation, the Kata\'s will be done on <a href=\"http://codewars.com/\">https://codewars.com.</a></p>
<p> </p>[/et_pb_text][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<h5>First week (10th - 14th December 2018)</h5>
<p>Participants will be introduced to kata challenges by solving general-topic random problems in the 8 KYU level.</p>
<h5>Second week (17th to 21st December 2018)</h5>
<p>Participants will be solving problems in an Array Challenge Series categorized as a 7 KYU level.</p>
<h5>Third week (24th to 28th December 2018)</h5>
<p>Participants will be introduced to a data set which they will be required to analyse, identify a particular problem from the data set and create an innovative solution to the problem.</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\"]<h1 style=\"text-align: center;\">Don\'t forget that registration ends on December 7th, 2019</h1>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" _builder_version=\"3.0.98\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"97\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" background_color=\"#151515\" module_id=\"checkpoints\" _builder_version=\"3.0.98\" custom_padding=\"0px|0px|54px|0px\"][et_pb_row _builder_version=\"3.0.98\"][et_pb_column type=\"4_4\" _builder_version=\"3.0.98\" parallax=\"off\" parallax_method=\"on\"][et_pb_text background_layout=\"dark\" _builder_version=\"3.0.98\" text_font=\"||||||||\" header_font=\"|||||on|||\" header_text_align=\"center\" header_font_size=\"35px\"]<h1>Checkpoints</h1>[/et_pb_text][et_pb_text _builder_version=\"3.0.98\"]<p>[MEC id=\"95\"]</p>[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]","Home","","inherit","closed","closed","","2-revision-v1","","","2018-11-23 20:31:56","2018-11-23 20:31:56","","2","http://hack.africa/2-revision-v1/","0","revision","","0");


CREATE TABLE IF NOT EXISTS `afhwp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_term_relationships` VALUES ("1","1","0");
INSERT INTO `afhwp_term_relationships` VALUES ("158","2","0");
INSERT INTO `afhwp_term_relationships` VALUES ("162","2","0");
INSERT INTO `afhwp_term_relationships` VALUES ("167","2","0");
INSERT INTO `afhwp_term_relationships` VALUES ("170","2","0");
INSERT INTO `afhwp_term_relationships` VALUES ("173","2","0");


CREATE TABLE IF NOT EXISTS `afhwp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_term_taxonomy` VALUES ("1","1","category","","0","0");
INSERT INTO `afhwp_term_taxonomy` VALUES ("2","2","nav_menu","","0","5");


CREATE TABLE IF NOT EXISTS `afhwp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `afhwp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_terms` VALUES ("1","Uncategorized","uncategorized","0");
INSERT INTO `afhwp_terms` VALUES ("2","Main Menu","main-menu","0");


CREATE TABLE IF NOT EXISTS `afhwp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_usermeta` VALUES ("1","2","nickname","ngunyimacharia");
INSERT INTO `afhwp_usermeta` VALUES ("2","2","first_name","");
INSERT INTO `afhwp_usermeta` VALUES ("3","2","last_name","");
INSERT INTO `afhwp_usermeta` VALUES ("4","2","description","");
INSERT INTO `afhwp_usermeta` VALUES ("5","2","rich_editing","true");
INSERT INTO `afhwp_usermeta` VALUES ("6","2","syntax_highlighting","true");
INSERT INTO `afhwp_usermeta` VALUES ("7","2","comment_shortcuts","false");
INSERT INTO `afhwp_usermeta` VALUES ("8","2","admin_color","fresh");
INSERT INTO `afhwp_usermeta` VALUES ("9","2","use_ssl","0");
INSERT INTO `afhwp_usermeta` VALUES ("10","2","show_admin_bar_front","true");
INSERT INTO `afhwp_usermeta` VALUES ("11","2","locale","");
INSERT INTO `afhwp_usermeta` VALUES ("12","2","afhwp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `afhwp_usermeta` VALUES ("13","2","afhwp_user_level","10");
INSERT INTO `afhwp_usermeta` VALUES ("14","2","dismissed_wp_pointers","wp496_privacy,text_widget_custom_html");
INSERT INTO `afhwp_usermeta` VALUES ("15","2","show_welcome_panel","1");
INSERT INTO `afhwp_usermeta` VALUES ("16","2","session_tokens","a:5:{s:64:\"87b9bd025c8dccef44a285af14e40db78e6636ce39637203953741d742cfce50\";a:4:{s:10:\"expiration\";i:1544173615;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:68:\"Mozilla/5.0 (X11; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1542964015;}s:64:\"bc0e7ede49c4024aff83b04026008f8dfb0436081d81a2634550aa45b8b0e079\";a:4:{s:10:\"expiration\";i:1544258580;s:2:\"ip\";s:12:\"172.68.186.9\";s:2:\"ua\";s:68:\"Mozilla/5.0 (X11; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1543048980;}s:64:\"38065bac01d1ee2b3bb93fe77c91517d6edd6b5099f708ead21a352de3d6433a\";a:4:{s:10:\"expiration\";i:1544261730;s:2:\"ip\";s:13:\"172.68.186.63\";s:2:\"ua\";s:68:\"Mozilla/5.0 (X11; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1543052130;}s:64:\"3409785efc7a5f7f79500abf0be36a47607ffde5f2235c9c1491e3ae5549f8c1\";a:4:{s:10:\"expiration\";i:1543226987;s:2:\"ip\";s:13:\"172.68.186.63\";s:2:\"ua\";s:68:\"Mozilla/5.0 (X11; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1543054187;}s:64:\"0ea787c830e31d977054f3fd552c8e47eb789914005361191da95762e88f6ab2\";a:4:{s:10:\"expiration\";i:1544265023;s:2:\"ip\";s:12:\"172.68.186.9\";s:2:\"ua\";s:68:\"Mozilla/5.0 (X11; Linux x86_64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1543055423;}}");
INSERT INTO `afhwp_usermeta` VALUES ("17","2","afhwp_dashboard_quick_press_last_post_id","4");
INSERT INTO `afhwp_usermeta` VALUES ("18","2","community-events-location","a:1:{s:2:\"ip\";s:13:\"197.251.185.0\";}");
INSERT INTO `afhwp_usermeta` VALUES ("19","2","afhwp_user-settings","libraryContent=browse&editor=tinymce");
INSERT INTO `afhwp_usermeta` VALUES ("20","2","afhwp_user-settings-time","1543004892");
INSERT INTO `afhwp_usermeta` VALUES ("21","2","show_try_gutenberg_panel","0");
INSERT INTO `afhwp_usermeta` VALUES ("22","2","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `afhwp_usermeta` VALUES ("23","2","metaboxhidden_nav-menus","a:7:{i:0;s:21:\"add-post-type-project\";i:1;s:24:\"add-post-type-mec-events\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";i:4;s:20:\"add-project_category\";i:5;s:15:\"add-project_tag\";i:6;s:16:\"add-mec_category\";}");
INSERT INTO `afhwp_usermeta` VALUES ("24","2","nav_menu_recently_edited","2");
INSERT INTO `afhwp_usermeta` VALUES ("25","2","itsec_user_activity_last_seen","1543140401");
INSERT INTO `afhwp_usermeta` VALUES ("26","2","itsec-settings-view","grid");
INSERT INTO `afhwp_usermeta` VALUES ("27","2","itsec-password-strength","4");
INSERT INTO `afhwp_usermeta` VALUES ("28","2","_itsec_password_requirements","a:1:{s:16:\"evaluation_times\";a:1:{s:8:\"strength\";i:1543054187;}}");
INSERT INTO `afhwp_usermeta` VALUES ("29","2","_itsec_has_logged_in","1543054187");


CREATE TABLE IF NOT EXISTS `afhwp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `afhwp_users` VALUES ("2","ngunyimacharia","$P$BEKZmbbcVcv.We1tJ9skZ.KhBb7zrP.","ngunyimacharia","ngunyimacharia@gmail.com","","2018-11-23 09:06:33","","0","ngunyimacharia");




